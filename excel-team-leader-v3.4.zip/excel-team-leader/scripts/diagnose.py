#!/usr/bin/env python3
"""よくあるエラーの原因を判定し、直し方を示す（Pythonライブラリ・Excel・文字コード・メモリなど）。

判定できないエラーは「想定外」として、ログを見せて相談してもらう。
使い方:
  python diagnose.py --message "ModuleNotFoundError: No module named 'xlwings'"
  python diagnose.py --log work/logs/202611251200_log.txt          （最後のNG/WARN行と原因を表示）
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

PIP_NAMES = {"xlwings": "xlwings", "xlrd": "xlrd", "openpyxl": "openpyxl", "pandas": "pandas",
             "numpy": "numpy", "PIL": "pillow"}

# (判定の語, 分類, 原因のめやす, やってみてほしいこと)
RULES = [
    (("No module named",), "ライブラリが入っていない",
     "Pythonのライブラリが見つかりません",
     "次を実行してください：pip install {pip}（xlwings は Excel のある環境だけ必要です）"),
    (("PermissionError", "Permission denied", "開いたまま", "置き換えられません", "保存できません", "権限"),
     "Excelで開いている／権限がない",
     "ファイルを開けない、または保存できません",
     "Excel でそのファイルを閉じてから、もう一度実行してください。権限があるかも確かめてください"),
    (("BadZipFile", "not a zip file", "xlsxとして開けません"), "xlsxの中身が壊れている",
     "Excelファイルとして読めません（壊れているか、形式が違います）",
     "別名で保存し直すか、元のファイルを確かめてください。.xls なら convert を使います"),
    (("InvalidFileException",), "ファイルの形式が違う",
     "Excelの形式（.xlsx）ではありません",
     "拡張子と中身を確かめ、.xlsx で保存し直してください。.xls・CSV は convert で変換します"),
    (("UnicodeDecodeError",), "文字コードの違い",
     "CSVの文字コードが想定と違います",
     "convert（utf-8-sig → cp932 の順）を使ってください"),
    (("MemoryError", "メモリ"), "データが多すぎる",
     "一度に扱うデータが大きすぎて、メモリが足りません",
     "ファイルやタブを分けて、数回に分けて実行してください（tests/run_scale.py で上限を確かめられます）"),
    (("PathLike", "not 'int'"), "ファイル名の指定が文字ではない",
     "ファイル名（出力先・入力先）に数字などが入っています",
     "ファイル名を文字（文字列）で指定し直してください（例：\"統合売上.xlsx\"）"),
    (("unsupported operand", "TypeError"), "指示の値の型が違う",
     "数字の欄に文字が入っている、などの可能性があります",
     "指示JSON（header_row・行数などの数字）の型を確かめてください"),
    (("KeyError", "見つかりません", "シートがありません"), "シート・列の名前が違う",
     "指定した名前が見つかりません",
     "シート名・列名の綴り、全角と半角、余分なスペースを確かめてください"),
    (("soffice", "LibreOffice", "再計算に失敗", "再計算が時間切れ"), "LibreOffice が使えない",
     "再計算ができないため、数式の結果は未確認です",
     "LibreOffice を入れるか、未確認のまま報告してから Excel で開いて確かめてもらってください"),
    (("xlwings", "COM", "pywintypes"), "Excel連携（開いたまま更新）が使えない",
     "Excel が無い環境か、xlwings が入っていません",
     "Excel のある Windows / Mac で実行するか、別ファイルに保存（warn）で対応してください"),
]
DEFAULT = ("想定外のエラー", "この原因は自動では判定できませんでした",
           "下のログを見せてください。必要なら開発者に相談してください")


def explain(message: str, kind: str | None = None) -> dict:
    """戻り値: {"category", "hint", "fix"}"""
    msg = message or ""
    if kind == "save" and not any(k in msg for k in ("保存", "置き換え", "開いて", "権限")):
        return {"category": "保存の問題", "hint": "保存先に書けませんでした", "fix": "保存先の空き・権限・Excelで開いていないかを確かめてください"}
    for keys, cat, hint, fix in RULES:
        if any(k in msg for k in keys):
            pip = ""
            m = re.search(r"No module named '([\w\.]+)'", msg)
            if m:
                pip = PIP_NAMES.get(m.group(1).split(".")[0], m.group(1).split(".")[0])
            return {"category": cat, "hint": hint, "fix": fix.format(pip=pip or "（ライブラリ名）")}
    return {"category": DEFAULT[0], "hint": DEFAULT[1], "fix": DEFAULT[2]}


def log_excerpt(path: str | Path, n: int = 6) -> list[str]:
    """ログの末尾から、NG・WARN の行を最大 n 行返す（無ければ末尾 n 行）。"""
    p = Path(path)
    if not p.exists():
        return []
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    bad = [l for l in lines if "| NG " in l or "| WARN " in l]
    return (bad or lines)[-n:]


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--message", help="エラーの文章")
    ap.add_argument("--log", help="ログファイル")
    a = ap.parse_args()
    if a.log:
        lines = log_excerpt(a.log)
        if not lines:
            print("ログが見つかりません:", a.log)
        for l in lines:
            print(l)
            e = explain(l)
            if e["category"] != DEFAULT[0]:
                print(f"  → 原因のめやす：{e['hint']} / {e['fix']}")
    elif a.message:
        e = explain(a.message)
        print(f"分類：{e['category']}\n原因のめやす：{e['hint']}\nやってみてほしいこと：{e['fix']}")
    else:
        ap.print_help()
