#!/usr/bin/env python3
"""Excel処理テンプレ（読込 → 検査 → 計算 → 安全に保存）。

使い方:
    python excel_tool.py input.xlsx --sheet Sheet1 --out output.xlsx

方針:
    1. 入力ファイルは読み取りのみ（上書きしない）
    2. 検査でNGなら、理由を出して止まる
    3. 不正な行は止めずに「エラー行」シートへ分けて出力する
    4. 保存は一時ファイル → 置き換え（途中で落ちても壊れない）
    5. 処理件数とエラーをログに残す
終了コード: 0=成功 / 1=入力の問題 / 2=保存の問題 / 3=想定外
"""
import argparse
import logging
import os
import sys
import tempfile
from datetime import datetime
from pathlib import Path

import pandas as pd

# ---- 設定（ここだけ直せば別の表にも使える） ----
REQUIRED_COLS = ["ID", "日付", "数量", "単価"]   # 必須の列
TEXT_COLS = ["ID"]                               # 文字列で読む列（先頭の0を守る）
NUM_COLS = ["数量", "単価"]                      # 数値にする列
DATE_COLS = ["日付"]                             # 日付にする列

log = logging.getLogger("excel_tool")


class InputError(Exception):
    """入力の問題（ファイル・列・シートなど）。"""


class SaveError(Exception):
    """保存の問題（開いたまま・権限など）。"""


# ---- 1. 開く前の確認 ----
def check_input(path: Path) -> None:
    if not path.exists():
        raise InputError(f"ファイルがありません: {path}")
    if path.suffix.lower() not in (".xlsx", ".xlsm"):
        raise InputError(f"対応していない形式です（.xlsx/.xlsmのみ）: {path.suffix}")
    if path.stat().st_size == 0:
        raise InputError(f"ファイルが空です: {path}")
    if path.name.startswith("~$"):
        raise InputError("Excelのロックファイル（~$）です。元のファイルを指定してください")


# ---- 2. 読み込み ----
def load(path: Path, sheet: str | int) -> pd.DataFrame:
    try:
        # 全列を文字列で読む（列名に空白があっても先頭の0が消えない。型変換は clean() で行う）
        df = pd.read_excel(path, sheet_name=sheet, dtype=str)
    except ValueError as e:                       # シート名違いなど
        raise InputError(f"シートを読めません（{sheet}）: {e}") from e
    except PermissionError as e:
        raise InputError(f"ファイルを開けません。Excelで開いたままではありませんか: {path}") from e
    except Exception as e:                        # 壊れたファイルなど
        raise InputError(f"読み込みに失敗しました: {e}") from e

    # 列名のゆれを吸収（前後の空白・全角空白）
    df.columns = [str(c).replace("\u3000", " ").strip() for c in df.columns]
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        raise InputError(f"必須の列がありません: {missing} / 実際の列: {list(df.columns)}")

    df = df.dropna(how="all")                     # 完全な空行は捨てる
    for c in TEXT_COLS:                           # 文字列の整形
        df[c] = df[c].astype("string").str.strip()
    return df.reset_index(drop=True)


# ---- 3. 検査と型変換（不正な行は分ける） ----
def clean(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    df = df.copy()
    for c in NUM_COLS:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    for c in DATE_COLS:
        df[c] = pd.to_datetime(df[c], errors="coerce", format="mixed")   # 2026-11-01 と 2026/11/02 が混在してもOK

    reasons = pd.Series("", index=df.index)
    for c in TEXT_COLS:
        reasons += df[c].isna().map({True: f"{c}が空; ", False: ""})
    for c in NUM_COLS + DATE_COLS:
        reasons += df[c].isna().map({True: f"{c}が不正または空; ", False: ""})

    bad_mask = reasons != ""
    bad = df[bad_mask].copy()
    bad.insert(0, "元の行番号", bad.index + 2)    # Excel上の行番号（見出し=1行目）
    bad["理由"] = reasons[bad_mask]
    return df[~bad_mask].copy(), bad


# ---- 4. 計算 ----
def calculate(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    df = df.copy()
    df["金額"] = df["数量"] * df["単価"]
    summary = (
        df.groupby("ID", as_index=False)
        .agg(件数=("ID", "size"), 数量合計=("数量", "sum"), 金額合計=("金額", "sum"))
        .sort_values("金額合計", ascending=False)
    )
    return df, summary


# ---- 5. 安全に保存 ----
def save(path: Path, sheets: dict[str, pd.DataFrame]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():                              # 既存は退避してから置き換える
        backup = path.with_name(f"{path.stem}.bak_{datetime.now():%Y%m%d_%H%M%S}{path.suffix}")
        try:
            os.replace(path, backup)
            log.info("既存ファイルを退避: %s", backup.name)
        except PermissionError as e:
            raise SaveError(f"出力先を置き換えられません。Excelで開いていませんか: {path}") from e

    fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=path.parent)
    os.close(fd)
    try:
        with pd.ExcelWriter(tmp, engine="openpyxl", datetime_format="yyyy/mm/dd") as w:
            for name, frame in sheets.items():
                if frame.empty and name == "エラー行":
                    continue                        # エラーが無ければ作らない
                frame.to_excel(w, sheet_name=name[:31], index=False)   # シート名は31字まで
                ws = w.sheets[name[:31]]
                ws.freeze_panes = "A2"
                ws.auto_filter.ref = ws.dimensions
                for col in ws.columns:
                    width = max(len(str(c.value)) if c.value is not None else 0 for c in col)
                    ws.column_dimensions[col[0].column_letter].width = min(max(width + 2, 8), 40)
        os.replace(tmp, path)                       # 最後に1回だけ置き換える
    except Exception as e:
        raise SaveError(f"保存に失敗しました: {e}") from e
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


# ---- 実行 ----
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Excel処理（読込→検査→計算→保存）")
    ap.add_argument("input", type=Path)
    ap.add_argument("--sheet", default=0, help="シート名（省略時は先頭）")
    ap.add_argument("--out", type=Path, default=None, help="出力先（省略時は日付つきの別名）")
    args = ap.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    out = args.out or args.input.with_name(f"{args.input.stem}_結果_{datetime.now():%Y%m%d}.xlsx")
    if out.resolve() == args.input.resolve():
        log.error("入力と同じファイルには保存できません。別名にしてください")
        return 1

    try:
        check_input(args.input)
        df = load(args.input, args.sheet)
        good, bad = clean(df)
        log.info("読込 %d行 / 正常 %d行 / エラー %d行", len(df), len(good), len(bad))
        if good.empty:
            raise InputError("正常な行が1行もありません。エラー行の内容を確認してください")
        detail, summary = calculate(good)
        save(out, {"明細": detail, "集計": summary, "エラー行": bad})
        log.info("保存しました: %s", out)
        return 0
    except InputError as e:
        log.error("入力の問題: %s", e)
        return 1
    except SaveError as e:
        log.error("保存の問題: %s", e)
        return 2
    except Exception:                                # 想定外は内容を残して終わる
        log.exception("想定外のエラー")
        return 3


if __name__ == "__main__":
    sys.exit(main())
