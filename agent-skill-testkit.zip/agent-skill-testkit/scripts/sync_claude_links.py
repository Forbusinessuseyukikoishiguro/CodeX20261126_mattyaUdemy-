#!/usr/bin/env python3
"""`.claude/skills` を `.agents/skills` に揃える。

通常はシンボリックリンクを作る。Windowsの標準Git設定などでリンクが作れない場合はコピーに切り替える
（その場合、スキルを編集するたびに再実行が必要）。
"""
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / ".agents" / "skills"
DST = ROOT / ".claude" / "skills"


def main():
    DST.parent.mkdir(parents=True, exist_ok=True)
    if DST.is_symlink() or DST.is_file():
        DST.unlink()
    elif DST.is_dir():
        shutil.rmtree(DST)
    try:
        os.symlink(os.path.relpath(SRC, DST.parent), DST, target_is_directory=True)
        print(f"symlink: {DST} -> {os.readlink(DST)}")
    except (OSError, NotImplementedError):
        shutil.copytree(SRC, DST, ignore=shutil.ignore_patterns("__pycache__"))
        print(f"copy: {SRC} -> {DST}  (リンク不可のためコピー。編集後は再実行してください)")


if __name__ == "__main__":
    sys.exit(main())
