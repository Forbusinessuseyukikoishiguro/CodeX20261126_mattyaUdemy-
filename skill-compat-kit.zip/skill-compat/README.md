# skill-compat：Codex ⇄ Claude Code の互換変換

スキル（SKILL.md とフォルダ）を、Codex 形式と Claude Code 形式の間で、安全に変換する一式です。
既定は確認だけ（何も書かない）。`--apply` を付けたときだけ書きます。

## 使い方

```bash
python3 scripts/skill_convert.py <元のスキル> <出力先> --to claude           # 確認
python3 scripts/skill_convert.py <元のスキル> <出力先> --to claude --apply   # 書き込み
python3 scripts/skill_convert.py <元のスキル> <出力先> --to codex --apply
python3 tests/run_compat_tests.py                                              # 試験（13件）
```

## 中身

```
skill-compat/
├── SKILL.md                    入口
├── scripts/skill_convert.py    変換（BLOCK・WARN・CHANGE・DROP・NOTE・REVIEW を報告）
├── tests/run_compat_tests.py   試験（C1〜C10）
├── docs/互換性設計書.md         設計書（図解つき）・現在の仕様の全体
├── docs/images/               図（Mermaid を描画したもの）
└── examples/                  見本（Codex 形式・Claude 形式）
```

## 確認状況

| 項目 | 状況 |
|---|---|
| 変換の試験 13件 | 確認済み（Linux） |
| 実物（spec-driven-dev）の両方向の確認（確認のみ） | 確認済み |
| 変換後のスキルの実際の呼び出し（/名前・$名前） | 未確認（変換先の環境で試験する） |
| Codex のフック・Claude のサブエージェントの形式 | 未確認（公式で確認） |
| Windows での実行 | 未確認 |

## 注意

- 変換は機械的な置き換えです。変換先の環境で必ず試験してください
- Claude 専用の項目は、Codex では使えません（省いた項目は CONVERSION.md に残ります）
- 常時読まれる指示（AGENTS.md ⇄ CLAUDE.md）は、この道具では変換しません（設計書 §5.3）
