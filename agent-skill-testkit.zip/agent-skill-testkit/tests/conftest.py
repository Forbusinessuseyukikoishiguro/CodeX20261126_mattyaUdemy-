import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
SKILLS_DIR = ROOT / ".agents" / "skills"
sys.path.insert(0, str(ROOT))
