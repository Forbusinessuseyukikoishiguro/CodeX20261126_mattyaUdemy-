# excel-team-leader 使い方（v2）

Claude Code と Codex の**両方で動く**スキルです。
リーダー（AI）が判断して指示を出し、Excelの作業は Python のワーカー2人（A・B）が行います。

> うさうさ研修工房｜作成日 2026-11-25
> v2：「skill-template-v2」（ひな形）と「excel-python」（Excel処理）の内容を、役割が重ならず漏れないように（MECE）取り込みました。対応表は `references/MAP.md`。
> ※ Claude Code・Codex 上での実起動は未確認です（「確認状況」参照）。公開前に各公式ページで再確認してください。

---

## 1. 何ができるか

| やりたいこと | 手順 | 流れ |
|---|---|---|
| データを入れて、数式で計算したい | 1 | B 入力 → A 計算 → B 読み戻し |
| 既存のExcelを読んで集計し、別名で保存したい | 2 | B 検査 → B 読込・整形 → A 集計 → B 読み戻し |
| Excelを**開いたまま**更新したい | 3 | B（xlwings） |
| `.xls`・CSV を扱いたい | 4 | B 変換 → 手順2 |
| ファイルが開けるか確かめたい | 0 | B 検査 |

### チームの役割（重ならない分け方）

| 役 | 扱うもの | 実体 |
|---|---|---|
| リーダー | 判断・指示・結果確認・報告（Excelには触れない） | AI本体（このスキルを持つのはここだけ） |
| B | **ファイルの入出力**：検査・入力・読込・整形・保存・変換・開いたまま更新 | `scripts/worker_b.py` |
| A | **計算**：数式の入力・再計算・検算 | `scripts/worker_a.py` |

ワーカーは普通のPythonスクリプトです。サブエージェント機能は使わないので、Codexでも同じ動きになります。

---

## 2. 事前準備

| 必要なもの | 内容 |
|---|---|
| Python | 3.9以上 |
| pandas・openpyxl | `pip install pandas openpyxl`（pandasは2以上） |
| LibreOffice | 任意。あると再計算と検算まで行う（`soffice` コマンドが使えること）。`.xls` の変換にも使う |
| xlwings＋Excel | 任意。「開いたまま更新」を使うときだけ（Excelのある Windows / Mac）：`pip install xlwings` |
| xlrd | 任意。`.xls` の変換用（無ければLibreOfficeで変換） |

LibreOfficeが無くても動きます。その場合、A は `not_verified`（数式は入力済み・再計算は未確認）を返します。

---

## 3. まず動かしてみる（AIなしの動作確認）

作業用の空フォルダで、次を実行します。

```bash
cd 好きな作業フォルダ
python /パス/excel-team-leader/scripts/run_demo.py [ログ保存先フォルダ]
```

※ Windowsで `python` が動かないときは `py` を使ってください。

2つの場面を続けて実行します。

```
== 場面1：新規入力 → 数式で計算
[01_b_write] ok: 3行を保存
[02_a_calc] ok: 再計算・検算OK（3セル）
[03_b_read] ok: 9行を読み戻し（入力）
== 場面2：汚れた表 → 検査 → 集計
[04_b_check] ok: ... 検査を通りました
[05_b_load] warn: 読込5行 / 正常4行 / エラー1行 → clean.xlsx
[06_a_agg] ok: 再計算・検算OK（6セル）
[07_b_read] ok: 3行を読み戻し（集計）
   ['ID', '件数', '数量合計', '金額合計']
   ['002', 2, 6, 1800]
   ['001', 2, 12, 1440]
[08_b_err] ok: 2行を読み戻し（エラー行）
   [5, '003', ..., None, 80, '数量が不正または空; ']
== CSV（cp932）→ xlsx
[09_b_conv] ok: CSVを変換（文字コード cp932） → from_csv.xlsx
```

場面2の見どころ：
- 先頭が0のID（`001`）が `1` にならない
- 数量が「abc」の行は止まらず「エラー行」シートに理由つきで分かれる（`warn`）
- 日付の書き方が混在（`2026-11-01` と `2026/11/02`）していても読める

作業フォルダの中に `work/`（結果と、リーダーの指示書の例 `work/tasks/*.json`）ができます。

---

## 4. スキルとして置く

正本は1か所だけに置き、もう一方はシンボリックリンクにします（二重管理を防ぐため）。

### Mac / Linux

```bash
# プロジェクト直下に skills/ を作り、zipを展開
unzip excel-team-leader.zip -d skills/

mkdir -p .claude/skills .agents/skills
ln -s ../../skills/excel-team-leader .claude/skills/excel-team-leader
ln -s ../../skills/excel-team-leader .agents/skills/excel-team-leader
```

### Windows

シンボリックリンクに権限が必要な場合があります。難しければ**コピー運用**でも構いません。

```
.claude\skills\excel-team-leader\   ← フォルダごとコピー
.agents\skills\excel-team-leader\   ← フォルダごとコピー
```

コピー運用では、直したときに両方を更新してください。

### 置き場所の一覧

| | Claude Code | Codex |
|---|---|---|
| プロジェクト | `.claude/skills/` | `.agents/skills/` |
| 個人 | `~/.claude/skills/` | `$HOME/.agents/skills/` |

---

## 4.5 フォルダ構成

```
excel-team-leader/
├── SKILL.md              必須。リーダーの判断ルールと手順
├── README.md             このファイル
├── scripts/
│   ├── worker_b.py       B：入出力（check / write_input / load_clean / read_back / convert / live_update）
│   ├── worker_a.py       A：計算（add_formulas / aggregate）
│   ├── teamcore.py       共通：指示JSON・終了コード・エラー分類
│   ├── teamlog.py        共通：ログの書き込み・表示（保存先は任意）
│   ├── check_xlsx.py     B の部品：検査（単体のコマンドとしても使える）
│   ├── xl_io.py          B の部品：読込・型変換・エラー行分離・安全な保存・CSV/.xls変換
│   ├── xl_live.py        B の部品：開いたまま更新（xlwings）
│   └── run_demo.py       AIなしの動作確認
├── references/
│   ├── TEAM.md           指示JSON・出力・終了コード
│   ├── ERRORS.md         よくあるエラーと対策
│   └── MAP.md            役割分担（MECE）と取り込み元の対応表
└── agents/
    └── openai.yaml       Codex専用の設定（Claude Codeでは使われない）
```

`SKILL.md` の frontmatter は Agent Skills 標準の項目だけ（`name` `description` `license` `compatibility` `metadata`）です。Claude/Codex固有の設定を混ぜていないので、どちらでも読めます。

---

## 5. AIに頼む

### 呼び出し方

| | 明示的に呼ぶ | 自動で選ばれる |
|---|---|---|
| Claude Code | `/excel-team-leader` | description に合う依頼をしたとき |
| Codex | `$excel-team-leader` | description に合う依頼をしたとき |

### 頼み方の例

```
/excel-team-leader
sales.xlsx を読んで、IDごとの件数・数量合計・金額合計を集計して、別名で保存して。
```

```
/excel-team-leader
report.xlsx を Excel で開いたまま、「データ」シートに次の表を書き込んで。
```

自動で選ばれるか試すときは、スキル名を出さずに頼みます。

```
このCSVをExcelにして、IDごとに金額を集計して
```

### リーダー（AI）の動き

1. **判断する**：「最初に判断する」の表で、状況に合う手順を1つ選びます。ファイルがあれば**まず検査（手順0）**。
   - データが無い／列の意味が曖昧 → 質問を1つだけして止まる（推測で埋めない）
2. **指示を書く**：`work/tasks/` にタスクJSONを書きます。
3. **ワーカーを順に実行**します。
4. **各ワーカーの `status` を確認**します。`ng` なら次へ進まず、`message` を報告して止まります。
5. **完了報告**：やったこと／出力ファイル名／処理行数とエラー行数／未確認の点／次に確認すること。

---

## 6. 手で動かす（タスクJSONを自分で書く）

AIを使わず、ワーカーを直接呼ぶこともできます。

```bash
python scripts/worker_b.py work/tasks/04_b_check.json
```

指示JSON（全action）の一覧と、出力の読み方・終了コードは **`references/TEAM.md`** にまとめています。主な例だけ載せます。

### 検査（B check）

```json
{"action":"check","file":"work/raw.xlsx","sheet":"Sheet1","require":["ID","日付","数量","単価"]}
```
存在・形式・ロックファイル・シート・必須列を調べます。NGなら理由つきで止まります。

### 読込→整形→別名で保存（B load_clean）

```json
{
  "action": "load_clean",
  "input": "work/raw.xlsx", "sheet": "Sheet1", "out": "work/clean.xlsx",
  "required_cols": ["ID","日付","数量","単価"],
  "text_cols": ["ID"], "num_cols": ["数量","単価"], "date_cols": ["日付"]
}
```
- 入力ファイルは**読み取りのみ**。入力と同じ名前の出力は拒否します
- 既存の出力ファイルがあれば `.bak_日時` に退避してから、一時ファイル経由で置き換えます
- 別の表で使うときは、スクリプトを書き換えず、この列名の指定だけ変えます

### 集計（A aggregate）

```json
{"action":"aggregate","file":"work/clean.xlsx","sheet":"明細","recalc":true}
```
「金額」列とID別の「集計」シート（件数・数量合計・金額合計）を**数式で**作り、再計算して検算します。

### 開いたまま更新（B live_update）

```json
{"action":"live_update","file":"report.xlsx","sheet":"データ","headers":["ID","金額"],"rows":[["001",200],["002",1000]]}
```
Excelで開いているブックに書き込みます（Excelのある Windows / Mac）。書けなければ日付つきの別ファイルに保存し、`status` は `warn` になります。**実機では未検証**なので、まずテスト用のファイルで試してください。

### 出力の読み方

| status | 意味 | 終了コード |
|---|---|---|
| `ok` | 成功（A は検算も一致） | 0 |
| `warn` | 完了したが注意あり（エラー行あり・別ファイルに保存） | 0 |
| `not_verified` | 数式は入ったが再計算を確認できていない | 0 |
| `ng` | 失敗。`kind` に分類 | 1=入力の問題・検算NG／2=保存の問題／3=想定外 |

---

## 6.5 ログ

### 何が残るか

ワーカーが動くたびに、自動で1行ずつ記録されます。

```
2026-11-25 12:17:14 | INFO | leader   | デモ開始
2026-11-25 12:17:14 | INFO | worker_b | 開始 action=write_input file=work/sales.xlsx
2026-11-25 12:17:14 | OK   | worker_b | 3行を保存
2026-11-25 12:17:16 | OK   | worker_a | 再計算・検算OK
```

- **ファイル名**：`YYYYMMDDHHMM_log.txt`（例：`202611251217_log.txt`）。日時の形式は `scripts/teamlog.py` の `NAME_FORMAT` で変えられます（秒まで要るなら `%Y%m%d%H%M%S`）。
- **ステータス**：`INFO`（開始など）／`OK`／`WARN`（`not_verified`）／`NG`
- **1回の実行を1ファイルにまとめる**：ファイル名は「書いた時刻の分」で決まるので、またぐと別ファイルになります。環境変数 `TEAM_LOG_STAMP` を決めておくと固定できます（`run_demo.py` はこれを使っています）。

### 保存先を任意の場所にする（優先順）

| 方法 | 例 |
|---|---|
| ① Pythonの引数 | `teamlog.write("OK", "保存した", "worker_b", "D:/logs")` |
| ② タスクJSONの `log_dir` | `{"action":"read_back","file":"...","log_dir":"D:/logs"}` |
| ③ 環境変数 `TEAM_LOG_DIR` | Mac/Linux：`export TEAM_LOG_DIR=/var/log/excel-team` ／ Windows：`set TEAM_LOG_DIR=D:\logs` |
| ④ 何も指定しない | `work/logs/` |

デモで試す：`python scripts/run_demo.py D:/logs/excel-team`

### Pythonで好きな場所にログを入れるサンプル

```python
import sys
sys.path.insert(0, "scripts")   # teamlog.py のあるフォルダ
import teamlog

# 任意の場所へ1行追記（保存先フォルダが無ければ作る）
p = teamlog.write("INFO", "集計を開始", worker="my_script", log_dir="D:/logs/excel-team")
teamlog.write("OK", "5件を保存", worker="my_script", log_dir="D:/logs/excel-team")
teamlog.write("NG", "列数が合わない", worker="my_script", log_dir="D:/logs/excel-team")
print(p)   # 書き込み先のパス。書けなかったときは None（処理は止まらない）
```

自分のワーカーを足すときも、`finish()` の中で `teamlog.write(...)` を呼べば同じ形式で残ります（`worker_a.py` / `worker_b.py` を参考に）。

### コマンドで書く・見る（リーダー向け）

```bash
# 書く
python scripts/teamlog.py write --status INFO --message "指示を出した" --worker leader --log-dir D:/logs/excel-team

# 最新ログの末尾20行を見る
python scripts/teamlog.py show --log-dir D:/logs/excel-team

# NG だけ見る
python scripts/teamlog.py show --log-dir D:/logs/excel-team --status NG
```

> ログを書けなかった（権限・ディスクなど）ときは、標準エラーに警告を出すだけで、Excelの処理は続けます。

---

## 7. うまくいかないとき

エラー全般の対策は **`references/ERRORS.md`**（原因・対策・担当の表）にあります。このスキルでよく出るものだけ載せます。

| 症状 | 原因と対処 |
|---|---|
| `not_verified: soffice無し` | LibreOfficeが未インストール、またはPATHに無い。入れるか、未確認のまま使う |
| `ng(input): 必須の列がありません` | 見出し名が違う。`required_cols` を表に合わせるか、見出しを直す |
| `ng(input): ファイルを開けません。Excelで開いたまま…` | Excelを閉じる。または手順3（開いたまま更新）／別名で保存 |
| `ng(save): 出力先を置き換えられません` | 出力先のExcelが開いている。閉じるか、別の出力名にする |
| `warn: …エラー1行` | 不正な行は「エラー行」シートに理由つきで分かれている。確認して元データを直す |
| `ng(verify): 検算が不一致` | 数式の範囲などが違う。`message` の（実際,期待）を見る |
| `ModuleNotFoundError` | `pip install pandas openpyxl`（開いたまま更新は `xlwings`） |
| スキルが一覧に出ない | 置き場所と、フォルダ名＝`name`（excel-team-leader）を確認。Codexは出ないときだけ再起動 |
| 自動で起動しない | 本文ではなく **description** を直す（起動は description で決まる） |
| ログが見つからない | 保存先の優先順（6.5）を確認。指定が無ければ、実行したフォルダの `work/logs/` |
| 想定外の場所に `work/` ができる | ワーカーは**実行したフォルダ**基準で `work/` を作る。作業フォルダに移動してから実行する |

---

## 8. 自分用に作り変える

### 別の表で使う

`load_clean` の列名指定（`required_cols` など）を指示JSONで変えます。スクリプトは直しません。

### 計算内容を変える

`scripts/worker_a.py` に関数を足します（例：割引率、部門別集計）。入出力はBに任せたままで済みます。

### 動作（action）を増やす

1. ワーカーに関数を足す（`dict` を受け取り、`{"status": ..., "message": ...}` を返す。入力の問題は `InputError`、保存の問題は `SaveError` を `raise` する）
2. 末尾の `ACTIONS` に登録する
3. `references/TEAM.md` に指示JSONの形式を書く

どちらのワーカーに置くかは `references/MAP.md` の判定の目安（「ファイルを扱う→B／数式・計算→A」）に従うと、役割が重なりません。

### 固有の設定を足す

| やりたいこと | 書く場所 |
|---|---|
| Claude Code：手動 `/name` のときだけ動かす | `SKILL.md` の frontmatter に `disable-model-invocation: true` |
| Codex：自動起動を止める | `agents/openai.yaml` の `policy.allow_implicit_invocation: false` |

⚠ `SKILL.md` に独自キーを足すと、claude.ai へのアップロードや Skills API では**エラー**になります。アップロードするなら標準の項目だけにしてください。

---

## 9. 確認状況

| 項目 | 状況 |
|---|---|
| `run_demo.py`（場面1・場面2・CSV変換、再計算、検算） | 確認済み（Linux・LibreOffice あり） |
| 先頭0のID・日付混在・不正行の分離 | 確認済み |
| 「001」と「1」を別IDとして集計 | 確認済み |
| `aggregate` を2回実行しても列・シートが増えない | 確認済み |
| エラーの分類（入力=1／保存=2／想定外=3、指示JSON不足、シート違い、壊れたファイル） | 確認済み |
| `.xls` の変換（LibreOffice経由） | 確認済み |
| ログ出力（任意の保存先・JSON指定・CLI書き込み・NG絞り込み表示） | 確認済み（Linux上） |
| 開いたまま更新：xlwings が無いとき別ファイルに保存（`warn`） | 確認済み |
| **開いたまま更新：実際のExcel（Windows / Mac）への書き込み** | **未確認** |
| LibreOffice 無しで `not_verified` になる | **未確認** |
| `.xls` の変換（xlrd経由） | **未確認** |
| Windows のパス（`D:\logs`）へのログ出力 | **未確認** |
| Claude Code での明示呼び出し（`/excel-team-leader`） | **未確認** |
| Codex での明示呼び出し（`$excel-team-leader`） | **未確認** |
| 暗黙の起動／「使わない場面」で起動しない | **未確認** |
| `agents/openai.yaml` の書き方 | 資料の記載をもとにした。**未確認** |

公開前に、次のテスト4種類を両方で行ってください。

| テスト | 方法 |
|---|---|
| 明示呼び出し | Claude `/excel-team-leader`、Codex `$excel-team-leader` |
| 暗黙の起動 | スキル名を出さず、descriptionに近い依頼を投げる |
| 外すテスト | Word・PDFの作成など、description の「使わない場面」で起動しないこと |
| 構文チェック | `skills-ref validate ./excel-team-leader` |

---

## 10. 注意

- `write_input` / `add_formulas` / `aggregate` は指定された `file` を**その場で更新**します。大事なExcelは必ずコピーを渡してください（`load_clean` は入力を読むだけで、別名の出力に保存します）。
- リーダーは元ファイルを直接編集せず、`work/` の中で作業する決まりです。
- 起動の判断は description だけで決まります。効かないときは description を直します。
- 製品の仕様は変わりやすいため、公式ページで再確認してください。
  - agentskills.io/specification
  - code.claude.com/docs/en/skills
  - developers.openai.com/codex/skills


---

## 11. v3 の変更点（直接更新と試験）

- **直接更新**：既存Excelの「入力セル」だけを書いて保存する `update_cells` を追加（Excel不要）。
  - 更新してよい範囲を必ず指定。数式セル・範囲外・結合の2つ目は書かない
  - 保存前にバックアップ、保存は一時ファイル経由、保存後に全セル照合
  - グラフなどがあれば既定で止まる（`allow_loss` で了承したときだけ続行）
- **試験**：`python tests/run_tests.py` で16件（正常・拒否・日付・保存不可・既存の検査）。Excelは不要。
- **試験の手順**：`references/TESTING.md`（業務レベルの試験項目、仕様の書き方、記録様式）。

確認状況（v3 追加分）：

| 項目 | 状況 |
|---|---|
| `update_cells` の試験16件 | 確認済み（Linux・LibreOffice あり） |
| `run_demo.py`（既存機能の回帰） | 確認済み |
| 保存不可（権限）の試験 | 未確認（root 実行では省略される） |
| Excel（Windows / Mac）で開いたままの更新（`live_update`） | 未確認（従来どおり） |
| Claude Code / Codex での起動 | 未確認（従来どおり） |


---

## 12. v3.1 の変更点（複数シートの統合）

- **統合**：複数のファイル・複数のシートを、列名で揃えて1つの表にする `merge_sheets` を追加。
  - 「統合」は元ファイル・元シート・元の行番号つき。「統合サマリ」はシートごとの行数と合計
  - 列の並びが違うシートも正しく揃う。列が欠けたシートは warn で知らせる
- **検証用サンプル**：`samples/` に2ファイル（東京・大阪、各2シート）。合計は10,540円、9行（`samples/README.md`）
- **試験**：`python tests/run_tests.py` で29件（直接更新16件＋統合13件）

確認状況（v3.1 追加分）：

| 項目 | 状況 |
|---|---|
| 統合（J〜O）、サンプル2ファイルの統合結果 | 確認済み（Linux） |
| 列が欠けたシートの warn（L） | 確認済み |
| 数式入りのシートを統合する場合 | 注意（計算結果が読めない）。未確認の運用 |


---

## 13. v3.2 の変更点（大量データの検証）

- **検証データの生成**：`tests/gen_testdata.py` で、ファイル数・タブ数・行数・列数を指定して Excel と正解（expected.json）を作る。乱数の種を固定するので再現できる
- **大規模試験**：`tests/run_scale.py` で、統合の行数（全体・タブごと）、数値列の合計、列数、複雑な数式（SUMIFS・COUNTIFS・AVERAGEIFS・SUMPRODUCT・IFERROR・構成比・ROUND）、処理時間を確かめる

確認状況（v3.2 追加分）：

| 項目 | 状況 |
|---|---|
| 3ファイル×3タブ×約2,000行×12列 | 確認済み（12件合格、約21秒） |
| 4ファイル×4タブ×約5,000行×30列（約240万セル） | 確認済み（12件合格、合計約163秒） |
| メモリ使用量 | 未計測 |
| 実機のExcelで開いたときの表示 | 未確認 |


---

## 14. v3.3 の変更点（顧客対応・にゃんこのお知らせ）

- **リーダーは顧客対応担当**：話し方と報告の型を `references/SUPPORT.md` にまとめた
- **聞き返し**：指示が足りないと、処理せずに質問を返す（推測で埋めない）
- **にゃんこのお知らせ**：処理中・進捗・残り時間・完了を標準エラーに出す。残り時間は実測の速さから計算し、計算できないときは「まだ計算中」
- **エラーの説明**：原因の分類・原因のめやす・やってみてほしいこと・ログの場所を返す。`diagnose.py` で単独でも判定できる
- **試験**：`python tests/run_support.py` で22件

確認状況（v3.3 追加分）：

| 項目 | 状況 |
|---|---|
| にゃんこのお知らせ・残り時間・聞き返し・エラーの原因とログ（22件） | 確認済み（Linux） |
| 既存の試験（直接更新・統合：29件、大規模：12件） | 確認済み（回帰なし） |
| 残り時間の精度（大きなデータでの実測との差） | 未確認 |
| 実際のチャット画面での表示 | 未確認 |


---

## 15. v3.4 の変更点（話し方の選択）

- **3つの話し方**：にゃんこ版（既定）・秘書版（丁寧なビジネス敬語）・ですます版（やわらかい丁寧語）
- **選び方**：指示JSONの `voice`、または環境変数 `TEAM_VOICE`。未知の名前はにゃんこ版
- **結果は同じ**：話し方は、お知らせの言葉だけを変える。結果のJSONと数字は同じ
- **原因の判定を追加**：出力先に数字を入れたときの「ファイル名の指定が文字ではない」

確認状況（v3.4 追加分）：

| 項目 | 状況 |
|---|---|
| 話し方の試験（18件） | 確認済み（Linux） |
| 既存の試験（直接更新・統合29件、大規模12件、対応力22件） | 確認済み（回帰なし） |
| 秘書版・ですます版の言葉づかいの自然さ | 確認済み（人の目での最終確認は未実施） |
