#!/usr/bin/env python3
"""話し方の試験：にゃんこ版・秘書版・ですます版。どれも結果は同じで、言葉だけが変わる。

使い方: python tests/run_voice.py [作業フォルダ]    終了コード: 0=全部合格 / 1=不合格あり
  V1 既定はにゃんこ版（指定なし）
  V2 秘書版（指示の voice）：秘書の言葉が出て、猫の言葉（にゃ・ニャ）が出ない
  V3 ですます版（環境変数 TEAM_VOICE）：お知らせの言葉が出て、猫の言葉が出ない
  V4 未知の話し方はにゃんこ版に戻る
  V5 秘書版のエラー：丁寧な謝罪・ログの保存先が出る
  V6 ですます版のエラー：エラーの発生・ログの場所が出る
  V7 秘書版の進捗：段階ごとの完了率が出る
  V8 ですます版の完了：完了しました が出る
  V9 話し方を変えても、標準出力は結果のJSON1行だけ（中身は同じ）
  V10 秘書版の聞き返し
  V11 残り時間の言葉：3つの話し方で、同じ見積もり（6分）を表す
"""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
import nyanko  # noqa: E402

WORK = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "work" / "voice"
CAT = ("にゃ", "ニャ")
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))


def run(task, tag, env_voice=None):
    WORK.mkdir(parents=True, exist_ok=True)
    tf = WORK / f"{tag}.json"
    tf.write_text(json.dumps(task, ensure_ascii=False), encoding="utf-8")
    env = dict(os.environ, TEAM_LOG_DIR=str(WORK / "logs"), PYTHONIOENCODING="utf-8")
    env.pop("TEAM_VOICE", None)
    if env_voice is not None:
        env["TEAM_VOICE"] = env_voice
    cp = subprocess.run([sys.executable, str(SCRIPTS / "worker_b.py"), str(tf)],
                        capture_output=True, text=True, env=env, encoding="utf-8")
    lines = [l for l in cp.stdout.splitlines() if l.strip()]
    try:
        res = json.loads(lines[-1]) if lines else {}
    except ValueError:
        res = {}
    return cp.returncode, res, cp.stdout, cp.stderr


def merge_task(out, sources=None, **extra):
    t = {"action": "merge_sheets", "out": str(WORK / out),
         "sources": sources or [{"file": str(ROOT / "samples" / "東京_売上.xlsx"), "sheets": "*"},
                                {"file": str(ROOT / "samples" / "大阪_売上.xlsx"), "sheets": "*"}]}
    t.update(extra)
    return t


def has_cat(text):
    return any(c in text for c in CAT)


def main():
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir(parents=True)

    code, res, out, err = run(merge_task("v1.xlsx"), "v1")
    check("V1 既定はにゃんこ版", "にゃんこ：" in err and has_cat(err))

    code, res, out, err = run(merge_task("v2.xlsx", voice="secretary"), "v2")
    check("V2 秘書版：秘書の言葉が出る", "秘書：" in err and "いたします" in err, err[:80])
    check("V2 秘書版：猫の言葉が出ない", not has_cat(err))

    code, res, out, err = run(merge_task("v3.xlsx"), "v3", env_voice="desu_masu")
    check("V3 ですます版（環境変数）：お知らせの言葉が出る", "お知らせ：" in err)
    check("V3 ですます版：猫の言葉が出ない", not has_cat(err))

    code, res, out, err = run(merge_task("v4.xlsx", voice="unknown_voice"), "v4")
    check("V4 未知の話し方はにゃんこ版に戻る", "にゃんこ：" in err)

    # V5 秘書版のエラー
    code, res, out, err = run({**merge_task("v5.xlsx"), "out": 123}, "v5", env_voice="secretary")
    check("V5 秘書版のエラー：丁寧な謝罪とログの保存先",
          "申し訳ございません" in err and "ログの保存先" in err, err[:80])
    check("V5 秘書版のエラー：猫の言葉が出ない", not has_cat(err))

    # V6 ですます版のエラー
    code, res, out, err = run({**merge_task("v6.xlsx"), "out": 123}, "v6", env_voice="desu_masu")
    check("V6 ですます版のエラー：エラーの発生とログの場所",
          "エラーが発生しました" in err and "ログの場所" in err)
    check("V6 ですます版のエラー：猫の言葉が出ない", not has_cat(err))

    # V7 秘書版の進捗
    code, res, out, err = run(merge_task("v7.xlsx", voice="secretary"), "v7")
    check("V7 秘書版の進捗：段階ごとの完了率", "統合：1/4 完了（25%）" in err and "統合：4/4 完了（100%）" in err, err[:120])

    # V8 ですます版の完了
    check("V8 ですます版の完了：完了しました", "完了しました" in run(merge_task("v8.xlsx"), "v8", env_voice="desu_masu")[3])

    # V9 話し方を変えても標準出力は JSON 1行、結果は同じ
    rows = [run(merge_task(f"v9_{v}.xlsx", voice=v), f"v9{v}")[1].get("rows") for v in ("nyanko", "secretary", "desu_masu")]
    stdout_lines = run(merge_task("v9o.xlsx", voice="desu_masu"), "v9o")[2].strip().splitlines()
    check("V9 話し方が違っても結果（行数）は同じ", len(set(rows)) == 1 and rows[0] == 9, str(rows))
    check("V9 標準出力は結果のJSON1行だけ", len(stdout_lines) == 1 and json.loads(stdout_lines[0])["status"] == "ok")

    # V10 秘書版の聞き返し
    code, res, out, err = run({"action": "update_cells", "file": str(WORK / "none.xlsx"),
                               "edits": [{"sheet": "データ", "cell": "B2", "value": 1}]}, "v10", env_voice="secretary")
    check("V10 秘書版の聞き返し", "確認させていただきたい点がございます" in err and code == 1, err[:80])

    # V11 残り時間の言葉（同じ見積もり：120秒で1/4 → 約6分）
    saved = nyanko.voice()
    vals = {}
    for v in nyanko.VOICES:
        nyanko.set_voice(v)
        vals[v] = nyanko.eta_text(120, 1, 4)
    nyanko.set_voice(saved)
    check("V11 残り時間：にゃんこ版は「後6分」", "後6分" in vals["nyanko"], vals["nyanko"])
    check("V11 残り時間：秘書版は「6分」", "6分" in vals["secretary"], vals["secretary"])
    check("V11 残り時間：ですます版は「6分」", "6分" in vals["desu_masu"], vals["desu_masu"])

    width = max(len(n) for n, _, _ in results)
    print("== 話し方の試験（にゃんこ・秘書・ですます）")
    for name, ok, detail in results:
        print(f"[{'OK' if ok else 'NG'}] {name.ljust(width)}  {'' if ok else detail}")
    failed = [r for r in results if not r[1]]
    print(f"合計 {len(results)} 件 / 合格 {len(results) - len(failed)} / 不合格 {len(failed)}")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
