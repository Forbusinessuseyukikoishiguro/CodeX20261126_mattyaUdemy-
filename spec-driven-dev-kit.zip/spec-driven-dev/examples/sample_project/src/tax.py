"""税込金額の計算（サンプル。設計書 spec/設計書.md の FR-001〜FR-003）。"""
from decimal import Decimal, ROUND_HALF_UP


def tax_included(amount_yen: int, rate: float) -> int:
    """税抜金額（円・整数）と税率（0.0〜1.0）から、税込金額（円・整数）を返す。"""
    if isinstance(amount_yen, bool) or not isinstance(amount_yen, int) or amount_yen < 0:
        raise ValueError("金額は0以上の整数（円）で指定してください")
    if not (0.0 <= rate <= 1.0):
        raise ValueError("税率は0%以上100%以下で指定してください")
    total = Decimal(amount_yen) * (Decimal(1) + Decimal(str(rate)))
    return int(total.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
