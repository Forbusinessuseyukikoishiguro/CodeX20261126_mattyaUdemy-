#!/usr/bin/env python3
"""聞き返し：指示に足りないものがあれば、処理を始める前に質問を返す。推測で埋めない。"""
from __future__ import annotations


def questions_for(task: dict) -> list[str]:
    """足りない項目の質問一覧。空なら、そのまま実行してよい。"""
    act = task.get("action")
    q: list[str] = []
    if act == "merge_sheets":
        if not task.get("sources"):
            q.append("統合したいファイルはどれですか？（ファイル名かパスを教えてください）")
        if not task.get("out"):
            q.append("統合結果の保存名はどうしますか？（例：統合売上.xlsx）")
    elif act == "update_cells":
        if not task.get("inputs"):
            q.append("書き込んでよい範囲はどこですか？（例：データ!B2:C4）。範囲の外には書きません")
        if not task.get("edits") and not task.get("blocks"):
            q.append("どのセルに、どんな値を書きますか？")
    elif act == "write_input":
        if not task.get("headers"):
            q.append("表の見出し（列名）を教えてください")
        if not task.get("rows"):
            q.append("入れるデータを教えてください")
    elif act == "load_clean":
        if not task.get("input"):
            q.append("読み込むExcelファイルはどれですか？")
        if not task.get("out"):
            q.append("整形後の保存名はどうしますか？")
    elif act in ("check",):
        if not task.get("file"):
            q.append("調べるファイルはどれですか？")
    elif act == "live_update":
        if not task.get("file"):
            q.append("開いたまま更新するファイルはどれですか？")
        if not task.get("headers") or not task.get("rows"):
            q.append("書き込む見出しと行のデータを教えてください")
    elif act is None:
        q.append("何をしたいですか？（集計・統合・直接更新・検査 のどれか）")
    return q
