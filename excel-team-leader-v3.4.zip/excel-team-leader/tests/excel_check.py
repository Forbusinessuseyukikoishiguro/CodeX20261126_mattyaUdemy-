#!/usr/bin/env python3
"""Excel加工結果の自動検査。判断はせず、仕様（spec.json）との一致だけを確かめる。

使い方: python excel_check.py 元.xlsx 加工後.xlsx spec.json
検査: シートの有無 / データ行数 / 合計（控え数値との一致） /
      保護範囲の値・数式が元と同じか / エラー値 / 再計算されていない数式
終了コード: 0 = 合格, 1 = 不合格, 2 = 使い方の誤り
"""
import json
import sys

from openpyxl import load_workbook
from openpyxl.utils import column_index_from_string

ERROR_VALUES = {"#REF!", "#DIV/0!", "#VALUE!", "#NAME?", "#N/A", "#NUM!", "#NULL!"}


def count_rows(ws, header_row, stop_at_blank=True):
    """データ行数。既定は見出しの次の行から、最初の空行までを数える（合計行より下は数えない）。"""
    n = 0
    for row in ws.iter_rows(min_row=header_row + 1):
        if any(c.value not in (None, "") for c in row):
            n += 1
        elif stop_at_blank and n > 0:
            break
    return n


def column_sum(ws, col_letter, header_row):
    """数値の合計と、値が計算されていない数式の件数を返す。"""
    idx = column_index_from_string(col_letter)
    total, uncomputed = 0.0, 0
    for r in range(header_row + 1, ws.max_row + 1):
        v = ws.cell(row=r, column=idx).value
        if v is None:
            continue
        if isinstance(v, (int, float)):
            total += v
        elif isinstance(v, str) and v.startswith("="):
            uncomputed += 1
    return total, uncomputed


def main(orig_path, proc_path, spec_path):
    spec = json.load(open(spec_path, encoding="utf-8"))
    f_orig = load_workbook(orig_path)                  # 数式（元）
    f_proc = load_workbook(proc_path)                  # 数式（加工後）
    v_proc = load_workbook(proc_path, data_only=True)  # 計算済みの値（加工後）
    results = []  # (ok, 文言)

    def rec(ok, text):
        results.append((bool(ok), text))

    # 1. シートの有無
    for name in spec.get("sheets_required", []):
        rec(name in v_proc.sheetnames, f"シート「{name}」がある")

    # 2. データ行数
    for rc in spec.get("row_counts", []):
        sheet = rc["sheet"]
        if sheet not in v_proc.sheetnames:
            rec(False, f"行数：シート「{sheet}」がない")
            continue
        n = count_rows(v_proc[sheet], rc.get("header_row", 1), rc.get("stop_at_blank", True))
        rec(n == rc["expected"], f"「{sheet}」のデータ行数 = {n}（期待 {rc['expected']}）")

    # 3. 合計（業務担当者の控え数値と比較）
    for cs in spec.get("control_sums", []):
        sheet = cs["sheet"]
        if sheet not in v_proc.sheetnames:
            rec(False, f"合計：シート「{sheet}」がない")
            continue
        total, uncomputed = column_sum(v_proc[sheet], cs["column"], cs.get("header_row", 1))
        tol = cs.get("tolerance", 0)
        rec(abs(total - cs["expected"]) <= tol,
            f"「{sheet}」{cs['column']}列の合計 = {total:,.2f}（期待 {cs['expected']:,}）")
        if uncomputed:
            rec(False, f"「{sheet}」{cs['column']}列に、再計算されていない数式が {uncomputed} 件")

    # 4. 保護範囲：値と数式が元と同じか
    for p in spec.get("protected", []):
        sheet, rng = p["sheet"], p["range"]
        if sheet not in f_orig.sheetnames or sheet not in f_proc.sheetnames:
            rec(False, f"保護範囲：シート「{sheet}」がない")
            continue
        diffs = []
        for row in f_orig[sheet][rng]:
            for c in row:
                if c.value != f_proc[sheet][c.coordinate].value:
                    diffs.append(c.coordinate)
        ok = not diffs
        detail = "" if ok else "（差分: " + ", ".join(diffs[:5]) + (" ほか" if len(diffs) > 5 else "") + "）"
        rec(ok, f"保護範囲「{sheet}!{rng}」が元と同じ{detail}")

    # 5. エラー値・未計算の数式（全シート）
    if spec.get("error_scan", True):
        errors, uncomputed = [], []
        for ws in f_proc.worksheets:
            wv = v_proc[ws.title]
            for row in ws.iter_rows():
                for c in row:
                    val = wv[c.coordinate].value
                    if isinstance(c.value, str) and c.value.startswith("="):
                        if val is None:
                            uncomputed.append(f"{ws.title}!{c.coordinate}")
                        elif isinstance(val, str) and val in ERROR_VALUES:
                            errors.append(f"{ws.title}!{c.coordinate}({val})")
                    elif isinstance(val, str) and val in ERROR_VALUES:
                        errors.append(f"{ws.title}!{c.coordinate}({val})")
        rec(not errors, "エラー値がない" + ("" if not errors else "：" + ", ".join(errors[:5])))
        rec(not uncomputed, "数式はすべて計算済み（再計算の必要なし）"
            if not uncomputed else f"未計算の数式が {len(uncomputed)} 件（xlsx の recalc.py を実行する）")

    print(f"検査: {proc_path}（元: {orig_path}）")
    for ok, text in results:
        print(("[OK] " if ok else "[NG] ") + text)
    passed = all(ok for ok, _ in results)
    print("判定: " + ("合格" if passed else "不合格"))
    return 0 if passed else 1


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(*sys.argv[1:]))
