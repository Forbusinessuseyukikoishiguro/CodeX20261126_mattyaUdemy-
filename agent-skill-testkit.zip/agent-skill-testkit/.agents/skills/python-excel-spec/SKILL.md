---
name: python-excel-spec
description: Excelファイル(.xlsx)のセルを読み書きし、シート一覧を取得する。「xlsxを作成/編集/確認したい」「セルに値を書き込みたい」ときに使う。
compatibility: Python 3.10+ と openpyxl が必要。
metadata:
  version: "1.0"
---

# python-excel-spec

`scripts/excel_tool.py` を実行して .xlsx を操作する。自分で openpyxl のコードを書かず、必ずこのスクリプトを使うこと。

## 使い方

```
python scripts/excel_tool.py write <file> <cell> <value> [--sheet Sheet1] [--as str|int|float]
python scripts/excel_tool.py read <file> <cell> [--sheet Sheet1]
python scripts/excel_tool.py sheets <file>
```

- `<file>` が存在しなければ `write` が新規作成する。
- 成功時は JSON を標準出力に出して終了コード 0。
- 失敗時は `{"ok": false, "error": ...}` を標準エラーに出して終了コード 1。
- 書き込んだ後は `read` で読み戻し、値が一致することを確認してから完了を報告する。

スクリプトのパスは、この SKILL.md があるディレクトリからの相対パス（`scripts/excel_tool.py`）。
