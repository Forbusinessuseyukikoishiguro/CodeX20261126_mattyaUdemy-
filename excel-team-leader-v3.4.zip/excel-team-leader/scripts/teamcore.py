#!/usr/bin/env python3
"""ワーカー共通の土台：タスクJSONの読込・聞き返し・ログ・にゃんこのお知らせ・エラー説明・終了コード。

終了コード: 0=成功(ok/warn/not_verified) / 1=入力の問題・検算NG・聞き返し / 2=保存の問題 / 3=想定外
標準出力: 結果のJSONを1行だけ（機械が読む）。お知らせ・エラー説明は標準エラーに出す。
"""
import json
import os
import sys
import time
from pathlib import Path

import diagnose
import nyanko
import support
import teamlog

_T0 = time.time()


class InputError(Exception):
    """入力の問題（ファイル・列・シート・指示JSONの不足など）。"""


class SaveError(Exception):
    """保存の問題（開いたまま・権限など）。"""


def _finish(worker, result, code, log_dir, label=""):
    st = result.get("status", "info")
    msg = result.get("message", "")
    if st == "ng":
        e = diagnose.explain(msg, result.get("kind"))
        result.setdefault("category", e["category"])
        result.setdefault("hint", e["hint"])
        result.setdefault("fix", e["fix"])
    p = teamlog.write(st, msg, worker, log_dir)
    if p:
        result["log_file"] = str(p)
    print(json.dumps(result, ensure_ascii=False, default=str))
    if st == "ng":
        if result.get("questions"):
            nyanko.ask(result["questions"])
        else:
            nyanko.ng(msg, result.get("hint", ""), result.get("fix", ""), result.get("log_file"))
    elif st == "warn":
        nyanko.warn(msg)
        nyanko.done(label or worker, time.time() - _T0)
    else:
        nyanko.done(label or worker, time.time() - _T0)
    sys.exit(code)


def main(worker, actions):
    # 話し方は指示の "voice"、なければ環境変数 TEAM_VOICE、どちらも無ければにゃんこ版
    voice_name = None
    if len(sys.argv) == 2:
        try:
            voice_name = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")).get("voice")
        except (OSError, ValueError, AttributeError):
            voice_name = None
    nyanko.set_voice(voice_name or os.environ.get("TEAM_VOICE"))
    nyanko.start(worker)
    if len(sys.argv) != 2:
        _finish(worker, {"status": "ng", "kind": "input", "message": f"使い方: {worker}.py task.json"}, 1, None)
    try:
        task = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        _finish(worker, {"status": "ng", "kind": "input", "message": f"指示JSONを読めません: {e}"}, 1, None)
    log_dir = task.get("log_dir")
    teamlog.write("info", f"開始 action={task.get('action')} file={task.get('file') or task.get('input')}", worker, log_dir)
    fn = actions.get(task.get("action"))
    if not fn:
        _finish(worker, {"status": "ng", "kind": "input",
                         "message": f"未知のaction: {task.get('action')}（使える: {list(actions)}）"}, 1, log_dir)
    qs = support.questions_for(task)
    if qs:  # 足りない指示は、処理を始める前に聞き返す
        _finish(worker, {"status": "ng", "kind": "input", "message": "指示が足りません",
                         "questions": qs}, 1, log_dir)
    try:
        res = fn(task)
        _finish(worker, res, 1 if res.get("status") == "ng" else 0, log_dir, label=task.get("action", worker))
    except KeyError as e:
        _finish(worker, {"status": "ng", "kind": "input",
                         "message": f"指示JSONの項目、またはシート・列の名前が見つかりません: {e}"}, 1, log_dir)
    except (InputError, FileNotFoundError) as e:
        _finish(worker, {"status": "ng", "kind": "input", "message": str(e)}, 1, log_dir)
    except SaveError as e:
        _finish(worker, {"status": "ng", "kind": "save", "message": str(e)}, 2, log_dir)
    except Exception as e:  # 想定外は隠さず、原因のめやすとログを添えて報告
        _finish(worker, {"status": "ng", "kind": "unexpected", "message": f"{type(e).__name__}: {e}"}, 3, log_dir)
