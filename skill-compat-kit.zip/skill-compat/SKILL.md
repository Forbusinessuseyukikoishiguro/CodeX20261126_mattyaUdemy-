---
name: skill-compat
description: スキルを Codex 形式と Claude Code 形式の間で互換変換する。自動起動の禁止・置き場所・呼び出しの書き方を写し、対応できない項目は報告に残す。既定は確認のみで、--apply のときだけ書く。「CodeX から Claude へ」「Claude を CodeX にする」「互換性の設定」「スキルを両方で使えるように」などで使う。
---

# skill-compat

スキルを、Codex と Claude Code のどちらでも使えるように写すための手順と道具です。

## 使い方

1. 確認：`python3 scripts/skill_convert.py <元> <先> --to claude`（または `--to codex`）
2. BLOCK（止まる項目）があれば、name・description を直す
3. CHANGE・DROP・NOTE・REVIEW を読む（CONVERSION.md にも残る）
4. 書き込み：`--apply` を付けて実行
5. 変換先の環境で、/名前（Claude）または $名前（Codex）と呼んで試験する

## 守ること

- 元のスキルは変えない（コピーを作る）
- 対応先の無い項目は、黙って消さず、報告に残す
- 常時読まれる指示（AGENTS.md ⇄ CLAUDE.md）は、この道具では変換しない（docs/互換性設計書.md §5.3）
- フック（Claude Code の settings.json）は変換しない（Codex 側の仕様を公式で確認してから扱う）

## 参照

- docs/互換性設計書.md：対応表、変換の流れ、CodeX ⇒ Claude と Claude ⇒ CodeX の手順（図解つき）
- tests/run_compat_tests.py：試験（13件）
