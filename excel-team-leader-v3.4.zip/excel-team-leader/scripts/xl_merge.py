#!/usr/bin/env python3
"""複数のExcelファイル・複数のワークシートを1つの表に統合する（B：入出力）。

方針:
  - 列は「列名」で揃える（列の並びが違っても正しい列へ入る）
  - 元の列にない列は足す。ない列は空欄にし、差分は「統合サマリ」と status=warn で報告する
  - 空行は除く。どのファイルのどのシートの何行目か（元の行番号）を残す
  - 入力は読み取りのみ。出力は別名（入力と同じ名前は拒否）
  - 統合結果のシート「統合」と、シートごとの内訳「統合サマリ」を作る

指示の例（worker_b の action=merge_sheets）:
  {"action":"merge_sheets",
   "sources":[{"file":"samples/東京_売上.xlsx","sheets":"*"},
              {"file":"samples/大阪_売上.xlsx","sheets":["1月","2月"]}],
   "out":"work/統合売上.xlsx",
   "out_sheet":"統合", "add_source_columns":true}
  sheets は "*"（すべて）か、シート名の配列。
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

import nyanko
import xl_io
from nyanko import Progress
from teamcore import InputError



def _read_sheets(src: dict):
    path = Path(src["file"])
    if not path.exists():
        raise InputError(f"ファイルがありません: {path}")
    if path.suffix.lower() not in (".xlsx", ".xlsm"):
        raise InputError(f"統合できる形式は .xlsx / .xlsm です: {path.name}（.xls・CSVは convert で先に変換）")
    want = src.get("sheets", "*")
    try:
        allsh = pd.read_excel(path, sheet_name=None, dtype=object, header=src.get("header_row", 1) - 1)
    except Exception as e:
        raise InputError(f"読めません（{path.name}）: {e}") from e
    if want == "*":
        names = list(allsh)
    else:
        missing = [s for s in want if s not in allsh]
        if missing:
            raise InputError(f"{path.name} にシートがありません: {missing} / 実際: {list(allsh)}")
        names = list(want)
    return path.name, {n: allsh[n] for n in names}


def merge(t: dict) -> dict:
    sources = t.get("sources") or []
    if not sources:
        raise InputError("統合する元のファイル（sources）が指定されていません")
    out = Path(t["out"])
    add_src = t.get("add_source_columns", True)
    out_sheet = t.get("out_sheet", "統合")

    # 1. 読込（入力は読み取りのみ）
    for s in sources:
        if Path(s["file"]).resolve() == out.resolve():
            raise InputError("統合結果の保存先が元ファイルと同じです。別名にしてください")
    frames, base_cols, summary = [], None, []
    warnings = []
    loaded = [(s, *_read_sheets(s)) for s in sources]  # まず全部読んで、段階数を数える
    prog = Progress("統合", sum(len(sh) for _, _, sh in loaded))
    for s, fname, sheets in loaded:
        for sname, df in sheets.items():
            prog.step(f"{fname} の {sname}")
            df = df.copy()
            df.columns = [str(c).replace("\u3000", " ").strip() for c in df.columns]
            cols = list(df.columns)
            if base_cols is None:
                base_cols = cols
            missing = [c for c in base_cols if c not in cols]
            extra = [c for c in cols if c not in base_cols]
            if missing or extra:
                warnings.append(f"{fname}/{sname}: 欠けた列 {missing or '-'}、余分な列 {extra or '-'}")
                base_cols = base_cols + [c for c in extra if c not in base_cols]
            df["元の行番号"] = df.index + 1 + int(s.get("header_row", 1))  # Excel上の行番号
            df = df.dropna(how="all", subset=[c for c in df.columns if c != "元の行番号"])
            df.insert(0, "元シート", sname)
            df.insert(0, "元ファイル", fname)
            frames.append(df)
            summary.append({"元ファイル": fname, "元シート": sname, "行数": len(df),
                            "列の一致": "一致" if not (missing or extra) else
                            f"差あり（欠け{missing or '-'}／余分{extra or '-'}）"})

    # 2. 統合（列名で揃える。欠けた列は空欄）
    cols_all = ["元ファイル", "元シート"] + [c for c in base_cols] + ["元の行番号"]
    cols_all = list(dict.fromkeys(cols_all))
    merged = pd.concat([f.reindex(columns=cols_all) for f in frames], ignore_index=True)
    if not add_src:
        merged = merged.drop(columns=["元ファイル", "元シート", "元の行番号"])
    if merged.empty:
        raise InputError("統合する行が1行もありません")

    # 3. 保存（既存の出力は退避してから置き換える）
    sm = pd.DataFrame(summary)
    total = pd.DataFrame([{"元ファイル": "合計", "元シート": "", "行数": int(sm["行数"].sum()), "列の一致": ""}])
    xl_io.save(out, {out_sheet: merged, "統合サマリ": pd.concat([sm, total], ignore_index=True)})

    n_src = len(summary)
    msg = f"{n_src}シートを統合：{len(merged)}行・{len(cols_all)}列 → {out.name}"
    if warnings:
        msg += " / 注意：" + " ; ".join(warnings)
        return {"status": "warn", "message": msg, "rows": len(merged), "sheets": n_src, "file": str(out)}
    return {"status": "ok", "message": msg, "rows": len(merged), "sheets": n_src, "file": str(out)}
