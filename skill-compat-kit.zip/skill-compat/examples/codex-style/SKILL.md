---
name: codex-style
description: 見本（Codex 形式）。議事録を整形する。「議事録にして」で使う。
---

# codex-style

配置：.agents/skills/codex-style/ に置く。呼び出しは $codex-style と書く。
