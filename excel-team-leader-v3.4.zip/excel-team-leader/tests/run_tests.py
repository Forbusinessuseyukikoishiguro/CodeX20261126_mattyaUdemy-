#!/usr/bin/env python3
"""直接更新（update_cells）の業務レベル試験。Excelは不要。

使い方: python tests/run_tests.py [作業フォルダ]    終了コード: 0=全部合格 / 1=不合格あり
試験の内容:
  A 正常          入力セルだけ更新 → 数式は残る・意図しない変更なし・バックアップあり・再計算で合計が合う
  B 数式上書き    数式セルへの書き込みは拒否（ng/input）
  C 範囲外        inputs の外への書き込みは拒否（ng/input）
  D 結合セル      結合の2つ目以降への書き込みは拒否（ng/input）
  E グラフあり    保存で失われるため拒否（ng/input）。allow_loss=true なら続行（warn）
  F 日付          ISO日付文字列が日付セルになる
  G 保存不可      フォルダに書けないとき ng/save（終了コード2）。root実行では省略
  H 不正指示      inputs 無し・未知の action は拒否（ng/input）
  I 既存の検査    A の結果を excel_check.py（spec）で再検査 → 合格
  J 統合          samples の2ファイル・複数シートを1表に統合（列名で揃える）
  K 統合の内訳    行数・合計・列の並びが違うシートも正しい列へ入る
  L 統合の警告    列が欠けたシートは warn、欠けた列は空欄
  M 統合の拒否    存在しないシート・保存先が入力と同じ → ng/input
  N 元は不変      統合しても入力ファイルの中身（ハッシュ）が変わらない
  O 統合の検査    統合結果を excel_check（行数・金額の合計）で検査 → 合格
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Font

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
WORK = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "work" / "tests"
results = []


def make_book(path: Path, chart=False, merged=False):
    wb = Workbook()
    ws = wb.active
    ws.title = "データ"
    ws.append(["ID", "数量", "単価", "金額"])
    for r, (i, q, p) in enumerate([("001", 10, 120), ("002", 25, 80), ("003", 3, 450)], start=2):
        ws.append([i, q, p, f"=B{r}*C{r}"])
    ws.append([None, None, None, None])
    ws["A6"] = "合計"
    ws["D6"] = "=SUM(D2:D4)"
    ws["F1"] = "メモ"
    if merged:
        ws.merge_cells("F2:G2")
    if chart:
        c = BarChart()
        c.add_data(Reference(ws, min_col=4, min_row=1, max_row=4), titles_from_data=True)
        ws.add_chart(c, "I2")
    wb.save(path)


def run_worker(task: dict):
    tf = WORK / "task.json"
    tf.write_text(json.dumps(task, ensure_ascii=False), encoding="utf-8")
    cp = subprocess.run([sys.executable, str(SCRIPTS / "worker_b.py"), str(tf)],
                        capture_output=True, text=True, cwd=str(WORK))
    try:
        out = json.loads(cp.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        out = {"status": "crash", "message": cp.stdout + cp.stderr}
    return cp.returncode, out


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))


def main():
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir(parents=True)
    os.environ.setdefault("TEAM_LOG_DIR", str(WORK / "logs"))
    inputs = [{"sheet": "データ", "range": "B2:C4"}]

    # A 正常
    book = WORK / "A.xlsx"
    make_book(book)
    code, out = run_worker({"action": "update_cells", "file": str(book), "inputs": inputs,
                            "edits": [{"sheet": "データ", "cell": "B2", "value": 12}],
                            "blocks": [{"sheet": "データ", "top_left": "C3", "rows": [[90]]}]})
    check("A 正常：終了コード0・ok/not_verified", code == 0 and out.get("status") in ("ok", "not_verified"), str(out)[:120])
    from openpyxl import load_workbook
    wb = load_workbook(book)
    ws = wb["データ"]
    check("A 正常：入力セルが書けている", ws["B2"].value == 12 and ws["C3"].value == 90)
    check("A 正常：数式が残っている", str(ws["D2"].value) == "=B2*C2" and str(ws["D6"].value) == "=SUM(D2:D4)")
    check("A 正常：バックアップがある", bool(out.get("backup")) and Path(out["backup"]).exists())
    if out.get("status") == "ok":
        wv = load_workbook(book, data_only=True)["データ"]
        check("A 正常：再計算で合計が合う", abs(wv["D6"].value - (12 * 120 + 25 * 90 + 3 * 450)) < 1e-6,
              f"D6={wv['D6'].value}")
    # 元と比べて、意図しない変更がないこと（バックアップとの全セル比較）
    bk = load_workbook(out["backup"])["データ"]
    changed = [c.coordinate for row in ws.iter_rows() for c in row
               if not (isinstance(c.value, str) and c.value.startswith("=")) and c.value != bk[c.coordinate].value]
    check("A 正常：変更は指定セルだけ", sorted(changed) == ["B2", "C3"], str(changed))
    a_book, a_backup = book, out.get("backup")

    # B 数式上書き
    book = WORK / "B.xlsx"; make_book(book)
    code, out = run_worker({"action": "update_cells", "file": str(book), "inputs": [{"sheet": "データ", "range": "A2:D6"}],
                            "edits": [{"sheet": "データ", "cell": "D2", "value": 999}]})
    check("B 数式上書きは拒否", code == 1 and out.get("kind") == "input", out.get("message", "")[:100])

    # C 範囲外
    book = WORK / "C.xlsx"; make_book(book)
    code, out = run_worker({"action": "update_cells", "file": str(book), "inputs": inputs,
                            "edits": [{"sheet": "データ", "cell": "A2", "value": "999"}]})
    check("C 範囲外は拒否", code == 1 and out.get("kind") == "input" and "範囲の外" in out.get("message", ""))

    # D 結合セル（G2 は結合の2つ目）
    book = WORK / "D.xlsx"; make_book(book, merged=True)
    code, out = run_worker({"action": "update_cells", "file": str(book), "inputs": [{"sheet": "データ", "range": "F2:G2"}],
                            "edits": [{"sheet": "データ", "cell": "G2", "value": "x"}]})
    check("D 結合セルの2つ目は拒否", code == 1 and out.get("kind") == "input", out.get("message", "")[:100])

    # E グラフあり：拒否 → allow_loss で続行（警告）
    book = WORK / "E.xlsx"; make_book(book, chart=True)
    code, out = run_worker({"action": "update_cells", "file": str(book), "inputs": inputs,
                            "edits": [{"sheet": "データ", "cell": "B2", "value": 5}]})
    check("E グラフありは拒否", code == 1 and out.get("kind") == "input" and "失われます" in out.get("message", ""))
    code, out = run_worker({"action": "update_cells", "file": str(book), "inputs": inputs, "allow_loss": True,
                            "edits": [{"sheet": "データ", "cell": "B2", "value": 5}]})
    check("E allow_loss=true なら続行し、警告にする", out.get("status") in ("warn", "not_verified") and code == 0,
          out.get("message", "")[:120])

    # F 日付
    book = WORK / "F.xlsx"; make_book(book)
    wbF = load_workbook(book); wbF["データ"]["F2"] = None; wbF.save(book)
    code, out = run_worker({"action": "update_cells", "file": str(book), "inputs": [{"sheet": "データ", "range": "F2:F3"}],
                            "edits": [{"sheet": "データ", "cell": "F2", "value": "2026-11-01"}]})
    got = load_workbook(book)["データ"]["F2"].value
    check("F ISO日付は日付セルになる", code == 0 and getattr(got, "year", None) == 2026 and got.month == 11, repr(got))

    # G 保存不可（root では権限が効かないので省略）
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        check("G 保存不可（root実行のため省略）", True, "スキップ")
    else:
        sub = WORK / "locked"; sub.mkdir(exist_ok=True)
        book = sub / "G.xlsx"; make_book(book)
        os.chmod(sub, 0o555)
        try:
            code, out = run_worker({"action": "update_cells", "file": str(book), "inputs": inputs,
                                    "edits": [{"sheet": "データ", "cell": "B2", "value": 5}]})
            check("G 保存不可は ng/save（終了コード2）", code == 2 and out.get("kind") == "save", out.get("message", "")[:100])
        finally:
            os.chmod(sub, 0o755)

    # H 不正指示
    code, out = run_worker({"action": "update_cells", "file": str(a_book), "edits": [{"sheet": "データ", "cell": "B2", "value": 1}]})
    check("H inputs 無しは拒否", code == 1 and out.get("kind") == "input")
    code, out = run_worker({"action": "no_such_action", "file": str(a_book)})
    check("H 未知の action は拒否", code == 1 and out.get("kind") == "input")

    # I 既存の試験（excel_check）で再検査
    spec = {"sheets_required": ["データ"], "row_counts": [{"sheet": "データ", "expected": 3, "header_row": 1}],
            "protected": [{"sheet": "データ", "range": "D2:D6"}], "error_scan": True}
    sp = WORK / "spec.json"; sp.write_text(json.dumps(spec, ensure_ascii=False), encoding="utf-8")
    cp = subprocess.run([sys.executable, str(ROOT / "tests" / "excel_check.py"), str(a_backup), str(a_book), str(sp)],
                        capture_output=True, text=True)
    check("I excel_check（数式の保護・エラー・行数）が合格", cp.returncode == 0, cp.stdout.strip().splitlines()[-1])

    # J〜O 統合（複数ワークシートを1表に）
    samp = ROOT / "samples"
    tokyo, osaka = samp / "東京_売上.xlsx", samp / "大阪_売上.xlsx"
    h_before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (tokyo, osaka)}
    out = WORK / "merge" / "統合売上.xlsx"
    code, res = run_worker({"action": "merge_sheets", "out": str(out), "sources": [
        {"file": str(tokyo), "sheets": "*"}, {"file": str(osaka), "sheets": "*"}]})
    check("J 両ファイルの全シートを統合", code == 0 and res.get("rows") == 9 and res.get("sheets") == 4, str(res)[:120])
    wbm = load_workbook(out, data_only=True)
    ws_m = wbm["統合"]
    rows_m = [r for r in ws_m.iter_rows(min_row=2, values_only=True)]
    total = sum(r[6] for r in rows_m)
    check("J 金額の合計が正解（10,540円）", abs(total - 10540) < 1e-6, f"合計={total}")
    osk = [r for r in rows_m if r[0] == "大阪_売上.xlsx" and r[1] == "2月"]
    check("K 列の並びが違うシートも正しい列へ（大阪2月）",
          len(osk) == 2 and osk[0][2:7] == ("2026-02-09", "りんご", 5, 130, 650), str(osk[:1]))
    check("K 元の行番号が残る（大阪2月の2件目は4行目）", osk[1][7] == 4, str(osk[1:2]))
    check("K 統合サマリの合計が9行", wbm["統合サマリ"].cell(wbm["統合サマリ"].max_row, 3).value == 9)

    code, res = run_worker({"action": "merge_sheets", "out": str(WORK / "merge" / "feb.xlsx"),
                            "sources": [{"file": str(tokyo), "sheets": ["2月"]}]})
    check("J 指定したシートだけ統合（東京2月）", code == 0 and res.get("rows") == 2, str(res)[:100])

    # L 列が欠けたシート → warn、欠けた列は空欄
    lack = WORK / "merge" / "lack.xlsx"
    wl = Workbook(); a = wl.active; a.title = "1月"
    a.append(["日付", "商品", "数量", "単価", "金額"]); a.append(["2026-03-01", "りんご", 2, 120, 240])
    b = wl.create_sheet("3月"); b.append(["日付", "商品", "数量", "単価"]); b.append(["2026-03-02", "みかん", 4, 80])
    wl.save(lack)
    code, res = run_worker({"action": "merge_sheets", "out": str(WORK / "merge" / "lack_out.xlsx"),
                            "sources": [{"file": str(lack), "sheets": "*"}]})
    check("L 列が欠けたシートは warn", code == 0 and res.get("status") == "warn" and "欠けた列" in res.get("message", ""),
          res.get("message", "")[:120])
    wlo = load_workbook(WORK / "merge" / "lack_out.xlsx", data_only=True)["統合"]
    hdr = [c.value for c in wlo[1]]
    k_amt, k_sheet = hdr.index("金額") + 1, hdr.index("元シート") + 1
    lack_row = [r for r in range(2, wlo.max_row + 1) if wlo.cell(r, k_sheet).value == "3月"][0]
    check("L 欠けた列は空欄（3月の金額）", wlo.cell(lack_row, k_amt).value is None, repr(wlo.cell(lack_row, k_amt).value))
    check("L 欠けていない列は値が入る（1月の金額）", wlo.cell(2, k_amt).value == 240, repr(wlo.cell(2, k_amt).value))

    # M 拒否
    code, res = run_worker({"action": "merge_sheets", "out": str(WORK / "merge" / "x.xlsx"),
                            "sources": [{"file": str(tokyo), "sheets": ["存在しない"]}]})
    check("M 存在しないシートは ng/input", code == 1 and res.get("kind") == "input", res.get("message", "")[:100])
    code, res = run_worker({"action": "merge_sheets", "out": str(tokyo),
                            "sources": [{"file": str(tokyo), "sheets": "*"}]})
    check("M 保存先が入力と同じは拒否", code == 1 and res.get("kind") == "input")

    # N 入力は不変
    h_after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (tokyo, osaka)}
    check("N 統合しても元ファイルは変わらない", h_before == h_after)

    # O 統合結果を既存の検査で確かめる
    spec_m = {"sheets_required": ["統合", "統合サマリ"],
              "row_counts": [{"sheet": "統合", "expected": 9, "header_row": 1}],
              "control_sums": [{"sheet": "統合", "column": "G", "expected": 10540, "header_row": 1, "tolerance": 0}],
              "error_scan": True}
    spm = WORK / "merge" / "spec_merge.json"; spm.write_text(json.dumps(spec_m, ensure_ascii=False), encoding="utf-8")
    cp = subprocess.run([sys.executable, str(ROOT / "tests" / "excel_check.py"), str(tokyo), str(out), str(spm)],
                        capture_output=True, text=True)
    check("O 統合結果が excel_check（行数・金額合計）で合格", cp.returncode == 0, cp.stdout.strip().splitlines()[-1])

    # 結果
    width = max(len(n) for n, _, _ in results)
    print("== 直接更新 試験結果")
    for name, ok, detail in results:
        print(f"[{'OK' if ok else 'NG'}] {name.ljust(width)}  {detail if not ok else ''}")
    failed = [r for r in results if not r[1]]
    print(f"合計 {len(results)} 件 / 合格 {len(results) - len(failed)} / 不合格 {len(failed)}")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
