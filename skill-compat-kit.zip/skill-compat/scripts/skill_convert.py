#!/usr/bin/env python3
"""スキルの互換変換：Codex 形式 ⇄ Claude Code 形式。既定は確認だけ（書かない）。--apply で書く。

使い方:
  python skill_convert.py <元のスキルフォルダ> <出力先フォルダ> --to claude [--apply]
  python skill_convert.py <元のスキルフォルダ> <出力先フォルダ> --to codex  [--apply]

変換の中身:
  1. 共通の項目（name・description）を検査する（Agent Skills 標準）
  2. 呼び出しの制御を変換する：
       Claude の disable-model-invocation: true  ⇄  Codex の agents/openai.yaml の allow_implicit_invocation: false
  3. 片方にしか無い項目は消さず、報告に残す（Claude 専用の項目を Codex へ渡すとき など）
  4. パス（.claude/skills ⇄ .agents/skills）は書き換える。呼び出しの書き方（/名前 ⇄ $名前）は、本文の中では書き換えず、確認箇所として報告する
  5. 変換の記録（変換レポート）を出力先の CONVERSION.md に残す
"""
import argparse
import json
import re
import shutil
import sys
from pathlib import Path

STANDARD = {"name", "description", "license", "compatibility", "metadata"}
CLAUDE_ONLY = {"disable-model-invocation", "user-invocable", "when_to_use", "allowed-tools", "model", "context", "agent", "hooks", "paths"}
NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


def parse_frontmatter(text: str):
    """戻り値: (項目の辞書, 本文)。単純な「キー: 値」だけを扱う（複数行の値は本文側に残す）。"""
    m = re.match(r"^---\n(.*?)\n---\n?", text, re.S)
    if not m:
        raise ValueError("SKILL.md に frontmatter（--- で囲んだ部分）がありません")
    fm = {}
    for line in m.group(1).splitlines():
        if ":" in line and not line.startswith(" "):
            k, v = line.split(":", 1)
            fm[k.strip()] = v.strip().strip('"')
    return fm, text[m.end():]


def dump_frontmatter(fm: dict) -> str:
    return "---\n" + "\n".join(f"{k}: {v}" if not isinstance(v, bool) else f"{k}: {'true' if v else 'false'}" for k, v in fm.items()) + "\n---\n"


def read_openai_yaml(path: Path):
    """agents/openai.yaml の、必要な2項目だけを読む（この一式の形式に合わせた簡単な読み取り）。"""
    if not path.exists():
        return {}
    data = {"display_name": None, "allow_implicit_invocation": None}
    for line in path.read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if s.startswith("display_name:"):
            data["display_name"] = s.split(":", 1)[1].strip().strip('"')
        if s.startswith("allow_implicit_invocation:"):
            data["allow_implicit_invocation"] = s.split(":", 1)[1].strip().lower() == "true"
    return data


def write_openai_yaml(path: Path, display_name: str, allow: bool):
    path.parent.mkdir(parents=True, exist_ok=True)
    body = (f"interface:\n  display_name: \"{display_name}\"\n"
            f"policy:\n  allow_implicit_invocation: {'true' if allow else 'false'}\n")
    path.write_text(body, encoding="utf-8")


def check_standard(fm: dict, folder: Path, report: list):
    name = fm.get("name", "")
    if not name:
        report.append(("BLOCK", "name が無い"))
    elif not NAME_RE.match(name) or len(name) > 64:
        report.append(("BLOCK", f"name「{name}」は小文字・数字・ハイフンで、64字以内にしてください"))
    elif name != folder.name:
        report.append(("WARN", f"name「{name}」とフォルダ名「{folder.name}」が違います（一致させてください）"))
    desc = fm.get("description", "")
    if not desc:
        report.append(("BLOCK", "description が無い"))
    elif len(desc) > 1024:
        report.append(("BLOCK", f"description が 1024 字を超えています（{len(desc)} 字）"))


def convert(src: Path, dst: Path, target: str):
    report = []  # (重さ, 内容)
    pending_yaml = None
    md = src / "SKILL.md"
    if not md.exists():
        raise FileNotFoundError(f"SKILL.md がありません: {src}")
    fm, body = parse_frontmatter(md.read_text(encoding="utf-8"))
    check_standard(fm, src, report)
    yaml_src = read_openai_yaml(src / "agents" / "openai.yaml")
    new_fm = {k: v for k, v in fm.items() if k in STANDARD}
    dropped = {k: v for k, v in fm.items() if k not in STANDARD}
    new_body = body

    if target == "codex":
        allow = True
        if fm.get("disable-model-invocation", "").lower() == "true":
            allow = False
            report.append(("CHANGE", "disable-model-invocation: true → agents/openai.yaml の allow_implicit_invocation: false"))
        elif yaml_src.get("allow_implicit_invocation") is False:
            allow = False
        dropped.pop("disable-model-invocation", None)  # 上で対応済み
        for k in list(dropped):
            if k in CLAUDE_ONLY:
                report.append(("DROP", f"Claude 専用の項目「{k}」は Codex に無いため省きました（{dropped[k]}）"))
            else:
                report.append(("DROP", f"標準にない項目「{k}」を省きました"))
        display = yaml_src.get("display_name") or fm.get("name", src.name)
        pending_yaml = (display, allow)
        report.append(("CHANGE", f"agents/openai.yaml を作る（既存があれば置き換え。表示名：{display}、自動起動：{'許可' if allow else '禁止'}）"))
        paths_from, paths_to = ".claude/skills", ".agents/skills"
    else:  # claude
        if yaml_src:
            if yaml_src.get("allow_implicit_invocation") is False:
                new_fm["disable-model-invocation"] = True
                report.append(("CHANGE", "allow_implicit_invocation: false → disable-model-invocation: true"))
            report.append(("NOTE", "agents/openai.yaml は Claude では読まれないため、残しました（不要なら削除）"))
            if yaml_src.get("display_name"):
                report.append(("DROP", f"表示名「{yaml_src['display_name']}」は Claude に対応する項目がありません"))
        for k in dropped:
            report.append(("NOTE", f"項目「{k}」は、そのまま残しました（Claude 専用の項目の可能性）"))
            new_fm[k] = dropped[k]
        paths_from, paths_to = ".agents/skills", ".claude/skills"

    if paths_from in new_body:
        new_body = new_body.replace(paths_from, paths_to)
        report.append(("CHANGE", f"本文の「{paths_from}」を「{paths_to}」に書き換えました"))
    invocation_hits = []
    for pat, label in ((r"\$[a-z][a-z0-9\-]+", "$名前（Codex の呼び方）"), (r"(?<![\w/])/[a-z][a-z0-9\-]+", "/名前（Claude の呼び方）")):
        for m in re.finditer(pat, new_body):
            invocation_hits.append(f"{m.group(0)}（{label}）")
    for h in sorted(set(invocation_hits))[:20]:
        report.append(("REVIEW", f"呼び出しの書き方を確認してください：{h}"))

    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns("work", "__pycache__"))
    (dst / "SKILL.md").write_text(dump_frontmatter(new_fm) + new_body, encoding="utf-8")
    if pending_yaml:  # コピーの後に書く（コピーで消されないように）
        write_openai_yaml(dst / "agents" / "openai.yaml", *pending_yaml)
    return report


def write_report(dst: Path, src: Path, target: str, report):
    names = {"BLOCK": "止める（直してから変換）", "WARN": "注意", "CHANGE": "変えた", "DROP": "省いた", "NOTE": "残した", "REVIEW": "確認してください"}
    lines = [f"# 変換の記録：{src.name} → {target}", "", f"- 変換先：{target}", ""]
    if not report:
        lines.append("変更はありません。")
    for kind in ("BLOCK", "WARN", "CHANGE", "DROP", "NOTE", "REVIEW"):
        items = [m for k, m in report if k == kind]
        if items:
            lines += [f"## {names[kind]}", ""] + [f"- {m}" for m in items] + [""]
    lines += ["※ 変換は機械的な置き換えです。動作は、変換先の環境で必ず試験してください。"]
    (dst / "CONVERSION.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--to", choices=["claude", "codex"], required=True)
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args(argv[1:])
    src, dst = Path(a.src).resolve(), Path(a.dst).resolve()
    if dst == src or src in dst.parents and dst.name == src.name:
        print("出力先が元と同じです。別の場所を指定してください")
        return 1
    # 確認用に、まず作業用の場所に変換して結果を見る
    trial = Path(dst.parent / (dst.name + ".__trial"))
    report = convert(src, trial, a.to)
    blocks = [m for k, m in report if k == "BLOCK"]
    print(f"変換：{src.name} → {a.to}（{'書き込み' if a.apply else '確認のみ'}）")
    for k, m in report:
        print(f"  [{k}] {m}")
    if blocks:
        shutil.rmtree(trial)
        print("止めました：上の BLOCK を直してから、もう一度実行してください。")
        return 1
    if a.apply:
        if dst.exists():
            shutil.rmtree(dst)
        shutil.move(str(trial), str(dst))
        write_report(dst, src, a.to, report)
        print(f"書き込みました：{dst}（変換の記録：CONVERSION.md）")
    else:
        shutil.rmtree(trial)
        print("（確認のみ。書き込むには --apply を付けてください）")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
