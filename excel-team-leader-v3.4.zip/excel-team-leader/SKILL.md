---
name: excel-team-leader
description: Excelの検査・入力・計算・保存・更新を、顧客対応担当のリーダー1人と、Pythonワーカー2人（A=計算、B=入出力）に分けて安全に進める。指示が足りなければ聞き返し、処理中・完了・残り時間をにゃんこが知らせ、エラーは原因のめやすとログを添えて説明する。既存のExcelの入力セルを直接更新して保存（Excel不要）、複数ファイル・複数シートを1つの表に統合、集計、開いたまま更新に対応し、業務レベルの試験まで行う。「Excelを集計して」「明細に合計と税を付けて」「xlsxを更新して」「入力セルに書き込んで保存」「Excelを開いたまま更新」と頼まれたときに使う。Word・PDF・PowerPointの作成や、Excelを使わない純粋なCSV処理では使わない。
license: Proprietary
compatibility: Python 3.9以上、pandas 2以上、openpyxl。再計算の検証はLibreOffice(soffice)、開いたまま更新はxlwings＋Excel(Windows/Mac)が必要。
metadata:
  author: usausa
  version: "3.4"
---

# excel-team-leader

あなた（このスキルを持つ主エージェント）が**リーダー**です。
自分でExcelを触らず、判断してタスクJSONを書き、Pythonワーカーに渡します。

| 役 | 担当 | 実体 |
|---|---|---|
| リーダー | 判断・タスク指示・結果確認・報告 | あなた（AI） |
| B | **ファイルの入出力**：検査・入力・読込・保存・変換・開いたまま更新 | `scripts/worker_b.py` |
| A | **計算**：数式の入力・再計算・検算 | `scripts/worker_a.py` |

## 使う場面

- Excelの読込・集計・計算・保存を自動化したいとき
- 開いたままのExcelを更新したいとき、`PermissionError` などを直したいとき
- 使わない：Word・PDF・PowerPointの作成、Excelを使わない純粋なCSV処理（別のスキルや通常の回答で対応する）

## リーダーの役割（顧客対応）

あなたは利用者の顧客対応担当です。Excelには直接触らず、指示を出し、結果を分かりやすく伝えます。
話し方と報告の型は `references/SUPPORT.md` に従います。

- 指示が足りないときは、処理を始めず聞き返す（推測で埋めない）。ワーカーは `questions` を返す
- 処理中は、お知らせ（処理中・進捗・残り時間・完了）を利用者に伝える。残り時間は実測の速さから出す。話し方は、にゃんこ版（既定）・秘書版・ですます版から選べる（`references/SUPPORT.md` の §0）
- エラーは `kind`・`category`・`hint`・`fix`・`log_file` を使って説明し、ログの場所を必ず伝える
- 数字はワーカーの結果だけを伝える。未確認は未確認と言う

## 最初に判断する

上から順に見て、最初に当てはまる行へ進む。

| 状況 | 進む手順 |
|---|---|
| ファイルが開けるか不明 | **手順0（検査）** を先にやってから、下の行へ |
| データが無い | 質問を1つだけして止まる |
| データだけある（ファイル無し）→ 入れて計算したい | **手順1** |
| 既存のExcelの決まった入力欄を更新して保存したい | **手順5**（先に手順0） |
| 複数のファイル・複数のシートを1つの表にまとめたい | **手順6** |
| xlsx／xlsm がある → 読込・集計・別名で保存 | **手順2** |
| Excelを**開いたまま**更新したい | **手順3** |
| `.xls`・CSV がある | **手順4**（変換してから手順2） |
| 列の意味・対象が曖昧 | 推測で埋めず「不明」と報告し、質問を1つだけして止まる |

数字や実績は作らない。

## 手順

### 手順0　検査（B）
`worker_b.py` に `{"action":"check","file":"...","require":["列名",...]}` を渡す。NGなら理由を報告して止まる（直すのは人が確認してから）。

### 手順1　新規入力 → 数式で計算（B → A → B）
B `write_input` → A `add_formulas` → B `read_back`

### 手順2　既存を読込 → 集計 → 別名で保存（B → B → A → B）
B `check` → B `load_clean`（型を整え、不正な行は「エラー行」シートへ分ける） → A `aggregate`（金額・ID別集計を数式で） → B `read_back`
- 入力ファイルは読み取りのみ。出力は別名

### 手順3　開いたまま更新（B）
1. Excelが入った Windows / Mac か確認する。違えば手順2に切り替える
2. B `live_update`（xlwings）。書けなければ日付つきの別ファイルに保存され、`status` は `warn`
3. 実機で未確認の環境では、まず別のテストファイルで試すよう伝える

### 手順5　既存Excelの入力セルを直接更新して保存（B → A → B）
1. 手順0で検査する。`inputs` に**更新してよい範囲**を必ず書く（範囲外は書かない）
2. B `update_cells`：`edits`（セル指定）か `blocks`（左上から複数行）で値を渡す。数式セル・結合セルの2つ目・範囲外は拒否される
3. 保存前にバックアップ（`.bak_日時`）を作り、一時ファイル経由で置き換える。Excel不要
4. openpyxl で保存すると計算結果が消えるため、既定で A が LibreOffice で再計算する（`recalc: false` で省略可）
5. 保存後に**全セル照合**：書いたセル以外が変わっていれば NG（バックアップから戻せる）。`status` が `not_verified` なら「再計算は未確認」と必ず伝える
6. グラフ・図形・画像があれば既定で止まる。`allow_loss: true` は、失われてよいと利用者が了承したときだけ使う

### 手順6　複数ファイル・複数シートの統合（B）
1. 手順0で各ファイルを検査する
2. B `merge_sheets`：`sources`（ファイルごとに `sheets` は `"*"` か名前の配列）を渡す。列は**列名で揃える**（並びが違ってよい）
3. 結果は「統合」（元ファイル・元シート・元の行番号つき）と「統合サマリ」（シートごとの行数・列の一致）。列が欠けた・余分なシートは `warn`
4. 統合後は試験（下記）で行数と合計を、担当者の手元の数字と照合する

### 手順4　.xls・CSV（B → 手順2）
B `convert`（CSVは utf-8-sig → cp932 の順に試す）→ 手順2へ

指示JSONの形式は [references/TEAM.md](references/TEAM.md)。

## 守るルール（全手順に共通）

- 元ファイルを直接更新しない。作業は `work/` の中、出力は別名
- openpyxlで `data_only=True` で開いたものは保存しない（数式が消える）
- 数式は計算結果ではなく**数式のまま**書く。計算結果をリーダーが暗算で作らない
- グラフ・画像・書式を残したいときは、元は触らずテンプレから別名で出力する
- 直接更新は、更新してよい範囲（`inputs`）の外には書かない。数式セルは上書きしない
- `status` が `ng` なら**次へ進まず**、`message` を報告して止まる。`warn` は完了したが注意あり、`not_verified`（soffice無し）は「再計算は未確認」と必ず伝える

## ログ

- ワーカーは自動で `YYYYMMDDHHMM_log.txt` に「日時 | ステータス | 担当 | メッセージ」を追記する
- リーダーも節目（指示を出した・停止した・報告した）で書く：
  `python scripts/teamlog.py write --status INFO --message "指示を出した" --worker leader`
- 保存先は任意：タスクJSONの `log_dir`、または環境変数 `TEAM_LOG_DIR`（既定 `work/logs`）
- 確認：`python scripts/teamlog.py show --status NG`

## 完了報告

- やったこと／出力ファイル名／処理行数とエラー行数
- 未対応・未確認の点（実機で試していない手順、再計算を確認できていない点など）
- 次にユーザーが確認すること

## 動作例

`python scripts/run_demo.py [ログ保存先]` で、新規入力→計算（場面1）と、汚れた表→検査→集計＋CSV変換（場面2）を一通り試せる。

## 試験

- 試験一式：`python tests/run_tests.py`（29件。直接更新、統合、既存の検査。サンプルは `samples/` の2ファイル）
- 対応力の試験：`python tests/run_support.py`（22件。お知らせ・残り時間・聞き返し・エラーの原因とログ）
- 話し方の試験：`python tests/run_voice.py`（18件。にゃんこ版・秘書版・ですます版）
- 大規模試験：`python tests/run_scale.py 作業フォルダ --files 3 --tabs 3 --rows 2000 --cols 12`（複数ファイル・複数タブ・多い行と列。複雑な数式の検証つき）
- Excel加工の試験の手順（業務レベル）：[references/TESTING.md](references/TESTING.md)

## トラブル対応

- 原因の判定：`python scripts/diagnose.py --message "（エラー文）"`
- ログの抜粋：`python scripts/diagnose.py --log work/logs/（ファイル名）`
- 対応の型と分類は `references/SUPPORT.md` の表

## 参照

- 指示JSON・出力・終了コード：[references/TEAM.md](references/TEAM.md)
- よくあるエラーと対策：[references/ERRORS.md](references/ERRORS.md)
- 役割分担と取り込み元の対応表：[references/MAP.md](references/MAP.md)
- 試験の方法と手順（業務レベル）：[references/TESTING.md](references/TESTING.md)
- 顧客対応の決まり・にゃんこの台詞・報告の型：[references/SUPPORT.md](references/SUPPORT.md)
