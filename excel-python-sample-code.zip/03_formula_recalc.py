# 外部のコマンド(LibreOffice)を呼ぶ標準ライブラリ
import subprocess
# コマンドの場所を探す・ファイルをコピーする標準ライブラリ
import shutil
# 一時フォルダを作る標準ライブラリ
import tempfile
# ファイルの場所を扱う標準ライブラリ
from pathlib import Path
# ブックを開く関数
from openpyxl import load_workbook

# 加工するファイル(02で作った clean.xlsx)
path = Path("clean.xlsx")
# 数式を書くために、ふつうに開く(data_only は付けない!付けると数式が消える)
wb = load_workbook(path)
# 「明細」シートを取り出す
ws = wb["明細"]
# 最後のデータ行の番号を覚える
last = ws.max_row
# E1 に見出し「金額」を書く
ws["E1"] = "金額"
# 2行目から最後の行まで、1行ずつ
for row in range(2, last + 1):
    # 金額は「計算結果」ではなく「数式」で書く(数量 × 単価)
    ws[f"E{row}"] = f"=C{row}*D{row}"
# 合計のラベルを、データの2行下に書く
ws[f"D{last + 2}"] = "合計"
# 合計も数式で書く(金額の列を全部たす)
ws[f"E{last + 2}"] = f"=SUM(E2:E{last})"
# 保存する(この時点では、数式はあるが計算結果がファイルに入っていない)
wb.save(path)

# LibreOffice の実行ファイルを探す(Windowsなどでは名前が違うので2つ試す)
soffice = shutil.which("soffice") or shutil.which("libreoffice")
# 見つからなければ、再計算は確認できない
if not soffice:
    # 確認できないことを正直に言って終わる(数式自体は入っている)
    raise SystemExit("LibreOfficeが無いので、再計算は未確認です(数式は入力済み)")
# 一時フォルダを作る(終わったら自動で消える)
with tempfile.TemporaryDirectory() as tmp:
    # LibreOffice を画面なしで動かして、xlsx に変換し直す=再計算される。120秒で打ち切る
    subprocess.run([soffice, "--headless", "--convert-to", "xlsx", "--outdir", tmp, str(path)],
                   check=True, capture_output=True, timeout=120)
    # 計算結果が入ったファイルを、元の場所へ戻す
    shutil.copy(Path(tmp) / path.name, path)

# 読み戻し:計算結果(値)を見るために data_only=True で開く
wb2 = load_workbook(path, data_only=True)
# 「明細」シートを取り出す
ws2 = wb2["明細"]
# Pythonで数量×単価を自分で計算して、検算の「期待値」にする
expected = sum(ws2[f"C{r}"].value * ws2[f"D{r}"].value for r in range(2, last + 1))
# Excelの数式が出した合計を読む
actual = ws2[f"E{last + 2}"].value
# 期待値と数式の結果を並べて見せる
print("数式の合計:", actual, "/ Pythonでの検算:", expected)
# 一致していなければ
if actual != expected:
    # 検算NGとして止める
    raise SystemExit("検算が一致しません")
# 一致したら報告する
print("検算OK")
