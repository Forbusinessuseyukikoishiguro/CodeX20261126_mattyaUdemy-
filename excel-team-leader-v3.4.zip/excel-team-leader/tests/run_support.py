#!/usr/bin/env python3
"""リーダーの対応力の試験：にゃんこのお知らせ・残り時間・聞き返し・エラーの原因とログ。

使い方: python tests/run_support.py [作業フォルダ]    終了コード: 0=全部合格 / 1=不合格あり
  S1 お知らせ：処理中・完了の言葉が出る。標準出力は結果のJSON1行だけ
  S2 残り時間：実測の速さから計算し、計算できないときは推測しない
  S3 聞き返し：指示が足りないときは処理せず、質問を返す（ワーカー・終了コード1）
  S4 聞き返し（統合）：ファイルが無い指示には質問を返す
  S5 想定外のエラー：原因のめやすとログの場所を返す（終了コード3）
  S6 原因の判定：ライブラリ未導入・権限・壊れたファイル・文字コード・メモリ・不明
  S7 ログの抜粋：NG の行を見せられる
  S8 CLI：diagnose.py --log で原因を表示できる
  S9 エラーのお知らせ：にゃんこが原因と保存先を伝える
  S10 進捗：統合の段階ごとに「完了 xx%」が出る
"""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
import diagnose  # noqa: E402
import nyanko  # noqa: E402

WORK = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "work" / "support"
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))


def run(task, tag):
    WORK.mkdir(parents=True, exist_ok=True)
    tf = WORK / f"{tag}.json"
    tf.write_text(json.dumps(task, ensure_ascii=False), encoding="utf-8")
    env = dict(os.environ, TEAM_LOG_DIR=str(WORK / "logs"), PYTHONIOENCODING="utf-8")
    cp = subprocess.run([sys.executable, str(SCRIPTS / "worker_b.py"), str(tf)],
                        capture_output=True, text=True, env=env, encoding="utf-8")
    out_lines = [l for l in cp.stdout.splitlines() if l.strip()]
    try:
        res = json.loads(out_lines[-1]) if out_lines else {}
    except ValueError:
        res = {}
    return cp.returncode, res, cp.stdout, cp.stderr


def main():
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir(parents=True)

    # S1 お知らせと標準出力
    code, res, out, err = run({"action": "merge_sheets", "out": str(WORK / "s1.xlsx"), "sources": [
        {"file": str(ROOT / "samples" / "東京_売上.xlsx"), "sheets": "*"}]}, "s1")
    check("S1 処理中・完了のお知らせが出る", "処理中だにゃー" in err and "終わったニャー" in err)
    check("S1 標準出力は結果のJSON1行だけ", code == 0 and len(out.strip().splitlines()) == 1 and res.get("status") == "ok")

    # S2 残り時間
    check("S2 残り時間：速さから計算（120秒で1/4 → 約後6分）",
          "後6分" in nyanko.eta_text(120, 1, 4), nyanko.eta_text(120, 1, 4))
    check("S2 残り時間：あと少し（30秒で3/4 → もうすぐ）", "もうすぐ" in nyanko.eta_text(30, 3, 4))
    check("S2 残り時間：まだ計算できないときは推測しない", nyanko.eta_text(0, 0, 4) == "まだ計算中だにゃ")

    # S3 聞き返し（更新の範囲が無い）
    code, res, out, err = run({"action": "update_cells", "file": str(WORK / "none.xlsx"),
                               "edits": [{"sheet": "データ", "cell": "B2", "value": 1}]}, "s3")
    check("S3 範囲が無いと聞き返す（終了コード1・処理なし）",
          code == 1 and res.get("kind") == "input" and res.get("questions"), str(res.get("questions"))[:120])
    check("S3 聞き返しの言葉が出る", "わからないことがあるから" in err)

    # S4 聞き返し（統合：ファイルが無い）
    code, res, out, err = run({"action": "merge_sheets", "out": str(WORK / "s4.xlsx")}, "s4")
    check("S4 統合で元ファイルが無いと質問する", code == 1 and any("統合したいファイル" in q for q in res.get("questions", [])))

    # S5 想定外のエラー（header_row に文字）→ 原因のめやすとログ
    code, res, out, err = run({"action": "merge_sheets", "out": 123, "sources": [
        {"file": str(ROOT / "samples" / "東京_売上.xlsx"), "sheets": "*"}]}, "s5")  # 出力先が文字でない → 想定外
    check("S5 想定外は終了コード3", code == 3 and res.get("kind") == "unexpected", str(res)[:120])
    check("S5 原因のめやすと直し方が付く", bool(res.get("hint")) and bool(res.get("fix")))
    lf = Path(res.get("log_file", ""))
    check("S5 ログの場所が分かり、NGの行が残る", lf.exists() and "| NG " in lf.read_text(encoding="utf-8"), str(lf))

    # S6 原因の判定
    cases = [
        ("No module named 'xlwings'", "ライブラリが入っていない", "pip install xlwings"),
        ("[Errno 13] Permission denied: 'a.xlsx'", "Excelで開いている", "閉じて"),
        ("BadZipFile: File is not a zip file", "壊れている", "別名で保存し直す"),
        ("UnicodeDecodeError: 'utf-8' codec", "文字コード", "cp932"),
        ("MemoryError", "多すぎる", "分けて"),
        ("zzz unknown", "想定外", "ログ"),
    ]
    for msg, cat, must in cases:
        e = diagnose.explain(msg)
        ok = cat in e["category"] and must in (e["fix"] + e["hint"])
        check(f"S6 判定：{msg[:28]}", ok, f"{e['category']} / {e['fix']}")

    # S7 ログの抜粋
    ex = diagnose.log_excerpt(lf, 3)
    check("S7 ログ抜粋に NG が含まれる", any("| NG " in l for l in ex), str(ex)[:120])

    # S8 CLI
    cp = subprocess.run([sys.executable, str(SCRIPTS / "diagnose.py"), "--log", str(lf)],
                        capture_output=True, text=True, encoding="utf-8")
    check("S8 diagnose.py --log が動く", cp.returncode == 0 and "NG" in cp.stdout, cp.stdout[:120])

    # S9 にゃんこのエラー（保存先と原因）
    code, res, out, err = run({"action": "merge_sheets", "out": 123, "sources": [
        {"file": str(ROOT / "samples" / "東京_売上.xlsx"), "sheets": "*"}]}, "s9")
    check("S9 にゃんこが「ログはここにあるにゃ」と伝える", "ログはここにあるにゃ" in err and "原因のめやす" in err)
    # 入力の読込で起きたエラーは「読めません」として入力の問題に分類され、原因のめやすが付く
    code2, res2, _, err2 = run({"action": "merge_sheets", "out": str(WORK / "s9b.xlsx"), "sources": [
        {"file": str(ROOT / "samples" / "東京_売上.xlsx"), "sheets": "*", "header_row": "abc"}]}, "s9b")
    check("S9 読込の失敗も原因のめやすが付く（型の不一致）", code2 == 1 and "型" in res2.get("category", ""), res2.get("category", ""))

    # S10 統合の段階ごとの進捗
    code, res, out, err = run({"action": "merge_sheets", "out": str(WORK / "s10.xlsx"), "sources": [
        {"file": str(ROOT / "samples" / "東京_売上.xlsx"), "sheets": "*"},
        {"file": str(ROOT / "samples" / "大阪_売上.xlsx"), "sheets": "*"}]}, "s10")
    check("S10 段階ごとに「完了 xx%」が出る", "統合：1/4 完了 25%" in err and "統合：4/4 完了 100%" in err)

    width = max(len(n) for n, _, _ in results)
    print("== 対応力の試験（にゃんこ・聞き返し・エラー対応）")
    for name, ok, detail in results:
        print(f"[{'OK' if ok else 'NG'}] {name.ljust(width)}  {'' if ok else detail}")
    failed = [r for r in results if not r[1]]
    print(f"合計 {len(results)} 件 / 合格 {len(results) - len(failed)} / 不合格 {len(failed)}")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
