#!/usr/bin/env python3
"""Excelファイルの事前検査（取り込み元 excel-python の check_xlsx.py を関数化）。判定はスクリプトが行う。
CLI: python scripts/check_xlsx.py <ファイル> [--sheet 名] [--require 列名 ...]   終了コード: 0=OK / 1=NG
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def inspect_xlsx(p: Path, sheet=None, require=()):
    """戻り値: (OKか, メッセージのリスト)。NGの理由は最後の行。"""
    msgs = []
    if not p.exists():
        return False, [f"NG: ファイルがありません: {p}"]
    if p.name.startswith("~$"):
        return False, ["NG: Excelのロックファイル（~$）です。元のファイルを指定してください"]
    if p.suffix.lower() not in (".xlsx", ".xlsm"):
        return False, [f"NG: 対応していない形式です: {p.suffix}（.xls・CSVは convert で .xlsx にしてください）"]
    if p.stat().st_size == 0:
        return False, ["NG: ファイルが空です"]
    if p.with_name(f"~${p.name}").exists():
        msgs.append("注意: ロックファイルがあり、Excelで開かれている可能性（読み取りは可・書き込みは不可）")
    try:
        from openpyxl import load_workbook
        wb = load_workbook(p, read_only=True, data_only=True)
    except PermissionError:
        return False, msgs + ["NG: ファイルを開けません。Excelで開いたままではありませんか"]
    except Exception as e:
        return False, msgs + [f"NG: 読み込めません（壊れている可能性）: {e}"]
    msgs.append(f"OK: シート {wb.sheetnames}")
    name = sheet or wb.sheetnames[0]
    if name not in wb.sheetnames:
        return False, msgs + [f"NG: シート '{name}' がありません"]
    header = next(wb[name].iter_rows(min_row=1, max_row=1, values_only=True), ())
    cols = [str(c).replace("\u3000", " ").strip() for c in header if c is not None]
    msgs.append(f"OK: 1行目の列名 {cols}")
    missing = [c for c in require if c not in cols]
    if missing:
        return False, msgs + [f"NG: 必須の列がありません: {missing}"]
    return True, msgs + ["OK: 検査を通りました"]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("file", type=Path)
    ap.add_argument("--sheet", default=None)
    ap.add_argument("--require", nargs="*", default=[])
    a = ap.parse_args()
    ok, msgs = inspect_xlsx(a.file, a.sheet, a.require)
    print("\n".join(msgs))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
