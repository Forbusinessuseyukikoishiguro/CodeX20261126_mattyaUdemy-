"""② Pythonスクリプトのテスト（エージェント不要）。CLI＋JSON＋終了コードを検証する。"""
import json
import subprocess
import sys

import openpyxl
import pytest

from conftest import SKILLS_DIR

SCRIPT = SKILLS_DIR / "python-excel-spec" / "scripts" / "excel_tool.py"


def run(*args):
    return subprocess.run([sys.executable, str(SCRIPT), *args], capture_output=True, text=True, encoding="utf-8")


def test_write_then_read_japanese(tmp_path):
    f = tmp_path / "t.xlsx"
    w = run("write", str(f), "A1", "こんにちは🐰")
    assert w.returncode == 0 and json.loads(w.stdout)["ok"] is True
    r = run("read", str(f), "A1")
    assert r.returncode == 0
    assert json.loads(r.stdout)["value"] == "こんにちは🐰"


@pytest.mark.parametrize("kind,raw,expected", [("int", "42", 42), ("float", "3.5", 3.5), ("str", "007", "007")])
def test_value_types(tmp_path, kind, raw, expected):
    f = tmp_path / "t.xlsx"
    assert run("write", str(f), "B2", raw, "--as", kind).returncode == 0
    value = json.loads(run("read", str(f), "B2").stdout)["value"]
    assert value == expected and type(value) is type(expected)


def test_overwrite_keeps_other_cells(tmp_path):
    f = tmp_path / "t.xlsx"
    run("write", str(f), "A1", "one")
    run("write", str(f), "A2", "two")
    assert json.loads(run("read", str(f), "A1").stdout)["value"] == "one"
    assert json.loads(run("read", str(f), "A2").stdout)["value"] == "two"


def test_new_sheet_is_added(tmp_path):
    f = tmp_path / "t.xlsx"
    run("write", str(f), "A1", "x")
    run("write", str(f), "A1", "y", "--sheet", "Other")
    assert json.loads(run("sheets", str(f)).stdout)["sheets"] == ["Sheet1", "Other"]


def test_empty_cell_is_null(tmp_path):
    f = tmp_path / "t.xlsx"
    run("write", str(f), "A1", "x")
    assert json.loads(run("read", str(f), "Z9").stdout)["value"] is None


def test_marker_proves_script_was_used(tmp_path):
    """e2e で「スキルのスクリプトが実行された」ことを判定する証跡。"""
    f = tmp_path / "t.xlsx"
    run("write", str(f), "A1", "x")
    assert openpyxl.load_workbook(f).properties.creator == "python-excel-spec/excel_tool 1.0"


@pytest.mark.parametrize("args", [
    ("read", "{missing}", "A1"),
    ("sheets", "{missing}"),
])
def test_missing_file_fails_with_json_error(tmp_path, args):
    args = [a.replace("{missing}", str(tmp_path / "none.xlsx")) for a in args]
    r = run(*args)
    assert r.returncode == 1
    assert json.loads(r.stderr)["ok"] is False


def test_missing_sheet_and_bad_inputs_fail(tmp_path):
    f = tmp_path / "t.xlsx"
    run("write", str(f), "A1", "x")
    assert run("read", str(f), "A1", "--sheet", "Nope").returncode == 1
    assert run("write", str(f), "!!", "x").returncode == 1
    assert run("write", str(f), "A1", "abc", "--as", "int").returncode == 1


def test_argument_error_exit_code_2():
    assert run("write").returncode == 2
