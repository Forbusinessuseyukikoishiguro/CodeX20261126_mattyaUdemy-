#!/bin/sh
# 例：コミット前に品質ゲート（開発中の検査）を走らせる。install_hooks.py --git --apply が同じものを書く。
python3 "/絶対パス/spec-driven-dev/scripts/quality_gate.py" "$(git rev-parse --show-toplevel)" || exit 1
