#!/usr/bin/env python3
"""任意のフックを導入する。既定は確認だけ（何も書かない）。--apply を付けたときだけ書き込む。

使い方:
  python install_hooks.py <プロジェクト> --claude          Claude Code：会話の終わりに品質ゲートを走らせる（Stop フック）
  python install_hooks.py <プロジェクト> --git             Git：コミット前に品質ゲートを走らせる（pre-commit）
  上の各コマンドに --apply を付けると、実際に書き込む（既存の内容は残し、.bak を作る）

Claude Code の Stop フック：不合格なら終了を止め、理由を表示する（終了コード2）。
  既に続けている場合（stop_hook_active）は止めないので、無限に止まることはない。
Codex：このスクリプトは Codex のフック設定を書かない（Codex 側のフックの有無は公式で確認してから使う）。
  Codex では、--git の pre-commit か CI で同じ品質ゲートを使う。
"""
import json
import shutil
import stat
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
GATE = (HERE / "quality_gate.py").resolve()


def claude_plan(project: Path, apply: bool):
    path = project / ".claude" / "settings.json"
    data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    hooks = data.setdefault("hooks", {})
    stop = hooks.setdefault("Stop", [])
    cmd = f"python3 {GATE} --hook"
    if any("quality_gate.py" in h.get("command", "") for g in stop for h in g.get("hooks", [])):
        print(f"既に導入されています：{path}")
        return 0
    stop.append({"matcher": "", "hooks": [{"type": "command", "command": cmd}]})
    text = json.dumps(data, ensure_ascii=False, indent=2)
    print(f"[予定] {path} に次の Stop フックを追加します：\n{text}")
    if not apply:
        print("（確認だけ。書き込むには --apply を付けてください）")
        return 0
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        shutil.copy2(path, path.with_suffix(".json.bak"))
    path.write_text(text + "\n", encoding="utf-8")
    print(f"書き込みました：{path}（元の内容は .json.bak）")
    return 0


def git_plan(project: Path, apply: bool):
    hook = project / ".git" / "hooks" / "pre-commit"
    body = f"#!/bin/sh\npython3 \"{GATE}\" \"{project}\" || exit 1\n"
    if hook.exists() and hook.read_text(encoding="utf-8") != body:
        print(f"既に別の pre-commit があります：{hook}\n上書きしません。内容を見て、手で追記してください。")
        return 1
    print(f"[予定] {hook} に次を書きます：\n{body}")
    if not apply:
        print("（確認だけ。書き込むには --apply を付けてください）")
        return 0
    hook.parent.mkdir(parents=True, exist_ok=True)
    hook.write_text(body, encoding="utf-8")
    hook.chmod(hook.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    print(f"書き込みました：{hook}")
    return 0


if __name__ == "__main__":
    args = sys.argv[1:]
    if len(args) < 2 or args[0].startswith("--"):
        print(__doc__)
        sys.exit(2)
    project = Path(args[0]).resolve()
    apply = "--apply" in args
    if "--claude" in args:
        sys.exit(claude_plan(project, apply))
    if "--git" in args:
        sys.exit(git_plan(project, apply))
    print(__doc__)
    sys.exit(2)
