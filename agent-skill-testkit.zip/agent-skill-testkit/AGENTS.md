# プロジェクト指示（Codex / その他エージェント共通）

- スキルの実体は `.agents/skills/` に置く（Codexはここを探索する）。
- Claude Code 用の `.claude/skills` は `.agents/skills` へのリンク（`python scripts/sync_claude_links.py`）。
- Python は 3.10 以上。変更後は `python -m pytest` を実行して全て通すこと。
- スキルの frontmatter は Agent Skills 標準の項目（name / description / license / compatibility / metadata / allowed-tools）だけを使う。
