#!/usr/bin/env python3
"""B：ファイルの入出力担当（検査・入力・読込・保存・変換・開いたまま更新）。計算はしない（計算はA）。"""
from __future__ import annotations

from pathlib import Path

import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font

import teamcore
import xl_io
from check_xlsx import inspect_xlsx
from teamcore import InputError, SaveError


def check(t):
    """検査。NGなら理由つきで止まる。"""
    ok, msgs = inspect_xlsx(Path(t["file"]), t.get("sheet"), t.get("require", []))
    if not ok:
        raise InputError(" / ".join(msgs))
    return {"status": "ok", "message": " / ".join(msgs)}


def write_input(t):
    headers, rows = t["headers"], t["rows"]
    bad = [i + 2 for i, r in enumerate(rows) if len(r) != len(headers)]
    if bad:
        raise InputError(f"列数が合わない行: {bad}")
    path = Path(t["file"])
    path.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = t.get("sheet", "入力")
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(name="Arial", bold=True)
    for r in rows:
        ws.append(r)
    wb.save(path)
    return {"status": "ok", "message": f"{len(rows)}行を保存", "file": str(path)}


def load_clean(t):
    """既存Excelを読み、型を整え、不正行を分けて別名で保存する（入力ファイルは読み取りのみ）。"""
    src, out = Path(t["input"]), Path(t["out"])
    if out.resolve() == src.resolve():
        raise InputError("入力と同じファイルには保存できません。別名にしてください")
    require = t.get("required_cols", ["ID", "日付", "数量", "単価"])
    text, num, date = t.get("text_cols", ["ID"]), t.get("num_cols", ["数量", "単価"]), t.get("date_cols", ["日付"])
    ok, msgs = inspect_xlsx(src, t.get("sheet"), require)
    if not ok:
        raise InputError(" / ".join(msgs))
    df = xl_io.load(src, t.get("sheet", 0), require, text)
    good, bad = xl_io.clean(df, text, num, date)
    if good.empty:
        raise InputError("正常な行が1行もありません。エラー行の内容を確認してください")
    xl_io.save(out, {"明細": good, "エラー行": bad})
    st = "warn" if len(bad) else "ok"
    return {"status": st, "message": f"読込{len(df)}行 / 正常{len(good)}行 / エラー{len(bad)}行 → {out.name}",
            "good": len(good), "bad": len(bad), "file": str(out)}


def read_back(t):
    wb = load_workbook(t["file"], data_only=True)
    if t.get("sheet", "入力") not in wb.sheetnames:
        raise InputError(f"シート '{t.get('sheet', '入力')}' がありません: {wb.sheetnames}")
    ws = wb[t.get("sheet", "入力")]
    values = [list(r) for r in ws.iter_rows(values_only=True)]
    return {"status": "ok", "message": f"{len(values)}行を読み戻し（{ws.title}）", "values": values}


def convert(t):
    how = xl_io.convert(Path(t["input"]), Path(t["out"]))
    return {"status": "ok", "message": f"{how} → {Path(t['out']).name}", "file": t["out"]}


def live_update(t):
    """開いたままのExcelを更新（Excelのある Windows/Mac）。書けなければ別ファイル＝warn。"""
    from xl_live import update_excel
    headers, rows = t["headers"], t["rows"]
    if any(len(r) != len(headers) for r in rows):
        raise InputError("列数が合わない行があります")
    ok, msg = update_excel(t["file"], pd.DataFrame(rows, columns=headers), t.get("sheet", "データ"))
    return {"status": "ok" if ok else "warn", "message": msg}


def update_cells(t):
    """既存Excelの入力セルだけを直接更新して保存（Excel不要）。詳細は xl_direct.py。"""
    from xl_direct import update_in_place
    try:
        return update_in_place(t)
    except (InputError, SaveError):
        raise


def merge_sheets(t):
    """複数ファイル・複数シートを列名で揃えて1つの表に統合（xl_merge.py）。"""
    from xl_merge import merge
    return merge(t)


ACTIONS = {"check": check, "write_input": write_input, "load_clean": load_clean,
           "read_back": read_back, "convert": convert, "live_update": live_update,
           "update_cells": update_cells, "merge_sheets": merge_sheets}

if __name__ == "__main__":
    teamcore.main("worker_b", ACTIONS)
