# 役割分担（MECE）と取り込み元の対応表

## 1. 役割分担：重ならず、漏れなく

分け方の軸は「**何を扱うか**」。1つの仕事は必ず1人だけが持つ。

| 役 | 扱うもの | 持つ仕事（action） | 持たないもの |
|---|---|---|---|
| **リーダー** | 判断・順序・報告 | どの手順か決める／指示JSONを書く／`status` を見て止める・進む／完了報告 | Excelに触れること、計算すること |
| **B（入出力）** | ファイルとの出入り | `check` `write_input` `load_clean` `read_back` `convert` `live_update` | 数式・計算 |
| **A（計算）** | 数式と検算 | `add_formulas` `aggregate` | ファイルの検査・変換・読込の整形 |
| **共通基盤** | 役の外側の約束事 | `teamcore.py`（JSON・終了コード・エラー分類）／`teamlog.py`（ログ） | 業務の判断 |

判定の目安：
- 「ファイルを開く・閉じる・変換する・整える・保存する」→ B
- 「数式を入れる・再計算する・値を照合する」→ A
- 「どれをやるか・やめるか・何を伝えるか」→ リーダー

## 2. 状況の分け方：重ならず、漏れなく

| 状況（排他） | 手順 | 流れ |
|---|---|---|
| ファイルが無い | 1 | B → A → B |
| xlsx/xlsm があり、別名で保存 | 2 | B → B → A → B |
| Excelを開いたまま更新 | 3 | B |
| xls/CSV | 4 | B → 手順2 |
| 開けるか不明 | 0（他の前に必ず） | B |
| 曖昧 | 質問1つで止まる | リーダー |

## 3. 取り込み元との対応（漏れ確認）

### skill-template-v2（ひな形）

| 取り込み元 | 入れた場所 | メモ |
|---|---|---|
| SKILL.md の節（使う場面／最初に判断する／手順／完了報告／参照） | `SKILL.md` | 同じ並びに揃えた |
| 「迷ったら推測で埋めず『不明』。数字や実績は作らない」 | `SKILL.md`「最初に判断する」 | |
| `scripts/check.py`（入力検査） | `scripts/check_xlsx.py` ＋ B `check` | Excel用に上位互換。重複するので残していない |
| `references/REFERENCE.md` | `references/ERRORS.md` ほか | |
| `agents/openai.yaml`（policy） | `agents/openai.yaml` | `interface.display_name` も足した |
| README の テスト3種・注意 | `README.md` | 取り込み |
| README の Codex 置き場所 `~/.codex/skills/`・「追加後は再起動」 | **採用しない** | 最新は `$HOME/.agents/skills/`、変更は自動検出（再起動は出ないときだけ） |
| `allowed-tools` 等はClaude専用の注意 | `README.md` | frontmatterは標準項目のみ |

### excel-python（Excel処理）

| 取り込み元 | 入れた場所 | メモ |
|---|---|---|
| 手順0（検査） | 手順0 ＋ B `check` | |
| 手順A（読込→計算→保存） | 手順2 | **分割**：読込・整形・保存＝B `load_clean`、計算＝A `aggregate` |
| 手順B（開いたまま更新） | 手順3 ＋ B `live_update` | `xl_live.py` |
| 手順C（数式・書式を残す） | 「守るルール」 | 手順ではなく全手順共通のルール |
| 手順D（.xls・CSV） | 手順4 ＋ B `convert` | |
| 完了報告 | `SKILL.md`「完了報告」 | |
| `check_xlsx.py` | `scripts/check_xlsx.py` | 関数 `inspect_xlsx` に（CLIも残す） |
| `excel_tool.py` | `scripts/xl_io.py`（読込・型変換・エラー行・安全な保存）＋ `worker_a.py`（計算） | 先頭の設定（`REQUIRED_COLS` 等）はスクリプトを直さず**指示JSON**で渡す形に変えた。終了コード 0/1/2/3 は `teamcore.py` で踏襲 |
| `excel_live_update.py` | `scripts/xl_live.py` | 戻り値を（成功か, メッセージ）にした |
| `REFERENCE.md` | `references/ERRORS.md` | 担当の列を足した |

### 取り込みで変えた点（元の挙動との差）

- 計算は Python 値の書き込みから、**Excelの数式**（再計算して検算）に変えた
- ID別集計は SUMIFS でなく SUMPRODUCT（「001」と「1」を区別するため）
- `excel_tool.py` の1コマンド実行はなくした。同じ流れは手順2（`run_demo.py` 場面2）で再現できる

### v3 で追加したもの

| 追加 | 置き場所 | 役割 |
|---|---|---|
| 直接更新（入力セルだけ書いて保存） | `scripts/xl_direct.py`、worker_b の `update_cells` | B（ファイルの入出力）。計算の再確認だけ A の `recalc` を借りる |
| 試験 | `tests/run_tests.py`、`tests/excel_check.py`、`references/TESTING.md` | 役割に属さない（リーダーが実行して判定する） |
