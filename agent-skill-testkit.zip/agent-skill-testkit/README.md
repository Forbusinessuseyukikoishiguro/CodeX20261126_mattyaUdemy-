# agent-skill-testkit — Claude Code / Codex 両対応スキル＋Python 動作確認キット

1つのスキル（`.agents/skills/`）が、**Claude Code と Codex の両方で読めて、Pythonが動く**ことを確かめる。

## クイックスタート
```bash
pip install -r requirements.txt
python scripts/run_all.py            # ①②③（エージェント不要・数秒）
python scripts/run_all.py --e2e      # ＋④ 実際に claude / codex を起動（要ログイン・遅い）
```
E2E 用に Codex は Git リポジトリ内で動かすのが基本（`git init` 済みが望ましい。外でも `--skip-git-repo-check` で実行可）。

## 4層構成
| 層 | ファイル | 確認内容 | エージェント |
|---|---|---|---|
| ① 形式 | `tests/test_01_skill_format.py` | 仕様どおりの SKILL.md か／両者共通の項目だけか | 不要 |
| ② Python | `tests/test_02_excel_tool.py` | スクリプトのCLI・JSON・終了コード・日本語 | 不要 |
| ③ 配置 | `tests/test_03_discovery_paths.py` | `.claude/skills` と `.agents/skills` が一致 | 不要 |
| ④ E2E | `tests/e2e/test_04_agents.py` | 実エージェントがスキルを使い成果物を作る | 必要 |

①②③が通って④が落ちたら「スキルは正しいが、エージェント側の読み込み・権限・トリガーの問題」と切り分けられる。

## 公式の根拠（何をどの資料に基づいて検査しているか）
| 検査 | 根拠 |
|---|---|
| name: 1-64文字、小文字・数字・ハイフン、先頭末尾/連続ハイフン不可、ディレクトリ名と一致 | Agent Skills 仕様 https://agentskills.io/specification |
| description: 必須・1-1024文字 | 同上 |
| 標準の任意項目は license / compatibility / metadata / allowed-tools | 同上 |
| 参照は SKILL.md から1階層、`skills-ref validate` が公式バリデータ | 同上 |
| `.agents/skills` を探索、シンボリックリンクを辿る、`agents/openai.yaml` は任意 | Codex https://developers.openai.com/codex/skills |
| Claude Code は標準を拡張した独自項目を持つ（`disable-model-invocation` 等）、`.claude/skills`、フォルダ名 `synced` は予約 | https://code.claude.com/docs/en/skills |
| `codex exec` は既定 read-only、編集は `--sandbox workspace-write`、Git外は `--skip-git-repo-check`、`--full-auto` は非推奨 | OpenAI Codex「Non-interactive mode」 |
| `claude -p` / `--allowedTools` / `--permission-mode` / `--output-format json` | Claude Code CLI（解説記事でも確認。最新は `claude --help`） |
| name に `claude` `anthropic` を含めない | Anthropic のスキル作成ガイド |

## 設計上の判断
- **共通項目だけを使う**: `disable-model-invocation` 等のClaude Code独自項目は、他環境（claude.aiへのアップロード等）で弾かれることがある。①の `test_only_portable_keys` が検出する。Codex固有設定は `agents/openai.yaml` へ分離する。
- **成果物で判定**: LLMの返答は揺れる。トークン一致＋スクリプトのマーカー（`excel_tool.py` が書くブック作成者）でスキル使用を機械判定する。
- **named / implicit の2モード**: `implicit` はスキル名を出さず description だけで選ばれるか＝トリガー品質のテスト。落ちたら description の冒頭に用途とキーワードを前出しする。
- **LLMは確率的**: 再試行は `E2E_RETRIES`（既定1）。連続失敗のみ本当の失敗とみなす。

## 自分のスキルに適用する
1. `.agents/skills/<name>/` に自分のスキルを置く（`python-excel-spec` は見本）。
2. `python scripts/sync_claude_links.py`（Windowsでリンク不可ならコピーに自動切替。編集後は再実行）。
3. ②に自分のスクリプトのテストを足し、④の `PROMPTS` と検証部分を自分のスキルの成果物に合わせる。

## 環境変数
`E2E_AGENTS=claude,codex` / `E2E_RETRIES=1` / `E2E_TIMEOUT=300`

## 既知の限界
- ④はCLIのバージョン・ログイン・権限設定に依存する。バージョンは `.e2e_out/versions.txt` に記録される。
- Claude Code の `--allowedTools` の記法は版で変わりうるため、許可拒否は失敗メッセージに表示される。
- 検査は「公式仕様に沿っているか」と「動いたか」の確認であり、スキルの品質（指示の分かりやすさ等）の評価ではない。
