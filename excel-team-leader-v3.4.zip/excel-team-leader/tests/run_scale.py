#!/usr/bin/env python3
"""大量データの業務レベル試験：複数ファイル・複数タブの統合、列数・行数、複雑な数式、処理時間。

使い方: python tests/run_scale.py [作業フォルダ] [--files 3] [--tabs 3] [--rows 2000] [--cols 12] [--budget 600]
終了コード: 0=全部合格 / 1=不合格あり
確かめること:
  1 統合の行数（全体・タブごと）が、生成時の正解と一致する
  2 すべての数値列の合計が一致する（列の取り違えがない）
  3 列数が正しく、すべての列名が統合結果に入る
  4 複雑な数式（SUMIFS・COUNTIFS・AVERAGEIFS・SUMPRODUCT・IFERROR・構成比）を、統合結果の上で再計算し、正解と照合する
  5 処理時間が予算内（--budget 秒）。超えたら不合格
"""
import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "tests"))

from openpyxl import load_workbook  # noqa: E402
from openpyxl.styles import Font  # noqa: E402

import gen_testdata  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("work", nargs="?", default=str(ROOT / "work" / "scale"))
    ap.add_argument("--files", type=int, default=3)
    ap.add_argument("--tabs", type=int, default=3)
    ap.add_argument("--rows", type=int, default=2000)
    ap.add_argument("--cols", type=int, default=12)
    ap.add_argument("--budget", type=float, default=600)
    a = ap.parse_args()
    work = Path(a.work)
    if work.exists():
        shutil.rmtree(work)
    src = work / "src"
    t0 = time.time()
    exp = gen_testdata.generate(src, a.files, a.tabs, a.rows, a.cols)
    t_gen = time.time() - t0
    check("生成：ファイル数・タブ数が指定どおり", len(exp["files"]) == a.files and len(exp["by_tab"]) == a.files * a.tabs,
          f"{len(exp['by_tab'])}タブ")

    # 統合（ワーカーを実行して結果を見る）
    task = {"action": "merge_sheets", "out": str(work / "統合.xlsx"),
            "sources": [{"file": str(src / f), "sheets": "*"} for f in exp["files"]]}
    tf = work / "task.json"; tf.parent.mkdir(parents=True, exist_ok=True)
    tf.write_text(json.dumps(task, ensure_ascii=False), encoding="utf-8")
    t1 = time.time()
    cp = subprocess.run([sys.executable, str(ROOT / "scripts" / "worker_b.py"), str(tf)], capture_output=True, text=True)
    t_merge = time.time() - t1
    res = json.loads(cp.stdout.strip().splitlines()[-1]) if cp.stdout.strip() else {"status": "crash", "message": cp.stderr}
    check("統合：終了コード0・ok", cp.returncode == 0 and res.get("status") in ("ok", "warn"), res.get("message", "")[:120])

    # 1 行数
    wb = load_workbook(work / "統合.xlsx", read_only=True, data_only=True)
    ws = wb["統合"]
    rows = list(ws.iter_rows(values_only=True))
    header, data = list(rows[0]), rows[1:]
    check("行数：統合の全体が正解と一致", len(data) == exp["total_rows"], f"{len(data)} / 正解 {exp['total_rows']}")
    idx = {h: i for i, h in enumerate(header)}
    tab_counts = {}
    for r in data:
        k = f"{r[idx['元ファイル']]}|{r[idx['元シート']]}"
        tab_counts[k] = tab_counts.get(k, 0) + 1
    bad_tabs = [k for k, v in exp["by_tab"].items() if tab_counts.get(k) != v["rows"]]
    check("行数：タブごとの行数が一致", not bad_tabs, f"不一致 {bad_tabs[:3]}")

    # 2 数値列の合計 / 3 列数
    sums_bad = {}
    for c, e in exp["sums"].items():
        got = sum((r[idx[c]] or 0) for r in data if isinstance(r[idx[c]], (int, float)))
        if abs(got - e) > 1e-6:
            sums_bad[c] = (got, e)
    check("合計：すべての数値列の合計が一致", not sums_bad, str(dict(list(sums_bad.items())[:3])))
    want_cols = a.cols + 3  # 元ファイル・元シート・元の行番号 を加える
    check("列数：統合の列数が正しく、全列が入る", len(header) == want_cols and all(c in idx for c in exp["sums"]),
          f"統合の列数 {len(header)} / 正解 {want_cols}")

    # 4 複雑な数式：統合結果の上に集計タブを作り、再計算して正解と照合
    calc_wb = load_workbook(work / "統合.xlsx")
    s = calc_wb.create_sheet("集計")
    col = {h: chr(ord("A") + i) for i, h in enumerate(header) if i < 26}
    # 列記号（統合の列）：商品・数量・単価・金額
    P, Q, U, M = col["商品"], col["数量"], col["単価"], col["金額"]
    N = len(data) + 1
    heads = ["商品", "件数", "数量合計", "金額合計", "平均単価", "金額構成比", "税込金額(10%)"]
    for i, h in enumerate(heads, 1):
        s.cell(1, i, h).font = Font(name="Arial", bold=True)
    prods = sorted(exp["by_product"])
    for k, p in enumerate(prods, 2):
        s.cell(k, 1, p)
        s.cell(k, 2, f"=COUNTIFS(統合!${P}$2:${P}${N},A{k})")
        s.cell(k, 3, f"=SUMIFS(統合!${Q}$2:${Q}${N},統合!${P}$2:${P}${N},A{k})")
        s.cell(k, 4, f"=SUMIFS(統合!${M}$2:${M}${N},統合!${P}$2:${P}${N},A{k})")
        s.cell(k, 5, f"=IFERROR(AVERAGEIFS(統合!${U}$2:${U}${N},統合!${P}$2:${P}${N},A{k}),0)")
        s.cell(k, 6, f"=D{k}/SUM($D$2:$D${len(prods) + 1})")
        s.cell(k, 7, f"=ROUND(D{k}*1.1,0)")
    tot = len(prods) + 2
    s.cell(tot, 1, "合計")
    s.cell(tot, 2, f"=SUM(B2:B{tot - 1})")
    s.cell(tot, 4, f"=SUM(D2:D{tot - 1})")
    s.cell(tot + 1, 1, "数式の照合（SUMPRODUCT）")
    s.cell(tot + 1, 4, f"=SUMPRODUCT(統合!${M}$2:${M}${N})")
    calc_path = work / "数式検証.xlsx"
    calc_wb.save(calc_path)
    from worker_a import recalc
    t2 = time.time()
    ok, why = recalc(calc_path)
    t_calc = time.time() - t2
    check("数式：再計算が成功（LibreOffice）", ok, why)
    if ok:
        vs = load_workbook(calc_path, data_only=True)["集計"]
        mism = []
        for k, p in enumerate(prods, 2):
            e = exp["by_product"][p]
            got = {"件数": vs.cell(k, 2).value, "数量合計": vs.cell(k, 3).value,
                   "金額合計": vs.cell(k, 4).value, "平均単価": vs.cell(k, 5).value}
            for key in ("件数", "数量合計", "金額合計"):
                if got[key] is None or abs(got[key] - e[key]) > 1e-6:
                    mism.append((p, key, got[key], e[key]))
            if got["平均単価"] is None or abs(got["平均単価"] - e["平均単価"]) > 1e-3:
                mism.append((p, "平均単価", got["平均単価"], e["平均単価"]))
        check("数式：商品別の件数・数量・金額・平均が正解と一致", not mism, str(mism[:3]))
        total_amt = exp["sums"]["金額"]
        check("数式：構成比の合計が100%", abs(sum(vs.cell(k, 6).value for k in range(2, len(prods) + 2)) - 1) < 1e-9)
        check("数式：金額合計（SUM）と SUMPRODUCT が一致", abs(vs.cell(tot, 4).value - total_amt) < 1e-6
              and abs(vs.cell(tot + 1, 4).value - total_amt) < 1e-6)
        check("数式：税込（ROUND）が正しい", vs.cell(2, 7).value == round(vs.cell(2, 4).value * 1.1))

    # 5 時間
    t_total = time.time() - t0
    check(f"時間：予算 {a.budget:.0f} 秒以内", t_total <= a.budget, f"合計 {t_total:.1f} 秒")

    print(f"== 大規模試験（{a.files}ファイル × {a.tabs}タブ × 約{a.rows}行 × {a.cols}列）")
    print(f"   生成 {t_gen:.1f}s / 統合 {t_merge:.1f}s / 数式の再計算 {t_calc:.1f}s / 合計 {t_total:.1f}s")
    w = max(len(n) for n, _, _ in results)
    for name, ok, detail in results:
        print(f"[{'OK' if ok else 'NG'}] {name.ljust(w)}  {'' if ok else detail}")
    failed = [r for r in results if not r[1]]
    print(f"合計 {len(results)} 件 / 合格 {len(results) - len(failed)} / 不合格 {len(failed)}")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
