#!/usr/bin/env python3
"""この一式の試験（K1〜K13）。使い方: python tests/run_kit_tests.py [作業フォルダ]  終了コード 0=全部合格

  K1  要件と試験の対応（サンプル）：全要件に試験がある
  K2  試験のタグを消すと、未カバーとして検出される
  K3  設計書に無いIDのタグは、宙に浮いたタグとして検出される
  K4  品質ゲート（開発中）：サンプルは合格
  K5  品質ゲート（リリース前）：手動試験の未実施があると不合格、開発中は注意のみ
  K6  試験が失敗すると、品質ゲートは不合格
  K7  秘密情報らしき記述を検出し、中身は出さない
  K8  図が閉じていないと、Mermaid の検査で不合格
  K9  納品前レビュー：正しい回答は合格（終了コード0）
  K10 納品前レビュー：NGの回答は、仮の文字・断定・社外秘・数値の出典不足を検出（終了コード1）
  K11 納品前レビュー：税務の話題に専門家への確認が無いと、警告（終了コード0）
  K12 フック（Stop）：既定は書かない。--apply で、既存の設定を残して追加し、2回目は重複しない
  K13 フック（Stop）の動き：不合格なら終了コード2、合格・stop_hook_active なら0
"""
import json
import shutil
import subprocess
import sys
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
SCRIPTS = KIT / "scripts"
SAMPLE = KIT / "examples" / "sample_project"
WORK = Path(sys.argv[1]) if len(sys.argv) > 1 else KIT / "work" / "kit_tests"
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))


def run(args, cwd=None, stdin=None):
    return subprocess.run([sys.executable] + [str(a) for a in args], cwd=cwd, input=stdin,
                          capture_output=True, text=True, encoding="utf-8", timeout=900)


def fresh_copy(name):
    dst = WORK / name
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(SAMPLE, dst, ignore=shutil.ignore_patterns("work", "__pycache__"))
    return dst


def main():
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir(parents=True)

    # K1
    cp = run([SCRIPTS / "spec_trace.py", SAMPLE])
    check("K1 要件と試験の対応：全要件に試験がある", cp.returncode == 0 and "要件ID: 4件 / テストで対応: 4件" in cp.stdout, cp.stdout[:120])

    # K2 タグを消す
    p = fresh_copy("k2")
    t = p / "tests" / "test_tax.py"
    t.write_text(t.read_text(encoding="utf-8").replace("# REQ: FR-002", "# （タグ無し）"), encoding="utf-8")
    cp = run([SCRIPTS / "spec_trace.py", p])
    check("K2 タグを消すと、未カバーとして検出される", cp.returncode == 1 and "未カバー：FR-002" in cp.stdout, cp.stdout[-120:])

    # K3 宙に浮いたタグ
    p = fresh_copy("k3")
    t = p / "tests" / "test_tax.py"
    t.write_text(t.read_text(encoding="utf-8").replace("# REQ: NFR-001", "# REQ: NFR-099"), encoding="utf-8")
    cp = run([SCRIPTS / "spec_trace.py", p])
    check("K3 設計書に無いIDのタグは、宙に浮いたタグとして検出される", cp.returncode == 1 and "NFR-099" in cp.stdout)

    # K4 開発中の品質ゲート
    cp = run([SCRIPTS / "quality_gate.py", SAMPLE])
    check("K4 品質ゲート（開発中）：サンプルは合格", cp.returncode == 0 and "総合：合格" in cp.stdout, cp.stdout[-200:])

    # K5 リリース前
    cp = run([SCRIPTS / "quality_gate.py", SAMPLE, "--release"])
    check("K5 リリース前：手動試験の未実施があると不合格", cp.returncode == 1 and "G6" in cp.stdout and "FAIL" in cp.stdout)
    cp = run([SCRIPTS / "quality_gate.py", SAMPLE])
    check("K5 開発中：手動試験の未実施は注意（INFO）で、合格のまま", cp.returncode == 0 and "| INFO |" in cp.stdout)

    # K6 試験の失敗
    p = fresh_copy("k6")
    t = p / "tests" / "test_tax.py"
    t.write_text(t.read_text(encoding="utf-8").replace("1100)", "1101)"), encoding="utf-8")
    cp = run([SCRIPTS / "quality_gate.py", p])
    check("K6 試験が失敗すると、品質ゲートは不合格", cp.returncode == 1 and "G2" in cp.stdout and "失敗" in cp.stdout)

    # K7 秘密情報（中身は出さない）
    p = fresh_copy("k7")
    secret = "sk-TESTSECRETabcdefghijklmnop1234"
    (p / "src" / "config.py").write_text(f'API_KEY = "{secret}"\n', encoding="utf-8")
    cp = run([SCRIPTS / "quality_gate.py", p])
    check("K7 秘密情報らしき記述を検出する", cp.returncode == 1 and "G5" in cp.stdout)
    check("K7 検出の表示に、秘密の中身を出さない", secret not in cp.stdout and secret not in (p / "work" / "quality_report.md").read_text(encoding="utf-8"))

    # K8 図が閉じていない
    p = fresh_copy("k8")
    s = p / "spec" / "設計書.md"
    s.write_text(s.read_text(encoding="utf-8").replace("F([結果：税込金額])\n```", "F([結果：税込金額])\n"), encoding="utf-8")
    cp = run([SCRIPTS / "quality_gate.py", p])
    check("K8 図が閉じていないと、Mermaid の検査で不合格", cp.returncode == 1 and "G4" in cp.stdout and "閉じていない" in cp.stdout)

    # K9〜K11 納品前レビュー
    pol = KIT / "hooks" / "delivery_policy.json"
    ans = SAMPLE / "answers"
    cp = run([SCRIPTS / "review_delivery.py", ans / "回答_OK.md", "--policy", pol, "--out", WORK / "r1.md"])
    check("K9 納品前レビュー：正しい回答は合格", cp.returncode == 0 and "渡してよい" in cp.stdout, cp.stdout[:120])
    cp = run([SCRIPTS / "review_delivery.py", ans / "回答_NG.md", "--policy", pol, "--out", WORK / "r2.md"])
    need = ["B1", "B2", "B3", "B4"]
    check("K10 NGの回答：仮の文字・断定・社外秘・見出し不足を検出",
          cp.returncode == 1 and all(f"[{b}]" in cp.stdout for b in need), cp.stdout[:200])
    p5 = WORK / "unsourced.md"
    p5.write_text("# 結論\n\n合計は 99,999円です。\n\n# 根拠\n\n- 別の数字 1,000円\n\n# 次のアクション\n\nご確認ください。\n", encoding="utf-8")
    cp = run([SCRIPTS / "review_delivery.py", p5, "--policy", pol, "--out", WORK / "r5.md"])
    check("K10 数値の出典が無い場合は B5 で止まる", cp.returncode == 1 and "[B5]" in cp.stdout and "99,999円" in cp.stdout)
    cp = run([SCRIPTS / "review_delivery.py", ans / "回答_税務.md", "--policy", pol, "--out", WORK / "r3.md"])
    check("K11 税務の話題に専門家への確認が無いと警告（終了コード0）", cp.returncode == 0 and "[W1]" in cp.stdout, cp.stdout[:160])

    # K12 フックの導入（既定は書かない・既存を残す・重複しない）
    p = WORK / "hookproj"
    (p / ".claude").mkdir(parents=True)
    (p / ".claude" / "settings.json").write_text(json.dumps({"model": "keep", "hooks": {"PreToolUse": []}}), encoding="utf-8")
    before = (p / ".claude" / "settings.json").read_text(encoding="utf-8")
    run([SCRIPTS / "install_hooks.py", p, "--claude"])
    check("K12 既定（確認のみ）は書かない", (p / ".claude" / "settings.json").read_text(encoding="utf-8") == before)
    run([SCRIPTS / "install_hooks.py", p, "--claude", "--apply"])
    d = json.loads((p / ".claude" / "settings.json").read_text(encoding="utf-8"))
    check("K12 --apply で Stop を追加し、既存の設定は残す", "Stop" in d["hooks"] and d["model"] == "keep" and "PreToolUse" in d["hooks"])
    run([SCRIPTS / "install_hooks.py", p, "--claude", "--apply"])
    d = json.loads((p / ".claude" / "settings.json").read_text(encoding="utf-8"))
    check("K12 2回目は重複しない", len(d["hooks"]["Stop"]) == 1)

    # K13 フックの動き
    cp = run([SCRIPTS / "quality_gate.py", "--hook"], stdin=json.dumps({"cwd": str(SAMPLE)}))
    check("K13 フック：合格なら終了コード0", cp.returncode == 0, cp.stderr[:120])
    cp = run([SCRIPTS / "quality_gate.py", "--hook"], stdin=json.dumps({"cwd": str(WORK / "k6")}))
    check("K13 フック：不合格なら終了コード2（理由を表示）", cp.returncode == 2 and "品質ゲートで不合格" in cp.stderr)
    cp = run([SCRIPTS / "quality_gate.py", "--hook"], stdin=json.dumps({"cwd": str(WORK / "k6"), "stop_hook_active": True}))
    check("K13 フック：stop_hook_active なら止めない（終了コード0）", cp.returncode == 0)

    width = max(len(n) for n, _, _ in results)
    print("== 仕様駆動開発の一式の試験")
    for name, ok, detail in results:
        print(f"[{'OK' if ok else 'NG'}] {name.ljust(width)}  {'' if ok else detail}")
    failed = [r for r in results if not r[1]]
    print(f"合計 {len(results)} 件 / 合格 {len(results) - len(failed)} / 不合格 {len(failed)}")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
