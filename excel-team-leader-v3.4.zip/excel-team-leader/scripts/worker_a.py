#!/usr/bin/env python3
"""A：計算担当。Excelに「数式」を入れ、再計算して、Pythonの期待値と照合する。入出力の細部はしない（それはB）。"""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter as L

import teamcore
from teamcore import InputError

FMT = "#,##0"


def _num(v, what):
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise InputError(f"数値ではない値があります（{what}）: {v!r}")
    return v


def recalc(path: Path):
    """LibreOfficeで再計算し、数式＋計算済み値のファイルに置き換える。戻り値: (成功か, 理由)。"""
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return False, "soffice無し：数式は入力済み・再計算は未確認"
    try:
        with tempfile.TemporaryDirectory() as td:
            cp = subprocess.run([soffice, "--headless", "--convert-to", "xlsx", "--outdir", td, str(path)],
                                capture_output=True, text=True, timeout=120)
            out = Path(td) / path.name
            if cp.returncode != 0 or not out.exists():
                return False, f"再計算に失敗: {cp.stderr[:200]}"
            shutil.copy(out, path)
    except subprocess.TimeoutExpired:
        return False, "再計算が時間切れ"
    return True, ""


def verify(path: Path, expected: dict, do_recalc: bool):
    """expected: {(シート,行,列): 期待値}。戻り値は結果dict。"""
    if not do_recalc:
        return {"status": "not_verified", "message": "数式を入力（再計算は指示なし）"}
    ok, why = recalc(path)
    if not ok:
        return {"status": "not_verified", "message": why}
    wb = load_workbook(path, data_only=True)
    diff = {}
    for (sh, r, c), exp in expected.items():
        got = wb[sh].cell(r, c).value
        if got is None or abs(got - exp) > 1e-6:
            diff[f"{sh}!{L(c)}{r}"] = (got, exp)
    if diff:
        return {"status": "ng", "kind": "verify", "message": f"検算が不一致(実際,期待): {dict(list(diff.items())[:5])}"}
    return {"status": "ok", "message": f"再計算・検算OK（{len(expected)}セル）"}


def add_formulas(t):
    """単価×数量の小計列と、合計・税率・消費税・税込合計を数式で追加する。"""
    path, sheet, rate = Path(t["file"]), t.get("sheet", "入力"), t.get("tax_rate", 0.1)
    wb = load_workbook(path)
    if sheet not in wb.sheetnames:
        raise InputError(f"シート '{sheet}' がありません: {wb.sheetnames}")
    ws = wb[sheet]
    head = {c.value: c.column for c in ws[1]}
    if "単価" not in head or "数量" not in head:
        raise InputError("ヘッダー「単価」「数量」が見つからない")
    pu, qty, last = head["単価"], head["数量"], ws.max_row
    subtotal = sum(_num(ws.cell(r, pu).value, f"単価{r}行") * _num(ws.cell(r, qty).value, f"数量{r}行")
                   for r in range(2, last + 1))
    tax_v = round(subtotal * rate)
    sub = ws.max_column + 1
    ws.cell(1, sub, "小計").font = Font(name="Arial", bold=True)
    for r in range(2, last + 1):
        ws.cell(r, sub, f"={L(pu)}{r}*{L(qty)}{r}").number_format = FMT
    S = L(sub)
    total, rt, tax, gross = last + 2, last + 3, last + 4, last + 5
    ws.cell(total, 1, "合計")
    ws.cell(total, sub, f"=SUM({S}2:{S}{last})")
    ws.cell(rt, 1, "税率（入力）")
    ws.cell(rt, sub, rate).font = Font(name="Arial", color="0000FF")
    ws.cell(rt, sub).number_format = "0.0%"
    ws.cell(tax, 1, "消費税")
    ws.cell(tax, sub, f"=ROUND({S}{total}*{S}{rt},0)")
    ws.cell(gross, 1, "税込合計")
    ws.cell(gross, sub, f"={S}{total}+{S}{tax}")
    for r in (total, tax, gross):
        ws.cell(r, sub).number_format = FMT
    wb.save(path)
    exp = {(sheet, total, sub): subtotal, (sheet, tax, sub): tax_v, (sheet, gross, sub): subtotal + tax_v}
    return verify(path, exp, t.get("recalc", True))


def aggregate(t):
    """明細シートに「金額」を数式で入れ、ID別の「集計」シート（件数・数量合計・金額合計）を数式で作る。
    ※ IDの一致は SUMPRODUCT で厳密に比べる（COUNTIF/SUMIFSは「001」と「1」を同じと見なすため）。"""
    path, sheet = Path(t["file"]), t.get("sheet", "明細")
    idc, qc, pc = t.get("id_col", "ID"), t.get("qty_col", "数量"), t.get("price_col", "単価")
    wb = load_workbook(path)
    if sheet not in wb.sheetnames:
        raise InputError(f"シート '{sheet}' がありません: {wb.sheetnames}")
    ws = wb[sheet]
    head = {str(c.value): c.column for c in ws[1] if c.value is not None}
    missing = [c for c in (idc, qc, pc) if c not in head]
    if missing:
        raise InputError(f"必要な列がありません: {missing}")
    last = ws.max_row
    if last < 2:
        raise InputError("明細が1行もありません")
    amt = head.get("金額") or ws.max_column + 1  # 再実行しても列が増えない
    ws.cell(1, amt, "金額").font = Font(name="Arial", bold=True)
    per = {}
    for r in range(2, last + 1):
        i, q, p = str(ws.cell(r, head[idc]).value), _num(ws.cell(r, head[qc]).value, f"数量{r}行"), _num(ws.cell(r, head[pc]).value, f"単価{r}行")
        ws.cell(r, amt, f"={L(head[qc])}{r}*{L(head[pc])}{r}").number_format = FMT
        n, s, m = per.get(i, (0, 0, 0))
        per[i] = (n + 1, s + q, m + q * p)
    if "集計" in wb.sheetnames:
        del wb["集計"]
    sm = wb.create_sheet("集計")
    for c, h in enumerate(["ID", "件数", "数量合計", "金額合計"], 1):
        sm.cell(1, c, h).font = Font(name="Arial", bold=True)
    q_ = f"'{sheet}'!${{c}}$2:${{c}}${last}"
    rid, rq, ra = (q_.format(c=L(head[idc])), q_.format(c=L(head[qc])), q_.format(c=L(amt)))
    exp = {}
    for row, (i, (n, s, m)) in enumerate(sorted(per.items(), key=lambda kv: (-kv[1][2], kv[0])), 2):
        sm.cell(row, 1, i).number_format = "@"  # 先頭の0を守る
        sm.cell(row, 2, f"=SUMPRODUCT(--({rid}=A{row}))")
        sm.cell(row, 3, f"=SUMPRODUCT(({rid}=A{row})*{rq})")
        sm.cell(row, 4, f"=SUMPRODUCT(({rid}=A{row})*{ra})")
        for c in (3, 4):
            sm.cell(row, c).number_format = FMT
        exp.update({("集計", row, 2): n, ("集計", row, 3): s, ("集計", row, 4): m})
    sm.freeze_panes = "A2"
    wb.save(path)
    return verify(path, exp, t.get("recalc", True))


ACTIONS = {"add_formulas": add_formulas, "aggregate": aggregate}

if __name__ == "__main__":
    teamcore.main("worker_a", ACTIONS)
