---
name: excel-python
description: PythonでExcelの読込・検査・計算・保存・更新を安全に行う。「Excelを集計して」「xlsxを更新して」「Excelを開いたまま更新」で使う。CSV変換やWord・PDF作成では使わない。
---

# excel-python

## 使う場面
- Excelの読込・集計・計算・保存を自動化したいとき
- 開いたままのExcelを更新したいとき、エラー（PermissionError など）を直したいとき
- 使わない: Word・PDF・PowerPoint の作成、Excel を使わない純粋な CSV 処理

## 最初に判断する
入力を見て、次のどれかに分ける。

| 状況 | 進む手順 |
|---|---|
| ファイルが開けるか不明 | 手順0（検査）から始める |
| 読込・集計・別ファイルに保存 | 手順A |
| Excelを開いたまま更新したい | 手順B |
| 数式・書式・グラフを残して編集 | 手順C |
| .xls や CSV | 手順D |

迷ったら推測で埋めず、「不明」と書いてユーザーに1つだけ質問する。

## 手順0（検査）
1. `python scripts/check_xlsx.py <ファイル> --require 列名1 列名2` を実行する
2. NG が出たら、その内容を報告して止まる（直すのは人が確認してから）

## 手順A（読込→計算→保存）
1. `scripts/excel_tool.py` の冒頭の設定（`REQUIRED_COLS` など）を、対象の表に合わせて直す
2. `python scripts/excel_tool.py 入力.xlsx --sheet シート名 --out 出力.xlsx`
3. 終了コード 0=成功 / 1=入力の問題 / 2=保存の問題 / 3=想定外。1〜3 は理由を報告する
4. 不正な行は止めず「エラー行」シートに出る。件数を完了報告に書く

## 手順B（開いたまま更新）
1. Excel がインストールされた Windows / Mac か確認する。違えば手順Aに切り替える
2. `scripts/excel_live_update.py` の `update_excel()` を使う（xlwings）
3. 書けなかった場合は、日付つきの別ファイルに保存される。その旨を必ず報告する
4. 実機で未確認の環境では、まず別のテストファイルで試すよう伝える

## 手順C（数式・書式を残す）
- 元ファイルは直接更新せず、別名で出力する
- openpyxl で `data_only=True` で開いたものは保存しない（数式が消える）
- 数式は計算結果ではなく、数式のまま書く

## 手順D（.xls と CSV）
- .xls は .xlsx に変換してから処理する
- CSV の文字コードは `utf-8-sig` か `cp932` を明示する

## 完了報告
- やったこと / 出力ファイル名 / 処理行数とエラー行数
- 未対応・未確認の点（実機で試していない手順など）

## 参照
- よくあるエラーと対策: [references/REFERENCE.md](references/REFERENCE.md)
