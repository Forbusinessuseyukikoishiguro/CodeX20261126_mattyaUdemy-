#!/usr/bin/env python3
"""お知らせ（処理中・進捗・残り時間・完了・エラー）を、選んだ話し方で出す。

話し方（voice）:
  nyanko      にゃんこ版（既定）：キャラクターの語り口
  secretary   秘書版：丁寧なビジネス敬語
  desu_masu   ですます版：やわらかい丁寧語
指定方法：指示JSONの "voice"、または環境変数 TEAM_VOICE。未知の名前は nyanko にする。

出力先は標準エラー（stderr）。結果のJSONは標準出力だけにする（機械が読むため）。
残り時間は、実際に進んだ速さから計算する。計算できないときは推測せず、まだ計算中と伝える。
絵文字は使わない（Windowsの日本語コンソールで文字化けするため）。
"""
from __future__ import annotations

import sys
import time

VOICES = ("nyanko", "secretary", "desu_masu")
DEFAULT_VOICE = "nyanko"

MSG = {
    "nyanko": {
        "prefix": "にゃんこ：",
        "start": "処理中だにゃー（{label}）。ちょっと待ってね！",
        "eta_far": "おおよそ後{m}分で終わる予定ですにゃ",
        "eta_soon": "もうすぐ終わるニャー",
        "eta_none": "まだ計算中だにゃ",
        "progress": "{label}：{done}/{total} 完了 {pct}%{extra}",
        "done": "終わったニャー！（{label}・{sec}秒）",
        "warn": "ちょっと気になることがあるにゃ：{msg}",
        "ng_head": "ごめんニャー、エラーが出ちゃった…。",
        "ng_msg": "エラー内容：{msg}",
        "ng_hint": "原因のめやす：{hint}",
        "ng_fix": "やってみてほしいこと：{fix}",
        "ng_log": "ログはここにあるにゃ：{log}",
        "ask_head": "わからないことがあるから、教えてくれる？",
    },
    "secretary": {
        "prefix": "秘書：",
        "start": "処理を開始いたします（{label}）。少々お待ちくださいませ。",
        "eta_far": "終了までおよそ{m}分を見込んでおります。",
        "eta_soon": "まもなく終了いたします。",
        "eta_none": "所要時間は算出中でございます。",
        "progress": "{label}：{done}/{total} 完了（{pct}%）{extra}",
        "done": "完了いたしました。（{label}・{sec}秒）",
        "warn": "念のためご確認くださいませ：{msg}",
        "ng_head": "申し訳ございません。処理中にエラーが発生いたしました。",
        "ng_msg": "内容：{msg}",
        "ng_hint": "考えられる原因：{hint}",
        "ng_fix": "ご対応のお願い：{fix}",
        "ng_log": "ログの保存先：{log}",
        "ask_head": "確認させていただきたい点がございます。",
    },
    "desu_masu": {
        "prefix": "お知らせ：",
        "start": "処理を開始します（{label}）。しばらくお待ちください。",
        "eta_far": "終わるまで、およそ{m}分ほどかかる見込みです。",
        "eta_soon": "まもなく終わります。",
        "eta_none": "まだ所要時間を計算中です。",
        "progress": "{label}：{done}/{total} 完了（{pct}%）{extra}",
        "done": "完了しました。（{label}・{sec}秒）",
        "warn": "ご確認いただきたい点があります：{msg}",
        "ng_head": "エラーが発生しました。",
        "ng_msg": "エラー内容：{msg}",
        "ng_hint": "原因のめやす：{hint}",
        "ng_fix": "対処方法：{fix}",
        "ng_log": "ログの場所：{log}",
        "ask_head": "確認させてください。",
    },
}

_voice = DEFAULT_VOICE


def set_voice(name: str | None) -> str:
    """話し方を決める。未知の名前は既定（にゃんこ）にする。戻り値は実際に使う話し方。"""
    global _voice
    _voice = name if name in VOICES else DEFAULT_VOICE
    return _voice


def voice() -> str:
    return _voice


def _t(key: str, **kw) -> str:
    return MSG[_voice][key].format(**kw)


def say(text: str) -> None:
    print(f"{MSG[_voice]['prefix']}{text}", file=sys.stderr, flush=True)


def start(label: str) -> None:
    say(_t("start", label=label))


def eta_text(elapsed: float, done: int, total: int) -> str:
    """残り時間の言葉。実測の速さから計算する。"""
    if done <= 0:
        return _t("eta_none")
    if total <= done:
        return ""
    remaining = elapsed / done * (total - done)
    if remaining < 60:
        return _t("eta_soon")
    return _t("eta_far", m=round(remaining / 60))


class Progress:
    """段階（シート・ファイルなど）ごとに進捗を知らせる。残り時間は実測の速さから出す。"""

    def __init__(self, label: str, total: int):
        self.label, self.total, self.done = label, max(total, 1), 0
        self.t0 = time.time()
        self._last_pct = -1
        start(f"{label} {self.total}段階")

    def step(self, note: str = "") -> None:
        self.done += 1
        pct = int(self.done * 100 / self.total)
        elapsed = time.time() - self.t0
        # 段階が多いときは10%刻み、少ないときは毎回知らせる
        if self.total > 10 and pct // 10 == self._last_pct // 10 and self.done != self.total:
            return
        self._last_pct = pct
        eta = eta_text(elapsed, self.done, self.total)
        extra = f"（{note}）" if note else ""
        line = _t("progress", label=self.label, done=self.done, total=self.total, pct=pct, extra=extra)
        say(line + (f"。{eta}" if eta and _voice == "nyanko" else (f" {eta}" if eta else "")))


def done(label: str, seconds: float) -> None:
    say(_t("done", label=label, sec=f"{seconds:.1f}"))


def warn(message: str) -> None:
    say(_t("warn", msg=message))


def ng(message: str, hint: str = "", fix: str = "", log_file: str | None = None) -> None:
    say(_t("ng_head"))
    say(_t("ng_msg", msg=message))
    if hint:
        say(_t("ng_hint", hint=hint))
    if fix:
        say(_t("ng_fix", fix=fix))
    if log_file:
        say(_t("ng_log", log=log_file))


def ask(questions: list[str]) -> None:
    say(_t("ask_head"))
    for i, q in enumerate(questions, 1):
        say(f"  {i}. {q}")
