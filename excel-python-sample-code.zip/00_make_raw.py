# openpyxl から「新しいExcelブック」を作る部品 Workbook を取り込む
from openpyxl import Workbook

# 空のブックを1冊つくる
wb = Workbook()
# 最初のシートを取り出す
ws = wb.active
# シートの名前を「Sheet1」にする
ws.title = "Sheet1"
# 1行目に見出し(列名)を書く。append は「いちばん下の行に1行足す」
ws.append(["ID", "日付", "数量", "単価"])
# 先頭が0のIDは、数字ではなく文字(文字列)として渡す
ws.append(["001", "2026-11-01", 10, 120])
# 日付の書き方がバラバラな行(スラッシュ区切り)
ws.append(["001", "2026/11/02", 2, 120])
# ふつうの行
ws.append(["002", "2026-11-03", 5, 300])
# 数量が「abc」という不正な行(わざと)
ws.append(["003", "2026-11-04", "abc", 80])
# ふつうの行
ws.append(["002", "2026-11-05", 1, 300])
# raw.xlsx という名前で保存する
wb.save("raw.xlsx")
# 保存できたことを知らせる
print("raw.xlsx を作りました（5行のデータ）")
