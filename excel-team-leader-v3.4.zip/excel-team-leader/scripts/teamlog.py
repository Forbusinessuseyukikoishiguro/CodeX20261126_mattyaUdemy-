#!/usr/bin/env python3
"""ログ：ファイル名は YYYYMMDDHHMM_log.txt、1行＝日時 | ステータス | 担当 | メッセージ。
保存先は任意（優先順：引数 log_dir ＞ タスクJSONの log_dir ＞ 環境変数 TEAM_LOG_DIR ＞ work/logs）。

Pythonから:   import teamlog; teamlog.write("OK", "保存した", "worker_b", "D:/logs")
コマンドから: python teamlog.py write --status INFO --message "開始" --worker leader --log-dir D:/logs
              python teamlog.py show --log-dir D:/logs --status NG --tail 20
"""
import argparse
import os
import sys
from datetime import datetime
from pathlib import Path

NAME_FORMAT = "%Y%m%d%H%M"  # ← ファイル名の日時形式。秒まで要るなら %Y%m%d%H%M%S
STATUS_MAP = {"ok": "OK", "ng": "NG", "not_verified": "WARN", "warn": "WARN", "info": "INFO"}


def log_dir_of(log_dir=None):
    return Path(log_dir or os.environ.get("TEAM_LOG_DIR") or "work/logs")


def log_path(log_dir=None):
    # TEAM_LOG_STAMP を決めておくと、1回の実行を1ファイルにまとめられる
    stamp = os.environ.get("TEAM_LOG_STAMP") or datetime.now().strftime(NAME_FORMAT)
    return log_dir_of(log_dir) / f"{stamp}_log.txt"


def write(status, message, worker="-", log_dir=None):
    """1行追記してパスを返す。ログの失敗で本処理は止めない（警告だけ出す）。"""
    st = STATUS_MAP.get(str(status).lower(), str(status).upper())
    msg = " ".join(str(message).split())  # 改行は1行にまとめる
    line = f"{datetime.now():%Y-%m-%d %H:%M:%S} | {st} | {worker} | {msg}\n"
    try:
        p = log_path(log_dir)
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "a", encoding="utf-8") as f:
            f.write(line)
        return p
    except OSError as e:
        print(f"[teamlog] ログを書けません: {e}", file=sys.stderr)
        return None


def show(log_dir=None, status=None, tail=20):
    d = log_dir_of(log_dir)
    files = sorted(d.glob("*_log.txt")) if d.exists() else []
    if not files:
        print(f"ログなし: {d}")
        return 1
    print(f"# {files[-1]}")
    lines = files[-1].read_text(encoding="utf-8").splitlines()
    if status:
        lines = [x for x in lines if f"| {status.upper()} |" in x]
    print("\n".join(lines[-tail:]))
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    w = sub.add_parser("write")
    w.add_argument("--status", default="INFO")
    w.add_argument("--message", required=True)
    w.add_argument("--worker", default="leader")
    w.add_argument("--log-dir")
    s = sub.add_parser("show")
    s.add_argument("--log-dir")
    s.add_argument("--status")
    s.add_argument("--tail", type=int, default=20)
    a = ap.parse_args()
    if a.cmd == "write":
        p = write(a.status, a.message, a.worker, a.log_dir)
        print(p or "書き込み失敗")
        sys.exit(0 if p else 1)
    sys.exit(show(a.log_dir, a.status, a.tail))
