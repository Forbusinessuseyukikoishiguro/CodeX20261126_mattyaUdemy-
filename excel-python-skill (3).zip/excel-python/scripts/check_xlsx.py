#!/usr/bin/env python3
"""Excelファイルの事前検査。判定はスクリプトが行う。
使い方: python scripts/check_xlsx.py <ファイル> [--sheet 名] [--require 列名 ...]
終了コード: 0=OK / 1=NG
"""
import argparse
import sys
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("file", type=Path)
    ap.add_argument("--sheet", default=None)
    ap.add_argument("--require", nargs="*", default=[])
    a = ap.parse_args()
    p = a.file

    if not p.exists():
        print(f"NG: ファイルがありません: {p}"); return 1
    if p.suffix.lower() not in (".xlsx", ".xlsm"):
        print(f"NG: 対応していない形式です: {p.suffix}（.xls は .xlsx に変換してください）"); return 1
    if p.stat().st_size == 0:
        print("NG: ファイルが空です"); return 1

    lock = p.with_name(f"~${p.name}")
    if lock.exists():
        print(f"注意: ロックファイル {lock.name} があります。Excelで開かれている可能性があります（読み取りは可、書き込みは不可）")

    try:
        from openpyxl import load_workbook
        wb = load_workbook(p, read_only=True, data_only=True)
    except PermissionError:
        print("NG: ファイルを開けません。Excelで開いたままではありませんか"); return 1
    except Exception as e:
        print(f"NG: 読み込めません（壊れている可能性）: {e}"); return 1

    print(f"OK: シート {wb.sheetnames}")
    name = a.sheet or wb.sheetnames[0]
    if name not in wb.sheetnames:
        print(f"NG: シート '{name}' がありません"); return 1
    header = next(wb[name].iter_rows(min_row=1, max_row=1, values_only=True), ())
    cols = [str(c).replace("\u3000", " ").strip() for c in header if c is not None]
    print(f"OK: 1行目の列名 {cols}")
    missing = [c for c in a.require if c not in cols]
    if missing:
        print(f"NG: 必須の列がありません: {missing}"); return 1
    print("OK: 検査を通りました"); return 0


if __name__ == "__main__":
    sys.exit(main())
