#!/usr/bin/env python3
"""リーダーの代わりに指示JSONを書いて、B→A→Bを順に動かすデモ（2場面）。
使い方: python run_demo.py [ログ保存先フォルダ]   ← 保存先は任意の場所を指定できる
  場面1：新規入力 → 数式で計算          （B write_input → A add_formulas → B read_back）
  場面2：既存の汚れた表 → 検査 → 集計    （B check → B load_clean → A aggregate → B read_back）＋ CSV変換
"""
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import teamlog  # noqa: E402

if len(sys.argv) > 1:
    os.environ["TEAM_LOG_DIR"] = sys.argv[1]
os.environ["TEAM_LOG_STAMP"] = datetime.now().strftime(teamlog.NAME_FORMAT)  # 1回の実行＝1ファイル

WORK = Path("work")
(WORK / "tasks").mkdir(parents=True, exist_ok=True)
S1 = str(WORK / "sales.xlsx")
RAW, CLEAN, CSV, CSVX = (str(WORK / n) for n in ("raw.xlsx", "clean.xlsx", "raw_cp932.csv", "from_csv.xlsx"))


def make_raw():
    """先頭0のID・日付の混在・不正な数量を含む『汚れた表』を作る（デモ用の入力）。"""
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    ws.append(["ID", "日付", "数量", "単価"])
    for r in (["001", "2026-11-01", "10", "120"], ["002", "2026/11/02", "5", "300"],
              ["001", "2026-11-03", "2", "120"], ["003", "2026-11-04", "abc", "80"], ["002", "2026-11-05", "1", "300"]):
        ws.append(r)
    wb.save(RAW)
    Path(CSV).write_bytes("ID,日付,数量,単価\n001,2026-11-01,10,120\n".encode("cp932"))


def run(name, script, task):
    tp = WORK / "tasks" / f"{name}.json"
    tp.write_text(json.dumps(task, ensure_ascii=False, indent=2), encoding="utf-8")
    p = subprocess.run([sys.executable, str(HERE / script), str(tp)], capture_output=True, text=True)
    res = json.loads(p.stdout)
    print(f"[{name}] {res['status']}: {res['message']}")
    if res["status"] == "ng":
        teamlog.write("ng", f"{name}で停止", "leader")
        sys.exit(1)
    for row in res.get("values", []):
        print("  ", row)


make_raw()
teamlog.write("info", "デモ開始", "leader")
print("== 場面1：新規入力 → 数式で計算")
run("01_b_write", "worker_b.py", {"action": "write_input", "file": S1, "sheet": "入力", "headers": ["品名", "単価", "数量"],
    "rows": [["りんご", 120, 10], ["みかん", 80, 25], ["ぶどう", 450, 3]]})
run("02_a_calc", "worker_a.py", {"action": "add_formulas", "file": S1, "sheet": "入力", "tax_rate": 0.1, "recalc": True})
run("03_b_read", "worker_b.py", {"action": "read_back", "file": S1, "sheet": "入力"})
print("== 場面2：汚れた表 → 検査 → 集計")
run("04_b_check", "worker_b.py", {"action": "check", "file": RAW, "sheet": "Sheet1", "require": ["ID", "日付", "数量", "単価"]})
run("05_b_load", "worker_b.py", {"action": "load_clean", "input": RAW, "sheet": "Sheet1", "out": CLEAN})
run("06_a_agg", "worker_a.py", {"action": "aggregate", "file": CLEAN, "sheet": "明細", "recalc": True})
run("07_b_read", "worker_b.py", {"action": "read_back", "file": CLEAN, "sheet": "集計"})
run("08_b_err", "worker_b.py", {"action": "read_back", "file": CLEAN, "sheet": "エラー行"})
print("== CSV（cp932）→ xlsx")
run("09_b_conv", "worker_b.py", {"action": "convert", "input": CSV, "out": CSVX})
run("10_b_conv_read", "worker_b.py", {"action": "read_back", "file": CSVX, "sheet": "データ"})
teamlog.write("ok", "デモ完了", "leader")
print("ログ:", teamlog.log_path())
