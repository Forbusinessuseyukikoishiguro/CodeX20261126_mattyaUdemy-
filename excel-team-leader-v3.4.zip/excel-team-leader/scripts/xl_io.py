#!/usr/bin/env python3
"""B（入出力）の部品：読込・型変換・エラー行の分離・安全な保存・CSV/.xls変換
（取り込み元 excel-python の excel_tool.py から「計算」以外を移した。設定は関数の引数で渡す＝スクリプトを書き換えない）。
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path

import pandas as pd

from teamcore import InputError, SaveError


def load(path: Path, sheet, required, text_cols) -> pd.DataFrame:
    try:
        # 全列を文字列で読む（先頭の0を守る。型変換は clean() で行う）
        df = pd.read_excel(path, sheet_name=sheet, dtype=str)
    except ValueError as e:
        raise InputError(f"シートを読めません（{sheet}）: {e}") from e
    except PermissionError as e:
        raise InputError(f"ファイルを開けません。Excelで開いたままではありませんか: {path}") from e
    except Exception as e:
        raise InputError(f"読み込みに失敗しました: {e}") from e
    df.columns = [str(c).replace("\u3000", " ").strip() for c in df.columns]  # 列名のゆれを吸収
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise InputError(f"必須の列がありません: {missing} / 実際の列: {list(df.columns)}")
    df = df.dropna(how="all")
    for c in text_cols:
        df[c] = df[c].astype("string").str.strip()
    return df.reset_index(drop=True)


def clean(df, text_cols, num_cols, date_cols):
    """戻り値: (正常な行, エラー行)。不正な行は止めずに理由つきで分ける。"""
    df = df.copy()
    for c in num_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    for c in date_cols:
        df[c] = pd.to_datetime(df[c], errors="coerce", format="mixed")  # 2026-11-01 と 2026/11/02 の混在OK
    reasons = pd.Series("", index=df.index)
    for c in text_cols:
        reasons += df[c].isna().map({True: f"{c}が空; ", False: ""})
    for c in list(num_cols) + list(date_cols):
        reasons += df[c].isna().map({True: f"{c}が不正または空; ", False: ""})
    bad_mask = reasons != ""
    bad = df[bad_mask].copy()
    bad.insert(0, "元の行番号", bad.index + 2)  # Excel上の行番号（見出し=1行目）
    bad["理由"] = reasons[bad_mask]
    return df[~bad_mask].copy(), bad


def save(path: Path, sheets: dict) -> None:
    """既存は退避→一時ファイルに書く→最後に1回だけ置き換え（途中で落ちても壊れない）。"""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise SaveError(f"保存先フォルダを作れません: {e}") from e
    if path.exists():
        backup = path.with_name(f"{path.stem}.bak_{datetime.now():%Y%m%d_%H%M%S}{path.suffix}")
        try:
            os.replace(path, backup)
        except PermissionError as e:
            raise SaveError(f"出力先を置き換えられません。Excelで開いていませんか: {path}") from e
    try:
        fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=path.parent)
    except OSError as e:
        raise SaveError(f"保存先に書けません（権限・容量など）: {e}") from e
    os.close(fd)
    try:
        with pd.ExcelWriter(tmp, engine="openpyxl", datetime_format="yyyy/mm/dd") as w:
            for name, frame in sheets.items():
                if frame.empty and name == "エラー行":
                    continue  # エラーが無ければ作らない
                n = name[:31]  # シート名は31字まで
                frame.to_excel(w, sheet_name=n, index=False)
                ws = w.sheets[n]
                ws.freeze_panes = "A2"
                ws.auto_filter.ref = ws.dimensions
                for col in ws.columns:
                    width = max(len(str(c.value)) if c.value is not None else 0 for c in col)
                    ws.column_dimensions[col[0].column_letter].width = min(max(width + 2, 8), 40)
        os.replace(tmp, path)
    except Exception as e:
        raise SaveError(f"保存に失敗しました: {e}") from e
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def convert(src: Path, out: Path) -> str:
    """CSV・.xls を .xlsx にする。CSVは utf-8-sig → cp932 の順に試す。"""
    ext = src.suffix.lower()
    if not src.exists():
        raise InputError(f"ファイルがありません: {src}")
    if ext in (".csv", ".tsv"):
        sep = "\t" if ext == ".tsv" else ","
        for enc in ("utf-8-sig", "cp932"):
            try:
                df = pd.read_csv(src, dtype=str, encoding=enc, sep=sep)
                save(out, {"データ": df})
                return f"CSVを変換（文字コード {enc}）"
            except UnicodeDecodeError:
                continue
        raise InputError("CSVの文字コードを判別できません（utf-8-sig / cp932 以外）")
    if ext == ".xls":
        try:
            df = pd.read_excel(src, dtype=str, engine="xlrd")
            save(out, {"データ": df})
            return "xlsを変換（xlrd）"
        except ImportError:
            pass  # xlrd無し → LibreOfficeで変換
        soffice = shutil.which("soffice") or shutil.which("libreoffice")
        if not soffice:
            raise InputError(".xlsを変換できません（xlrd も LibreOffice も無い）")
        with tempfile.TemporaryDirectory() as td:
            subprocess.run([soffice, "--headless", "--convert-to", "xlsx", "--outdir", td, str(src)],
                           capture_output=True, text=True, timeout=120)
            made = Path(td) / f"{src.stem}.xlsx"
            if not made.exists():
                raise InputError("LibreOfficeで.xlsを変換できませんでした")
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(made, out)
        return "xlsを変換（LibreOffice）"
    raise InputError(f"変換できない形式です: {ext}（.csv / .tsv / .xls のみ）")
