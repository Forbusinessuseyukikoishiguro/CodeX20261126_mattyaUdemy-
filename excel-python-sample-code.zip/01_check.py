# ファイルの場所を安全に扱う標準ライブラリ
from pathlib import Path
# xlsxを読み書きするライブラリ openpyxl から、ブックを開く関数だけ取り込む
from openpyxl import load_workbook

# 検査するファイルの名前
path = Path("raw.xlsx")
# 必ず必要な列名(見出し)の一覧
required = ["ID", "日付", "数量", "単価"]

# ファイルが無ければ
if not path.exists():
    # 理由を言ってプログラムを止める(SystemExit は「メッセージを出して終わる」)
    raise SystemExit("ファイルがありません: " + str(path))
# 元ファイルは変えない。値だけ(data_only)・読むだけ(read_only)の軽い開き方にする
wb = load_workbook(path, data_only=True, read_only=True)
# 先頭のシートを取り出す
ws = wb.worksheets[0]
# シート名を覚えておく(閉じたあとでも使えるように)
sheet_name = ws.title
# iter_rows は行を1つずつ返す。next で「最初の1行」だけ取る
first_row = next(ws.iter_rows(min_row=1, max_row=1))
# 1行目の各セルの値を取り出して、見出しのリストにする
header = [cell.value for cell in first_row]
# 開いたブックを閉じる(読み取り専用のときは閉じるのが作法)
wb.close()
# 必須の列のうち、見出しに無いものを探す
missing = [name for name in required if name not in header]
# 足りない列があれば
if missing:
    # 足りない列名を言って止める
    raise SystemExit("必須の列がありません: " + ", ".join(missing))
# 問題なければ、シート名と見出しを報告する
print("検査OK:", sheet_name, header)
