# excel-python（Claude Code / Codex 両対応スキル）

PythonでExcelを安全に読込・検査・計算・保存・更新する。SKILL.mdは標準の項目（name, description）のみ。

## 置き場所（正本を1つにしてリンク）
- Claude Code: .claude/skills/ または ~/.claude/skills/
- Codex: .agents/skills/ または ~/.codex/skills/（追加後は再起動）

    ln -s ../../skills/excel-python .claude/skills/excel-python
    ln -s ../../skills/excel-python .agents/skills/excel-python

## ClaudeのWeb/Desktop、ChatGPTに入れるとき
excel-python フォルダを zip にしてアップロード。ただしスクリプトを実行できる環境かは各サービスで確認。

## 注意
- scripts/excel_tool.py は冒頭の設定（REQUIRED_COLS など）を対象の表に合わせて直して使う
- 開いたまま更新（excel_live_update.py）は Excel のある Windows/Mac のみ。実機では未検証
- agents/openai.yaml のキー構造は公式で要確認
