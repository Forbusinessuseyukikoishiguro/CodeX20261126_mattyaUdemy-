# わざと、入っていない部品を取り込んで失敗させる(訓練用)
import not_installed_lib
