#!/usr/bin/env python3
"""互換変換の試験（C1〜C9）。使い方: python tests/run_compat_tests.py [作業フォルダ]  終了コード 0=全部合格

  C1 Codex → Claude：自動起動の禁止が disable-model-invocation: true になる
  C2 Claude → Codex：agents/openai.yaml が作られ、Claude 専用の項目は報告して省く
  C3 パスの書き換え（.agents/skills ⇄ .claude/skills）が両方向で行われる
  C4 description が無いと止まり、出力先を作らない（BLOCK）
  C5 name とフォルダ名が違うと注意（WARN）。変換は続く
  C6 確認のみ（--apply なし）は、何も書かない
  C7 元と同じ場所への出力は拒否する
  C8 往復（Claude → Codex → Claude）で、共通の項目と呼び出しの制御が元に戻る
  C9 変換の記録（CONVERSION.md）が出る
  C10 この一式の実物（spec-driven-dev）を Claude 形式へ変換でき、止まらない
"""
import shutil
import subprocess
import sys
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
CONV = KIT / "scripts" / "skill_convert.py"
EX = KIT / "examples"
WORK = Path(sys.argv[1]) if len(sys.argv) > 1 else KIT / "work" / "compat_tests"
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))


def conv(src, dst, to, apply=True):
    args = [sys.executable, str(CONV), str(src), str(dst), "--to", to] + (["--apply"] if apply else [])
    return subprocess.run(args, capture_output=True, text=True, encoding="utf-8")


def fm_of(path: Path) -> str:
    return path.read_text(encoding="utf-8").split("---")[1]


def main():
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir(parents=True)

    # C1
    d = WORK / "c1"
    cp = conv(EX / "codex-style", d, "claude")
    check("C1 Codex → Claude：自動起動の禁止を disable-model-invocation: true にする",
          cp.returncode == 0 and "disable-model-invocation: true" in fm_of(d / "SKILL.md"), cp.stdout[:150])

    # C2
    d = WORK / "c2"
    cp = conv(EX / "claude-style", d, "codex")
    yaml = (d / "agents" / "openai.yaml").read_text(encoding="utf-8") if (d / "agents" / "openai.yaml").exists() else ""
    check("C2 Claude → Codex：agents/openai.yaml が作られ、自動起動は禁止になる",
          cp.returncode == 0 and "allow_implicit_invocation: false" in yaml, cp.stdout[:150])
    check("C2 Claude 専用の項目（allowed-tools）は省かれ、報告される",
          "allowed-tools" not in fm_of(d / "SKILL.md") and "allowed-tools" in cp.stdout)

    # C3
    check("C3 パスの書き換え：.claude/skills → .agents/skills",
          ".agents/skills" in (WORK / "c2" / "SKILL.md").read_text(encoding="utf-8") and
          ".claude/skills" not in (WORK / "c2" / "SKILL.md").read_text(encoding="utf-8"))
    d = WORK / "c3"
    conv(EX / "codex-style", d, "claude")
    check("C3 パスの書き換え：.agents/skills → .claude/skills",
          ".claude/skills" in (d / "SKILL.md").read_text(encoding="utf-8") and
          ".agents/skills" not in (d / "SKILL.md").read_text(encoding="utf-8"))

    # C4 description が無い
    bad = WORK / "bad-src" / "nodesc"
    bad.mkdir(parents=True)
    (bad / "SKILL.md").write_text("---\nname: nodesc\n---\n\n本文\n", encoding="utf-8")
    out = WORK / "c4-out"
    cp = conv(bad, out, "claude")
    check("C4 description が無いと止まり、出力先を作らない", cp.returncode == 1 and not out.exists(), cp.stdout[:120])

    # C5 name とフォルダ名が違う
    mis = WORK / "bad-src" / "folder-name"
    mis.mkdir(parents=True)
    (mis / "SKILL.md").write_text("---\nname: other-name\ndescription: 試験用。\n---\n\n本文\n", encoding="utf-8")
    cp = conv(mis, WORK / "c5-out", "claude")
    check("C5 name とフォルダ名が違うと注意し、変換は続く", cp.returncode == 0 and "[WARN]" in cp.stdout, cp.stdout[:120])

    # C6 確認のみ
    d = WORK / "c6"
    cp = conv(EX / "codex-style", d, "claude", apply=False)
    check("C6 確認のみでは、何も書かない", cp.returncode == 0 and not d.exists() and "確認のみ" in cp.stdout)

    # C7 同じ場所
    cp = conv(EX / "codex-style", EX / "codex-style", "claude")
    check("C7 元と同じ場所への出力は拒否", cp.returncode == 1)

    # C8 往復
    a, b = WORK / "rt-a", WORK / "rt-b"
    conv(EX / "claude-style", a, "codex")
    conv(a, b, "claude")
    fb = fm_of(b / "SKILL.md")
    orig = fm_of(EX / "claude-style" / "SKILL.md")
    check("C8 往復：name・description が元に戻る",
          "name: claude-style" in fb and "見積もりの計算" in fb, fb[:120])
    check("C8 往復：自動起動の禁止が元に戻る（disable-model-invocation: true）",
          "disable-model-invocation: true" in fb and "disable-model-invocation: true" in orig)

    # C9 記録
    check("C9 変換の記録（CONVERSION.md）が残る", (WORK / "c2" / "CONVERSION.md").exists() and
          "省いた" in (WORK / "c2" / "CONVERSION.md").read_text(encoding="utf-8"))

    # C10 この一式の実物
    real = KIT.parent / "spec-driven-dev" if (KIT.parent / "spec-driven-dev").exists() else None
    if real:
        cp = conv(real, WORK / "c10", "claude", apply=False)
        check("C10 実物（spec-driven-dev）を Claude 形式へ確認できる（止まらない）", cp.returncode == 0, cp.stdout[:120])
    else:
        check("C10 実物の確認（この環境に実物が無いため省略）", True, "スキップ")

    width = max(len(n) for n, _, _ in results)
    print("== 互換変換の試験")
    for name, ok, detail in results:
        print(f"[{'OK' if ok else 'NG'}] {name.ljust(width)}  {'' if ok else detail}")
    failed = [r for r in results if not r[1]]
    print(f"合計 {len(results)} 件 / 合格 {len(results) - len(failed)} / 不合格 {len(failed)}")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
