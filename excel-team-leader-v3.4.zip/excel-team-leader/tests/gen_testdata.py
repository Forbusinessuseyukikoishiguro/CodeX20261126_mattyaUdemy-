#!/usr/bin/env python3
"""大量の検証用データを作る（乱数の種を固定するので、何度作っても同じ内容になる）。

作るもの: ファイル × タブ × 行 × 列 の Excel と、正解の値（expected.json）。
  基本列: 日付・商品・数量・単価・金額（金額 = 数量 × 単価）
  追加列: 項目01, 項目02, ...（列数を増やすため。整数）
  タブ名は 2026-01, 2026-02, ... （ファイルごとに違うタブ数・行数を持たせられる）

使い方: python tests/gen_testdata.py 出力フォルダ [--files 3] [--tabs 3] [--rows 2000] [--cols 12] [--seed 1]
"""
import argparse
import json
import random
from pathlib import Path

import pandas as pd

PRODUCTS = ["りんご", "みかん", "ぶどう", "もも", "なし"]
BASE = ["日付", "商品", "数量", "単価", "金額"]


def make_frame(rng, rows, cols, start_month):
    recs = []
    for _ in range(rows):
        q = rng.randint(1, 50)
        p = rng.randrange(50, 501, 10)
        day = rng.randint(1, 28)
        rec = {"日付": f"2026-{start_month:02d}-{day:02d}", "商品": rng.choice(PRODUCTS),
               "数量": q, "単価": p, "金額": q * p}
        for k in range(1, cols - len(BASE) + 1):
            rec[f"項目{k:02d}"] = rng.randint(0, 999)
        recs.append(rec)
    return pd.DataFrame(recs, columns=BASE + [f"項目{k:02d}" for k in range(1, cols - len(BASE) + 1)])


def generate(out: Path, files=3, tabs=3, rows=2000, cols=12, seed=1):
    rng = random.Random(seed)
    out.mkdir(parents=True, exist_ok=True)
    expected = {"files": [], "total_rows": 0, "sums": {}, "by_product": {}, "by_tab": {}}
    all_frames = []
    for fi in range(1, files + 1):
        fname = f"データ_{fi:02d}.xlsx"
        sheets = {}
        for ti in range(1, tabs + 1):
            month = ti
            n = rows + rng.randint(-rows // 10, rows // 10)  # タブごとに行数を変える
            df = make_frame(rng, n, cols, month)
            tab = f"2026-{month:02d}"
            sheets[tab] = df
            all_frames.append((fname, tab, df))
            expected["by_tab"][f"{fname}|{tab}"] = {"rows": len(df), "金額": int(df["金額"].sum())}
        with pd.ExcelWriter(out / fname, engine="openpyxl") as w:
            for tab, df in sheets.items():
                df.to_excel(w, sheet_name=tab, index=False)
        expected["files"].append(fname)
    big = pd.concat([d.assign(元ファイル=f, 元シート=t) for f, t, d in all_frames], ignore_index=True)
    expected["total_rows"] = int(len(big))
    for c in big.columns:
        if c in BASE + [f"項目{k:02d}" for k in range(1, cols - len(BASE) + 1)]:
            if pd.api.types.is_numeric_dtype(big[c]):
                expected["sums"][c] = int(big[c].sum())
    for p, g in big.groupby("商品"):
        expected["by_product"][p] = {"件数": int(len(g)), "数量合計": int(g["数量"].sum()),
                                     "金額合計": int(g["金額"].sum()), "平均単価": round(float(g["単価"].mean()), 4)}
    (out / "expected.json").write_text(json.dumps(expected, ensure_ascii=False, indent=1), encoding="utf-8")
    return expected


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--files", type=int, default=3)
    ap.add_argument("--tabs", type=int, default=3)
    ap.add_argument("--rows", type=int, default=2000)
    ap.add_argument("--cols", type=int, default=12)
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    e = generate(Path(a.out), a.files, a.tabs, a.rows, a.cols, a.seed)
    print(f"作成: {len(e['files'])}ファイル × {a.tabs}タブ / 合計 {e['total_rows']}行 / {a.cols}列")
