#!/usr/bin/env python3
"""お客様向け回答の納品前レビュー（任意）。渡す前に、機械でできる確認をする。

使い方: python review_delivery.py 回答.md [--policy hooks/delivery_policy.json] [--out work/delivery_review.md]
確認（BLOCK＝直すまで渡さない／WARN＝確認して判断）:
  B1 必要な見出し（結論・根拠・次のアクション など）がある                    BLOCK
  B2 プレースホルダ（【】、TODO、???、{{}} など）が残っていない               BLOCK
  B3 断定しすぎの言葉（保証します、必ず、絶対 など）が無い                    BLOCK
  B4 社外秘・社内限定の言葉が無い                                            BLOCK
  B5 数値（円・%・件 など）に、「根拠」の節での出典がある                     BLOCK
  W1 税務・法律などの話題には、専門家への確認の一文がある                    WARN
  W2 文字数が上限以内                                                        WARN
終了コード: 0=BLOCK なし / 1=BLOCK あり
"""
import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def split_sections(text: str):
    """見出し（## や #）ごとに分ける。戻り値: {見出し名: 本文}"""
    out, cur, buf = {}, "", []
    for line in text.splitlines():
        m = re.match(r"^#{1,6}\s+(.*)", line)
        if m:
            out[cur] = "\n".join(buf)
            cur, buf = m.group(1).strip(), []
        else:
            buf.append(line)
    out[cur] = "\n".join(buf)
    return out


def review(text: str, policy: dict):
    findings = []  # (記号, 重さ, 内容)
    sections = split_sections(text)
    heads = set(sections)

    for s in policy["required_sections"]:
        if not any(s in h for h in heads):
            findings.append(("B1", "BLOCK", f"見出し「{s}」がありません"))

    for pat in policy["placeholder_patterns"]:
        for m in re.finditer(pat, text):
            findings.append(("B2", "BLOCK", f"仮の文字が残っています：「{m.group(0)[:20]}」"))

    for word in policy["forbidden_claims"]:
        if word in text:
            findings.append(("B3", "BLOCK", f"断定しすぎの言葉：「{word}」（事実に置き換える）"))

    for word in policy["confidential_terms"]:
        if word in text:
            findings.append(("B4", "BLOCK", f"社外秘・社内限定の言葉：「{word}」"))

    evidence_key = policy.get("evidence_section", "根拠")
    evidence = " ".join(v for h, v in sections.items() if evidence_key in h)
    body = "\n".join(v for h, v in sections.items() if evidence_key not in h)
    units = "|".join(re.escape(u) for u in policy["numeric_units"])
    for m in re.finditer(rf"\d[\d,]*(?:\.\d+)?\s*(?:{units})", body):
        num = re.sub(r"\s+", "", m.group(0))
        core = re.sub(r"[,\s]", "", re.match(r"[\d,\.]+", num).group(0))
        if core not in re.sub(r"[,\s]", "", evidence):
            findings.append(("B5", "BLOCK", f"数値「{num}」の出典が「{evidence_key}」の節にありません"))

    legal = [w for w in policy["legal_topics"] if w in text]
    if legal and not any(p in text for p in policy["disclaimer_phrases"]):
        findings.append(("W1", "WARN", f"「{legal[0]}」に関する話題ですが、専門家への確認の一文がありません"))

    if len(text) > policy["max_chars"]:
        findings.append(("W2", "WARN", f"文字数 {len(text)} は上限 {policy['max_chars']} を超えています"))

    return findings


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument("answer")
    ap.add_argument("--policy", default=str(HERE.parent / "hooks" / "delivery_policy.json"))
    ap.add_argument("--out", default="work/delivery_review.md")
    a = ap.parse_args(argv[1:])
    text = Path(a.answer).read_text(encoding="utf-8")
    policy = json.loads(Path(a.policy).read_text(encoding="utf-8"))
    policy = {k: v for k, v in policy.items() if not k.startswith("_")}
    findings = review(text, policy)
    blocks = [f for f in findings if f[1] == "BLOCK"]
    warns = [f for f in findings if f[1] == "WARN"]
    verdict = "渡せない（直してから再レビュー）" if blocks else ("確認して判断" if warns else "渡してよい（機械的な確認は合格）")
    lines = [f"# 納品前レビュー：{Path(a.answer).name}", "", f"**判定：{verdict}**", "",
             f"- BLOCK：{len(blocks)} 件 ／ WARN：{len(warns)} 件", ""]
    lines += [f"- [{g}] {w}: {m}" for g, w, m in findings] or ["- 指摘はありません"]
    lines += ["", "※ 機械の確認は、事実の正しさを保証しません。数字と内容は、担当者が元の資料と照合してください。"]
    report = "\n".join(lines) + "\n"
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(report, encoding="utf-8")
    print(report)
    return 1 if blocks else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
