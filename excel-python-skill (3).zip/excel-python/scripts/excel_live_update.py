#!/usr/bin/env python3
"""Excelを開いたままでも更新する（xlwings）。失敗したら別ファイルに逃がす。

前提: Excelがインストールされた Windows / Mac。pip install xlwings pandas openpyxl
方針:
  1. 開いているブックがあれば、それに接続して書く（ファイルを直接書かない）
  2. 開いていなければ、Excelで開いて書く
  3. Excelが使えない・書けないときは、日付つきの別ファイルに保存して知らせる
  4. 人が編集中のセルとぶつからないよう、書く場所は専用シートに限る
"""
import time
from datetime import datetime
from pathlib import Path

import pandas as pd


def find_open_book(xw, path: Path):
    """開いているブックを探す。パスで見つからなければ名前で探す（OneDrive対策）。"""
    for app in xw.apps:
        for book in app.books:
            try:
                if Path(book.fullname).resolve() == path.resolve():
                    return book
            except Exception:
                continue
    for app in xw.apps:
        for book in app.books:
            if book.name.lower() == path.name.lower():
                return book
    return None


def write_live(path: Path, df: pd.DataFrame, sheet: str, cell: str = "A1", retries: int = 5) -> None:
    import xlwings as xw                       # 未インストールならここで例外 → 呼び出し側で別ファイルへ

    last = None
    for i in range(retries):
        try:
            book = find_open_book(xw, path) or xw.Book(str(path.resolve()))
            names = [s.name for s in book.sheets]
            ws = book.sheets[sheet] if sheet in names else book.sheets.add(sheet, after=book.sheets[-1])
            ws.range(cell).expand().clear_contents()          # 前回の分だけ消す
            ws.range(cell).options(index=False).value = df    # まとめて1回で書く
            book.save()
            return
        except Exception as e:                  # セル編集中などでExcelが受け付けないとき
            last = e
            time.sleep(1 + i)                   # 1,2,3,4,5秒と待ちを延ばして再試行
    raise RuntimeError(f"Excelに書けませんでした（{retries}回試行）: {last}")


def update_excel(path: str, df: pd.DataFrame, sheet: str = "データ") -> str:
    p = Path(path)
    try:
        write_live(p, df, sheet)
        return f"更新しました（Excel経由）: {p.name}"
    except Exception as e:
        out = p.with_name(f"{p.stem}_更新_{datetime.now():%Y%m%d_%H%M%S}.xlsx")
        df.to_excel(out, sheet_name=sheet, index=False)
        return f"Excelに書けなかったため別ファイルに保存しました: {out.name}（理由: {e}）"


if __name__ == "__main__":
    sample = pd.DataFrame({"ID": ["001", "002"], "金額": [200, 1000]})
    print(update_excel("report.xlsx", sample))
