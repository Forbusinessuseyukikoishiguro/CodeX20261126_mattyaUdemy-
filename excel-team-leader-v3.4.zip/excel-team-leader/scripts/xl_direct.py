#!/usr/bin/env python3
"""既存のExcelを直接更新する（入力セルだけを書き換えて保存）。Excelは不要（openpyxl）。

安全の方針（すべて必須）:
  1. 更新してよい範囲（inputs）を指示で必ず指定する。範囲外は書かない
  2. 数式セルは上書きしない。結合セルの2つ目以降も書かない
  3. グラフ・図形・画像があれば止める（保存すると失われるため）。allow_loss=true のときだけ続行
  4. 保存前に必ずバックアップ（.bak_日時）を作る。保存は一時ファイル経由で置き換える
  5. 保存後に再計算し、意図したセル以外の値が変わっていないかを全セルで照合する

指示の例（worker_b の action=update_cells）:
  {"action":"update_cells","file":"work/book.xlsx",
   "inputs":[{"sheet":"データ","range":"B2:C4"}],
   "edits":[{"sheet":"データ","cell":"B2","value":12}],
   "blocks":[{"sheet":"データ","top_left":"B5","rows":[[3,100],[4,200]]}],
   "recalc":true, "allow_loss":false}

注意: 保存時に openpyxl は数式の計算結果を消すため、既定では LibreOffice で再計算して値を戻す。
      soffice が無い場合は status=not_verified（数式は入ったが再計算は未確認）。
"""
from __future__ import annotations

import datetime as dt
import os
import re
import shutil
import tempfile
import zipfile
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.cell.cell import MergedCell
from openpyxl.utils import get_column_letter, range_boundaries

from teamcore import InputError, SaveError

LOSS_PARTS = ("xl/charts/", "xl/drawings/", "xl/media/", "xl/pivotTables/", "xl/slicers/")
ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _coord_in_inputs(sheet, col, row, inputs):
    for rng in inputs:
        if rng["sheet"] != sheet:
            continue
        c1, r1, c2, r2 = range_boundaries(rng["range"])
        if c1 <= col <= c2 and r1 <= row <= r2:
            return True
    return False


def _collect_edits(t):
    """edits と blocks を、(シート, セル座標, 値) の一覧にする。"""
    out = []
    for e in t.get("edits", []):
        out.append((e["sheet"], e["cell"], e.get("value")))
    for b in t.get("blocks", []):
        c1, r1, _, _ = range_boundaries(b["top_left"] + ":" + b["top_left"])
        for i, row in enumerate(b["rows"]):
            for j, v in enumerate(row):
                out.append((b["sheet"], f"{get_column_letter(c1 + j)}{r1 + i}", v))
    if not out:
        raise InputError("更新する内容（edits か blocks）がありません")
    return out


def _zip_loss_parts(path: Path):
    try:
        with zipfile.ZipFile(path) as z:
            return sorted({n.split("/")[0] + "/" + n.split("/")[1] for n in z.namelist()
                           if n.startswith(LOSS_PARTS)})
    except zipfile.BadZipFile as e:
        raise InputError(f"xlsx として開けません（壊れている可能性）: {e}") from e


def _snapshot(path: Path):
    """全セルの値と数式を取る。戻り値: {(シート, 座標): (値, 数式か)}"""
    wb = load_workbook(path)
    snap = {}
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if c.value is None:
                    continue
                is_f = isinstance(c.value, str) and c.value.startswith("=")
                snap[(ws.title, c.coordinate)] = (c.value, is_f)
    return snap


def _normalize(v):
    if isinstance(v, dt.datetime):
        return v.date().isoformat() if v.time() == dt.time(0) else v.isoformat()
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v


def update_in_place(t: dict) -> dict:
    path = Path(t["file"])
    if not path.exists():
        raise InputError(f"ファイルがありません: {path}")
    if path.suffix.lower() not in (".xlsx", ".xlsm"):
        raise InputError(f"対応していない形式です: {path.suffix}")
    inputs = t.get("inputs") or []
    if not inputs:
        raise InputError("更新してよい範囲（inputs）が指定されていません。範囲外は書けません")
    edits = _collect_edits(t)

    # 1. 事前検査（保存前に止める）
    loss = _zip_loss_parts(path)
    if loss and not t.get("allow_loss", False):
        raise InputError("グラフ・図形・画像などがあり、保存すると失われます（" + ", ".join(loss) +
                         "）。allow_loss を true にするか、テンプレートから別名で作ってください")
    wb = load_workbook(path, keep_vba=path.suffix.lower() == ".xlsm")
    targets = []
    for sheet, coord, value in edits:
        if sheet not in wb.sheetnames:
            raise InputError(f"シート '{sheet}' がありません: {wb.sheetnames}")
        ws = wb[sheet]
        c1, r1, _, _ = range_boundaries(coord + ":" + coord)
        if not _coord_in_inputs(sheet, c1, r1, inputs):
            raise InputError(f"入力範囲の外です: {sheet}!{coord}（inputs で許可されていない）")
        cell = ws[coord]
        if isinstance(cell, MergedCell):
            raise InputError(f"結合セルの一部です（左上のセルに書いてください）: {sheet}!{coord}")
        if isinstance(cell.value, str) and cell.value.startswith("="):
            raise InputError(f"数式セルは上書きしません: {sheet}!{coord} = {cell.value}")
        targets.append((sheet, coord, value))
    if not targets:
        raise InputError("更新するセルがありません")

    # 2. バックアップ（保存前に必ず）
    before = _snapshot(path)
    backup = path.with_name(f"{path.stem}.bak_{dt.datetime.now():%Y%m%d_%H%M%S}{path.suffix}")
    try:
        shutil.copy2(path, backup)
    except OSError as e:
        raise SaveError(f"バックアップを作れません: {e}") from e

    # 3. 書き込み（日付文字列は日付として）
    for sheet, coord, value in targets:
        cell = wb[sheet][coord]
        if isinstance(value, str) and ISO_DATE.match(value):
            value = dt.datetime.strptime(value, "%Y-%m-%d")
            cell.number_format = "yyyy-mm-dd"
        cell.value = value

    # 4. 一時ファイル経由で置き換える（途中で落ちても元が壊れない）
    try:
        fd, tmp = tempfile.mkstemp(suffix=path.suffix, dir=path.parent)
        os.close(fd)
        wb.save(tmp)
        os.replace(tmp, path)
    except PermissionError as e:
        raise SaveError(f"保存できません。Excelで開いていませんか、または権限がありません: {path}") from e
    except OSError as e:
        raise SaveError(f"保存先に書けません（権限・容量など）: {e}") from e
    finally:
        if "tmp" in locals() and os.path.exists(tmp):
            os.remove(tmp)

    # 5. 再計算（openpyxl保存で消えた計算結果を戻す）→ 照合
    from worker_a import recalc  # 遅延import（循環を避ける）
    recalced, why = (recalc(path) if t.get("recalc", True) else (False, "再計算は指示なし"))

    after = _snapshot(path)
    expected = {(s, c): _normalize(v) for s, c, v in targets}
    problems = []
    for (s, c), v in expected.items():
        got = after.get((s, c), (None, False))[0]
        if _normalize(got) != v and not (v is None and got is None):
            problems.append(f"{s}!{c}: 書いた値と違う（実際 {got!r}）")
    # 意図しない変更（数式は文字列、値は非数式セルのみ照合）
    edited = set(expected)
    for key, (val, is_f) in before.items():
        if key in edited:
            continue
        if key not in after:
            problems.append(f"{key[0]}!{key[1]}: 消えた")
        elif is_f and after[key][0] != val:
            problems.append(f"{key[0]}!{key[1]}: 数式が変わった（{val} → {after[key][0]}）")
        elif not is_f and _normalize(after[key][0]) != _normalize(val):
            problems.append(f"{key[0]}!{key[1]}: 意図しない変更（{val!r} → {after[key][0]!r}）")
    for key in after:
        if key not in before and key not in edited:
            problems.append(f"{key[0]}!{key[1]}: 意図しない追加")
    if problems:
        raise SaveError("保存後の照合で問題（バックアップから戻せます: " + backup.name + "）: " +
                        " / ".join(problems[:5]))

    msg = f"{len(targets)}セルを更新して保存（バックアップ: {backup.name}）"
    if loss:
        msg += f" / 注意：{', '.join(loss)} は保存で失われました"
    if not recalced:
        return {"status": "not_verified", "message": msg + f" / 再計算は未確認（{why}）",
                "backup": str(backup), "changed": len(targets)}
    return {"status": "warn" if loss else "ok", "message": msg + " / 再計算・照合OK",
            "backup": str(backup), "changed": len(targets)}
