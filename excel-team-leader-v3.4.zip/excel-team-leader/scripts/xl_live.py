#!/usr/bin/env python3
"""Excelを開いたままでも更新する（xlwings）。失敗したら日付つきの別ファイルに逃がす。
（取り込み元 excel-python の excel_live_update.py。前提: Excelがある Windows / Mac、pip install xlwings。実機では未検証）
方針: ①開いているブックに接続して書く ②開いていなければExcelで開く ③書けなければ別ファイル ④書く場所は専用シートに限る
"""
from __future__ import annotations

import time
from datetime import datetime
from pathlib import Path

import pandas as pd


def find_open_book(xw, path: Path):
    """開いているブックを探す。パスで見つからなければ名前で探す（OneDrive対策）。"""
    for app in xw.apps:
        for book in app.books:
            try:
                if Path(book.fullname).resolve() == path.resolve():
                    return book
            except Exception:
                continue
    for app in xw.apps:
        for book in app.books:
            if book.name.lower() == path.name.lower():
                return book
    return None


def write_live(path: Path, df: pd.DataFrame, sheet: str, cell: str = "A1", retries: int = 5) -> None:
    import xlwings as xw  # 未インストールならここで例外 → 呼び出し側で別ファイルへ

    last = None
    for i in range(retries):
        try:
            book = find_open_book(xw, path) or xw.Book(str(path.resolve()))
            names = [s.name for s in book.sheets]
            ws = book.sheets[sheet] if sheet in names else book.sheets.add(sheet, after=book.sheets[-1])
            ws.range(cell).expand().clear_contents()          # 前回の分だけ消す
            ws.range(cell).options(index=False).value = df    # まとめて1回で書く
            book.save()
            return
        except Exception as e:                                # セル編集中などで受け付けないとき
            last = e
            time.sleep(1 + i)                                 # 待ちを延ばして再試行
    raise RuntimeError(f"Excelに書けませんでした（{retries}回試行）: {last}")


def update_excel(path: str, df: pd.DataFrame, sheet: str = "データ"):
    """戻り値: (Excel経由で更新できたか, メッセージ)。"""
    p = Path(path)
    try:
        write_live(p, df, sheet)
        return True, f"更新しました（Excel経由）: {p.name}"
    except Exception as e:
        out = p.with_name(f"{p.stem}_更新_{datetime.now():%Y%m%d_%H%M%S}.xlsx")
        df.to_excel(out, sheet_name=sheet, index=False)
        return False, f"Excelに書けなかったため別ファイルに保存しました: {out.name}（理由: {e}）"
