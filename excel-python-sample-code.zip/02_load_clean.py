# 表の加工に強いライブラリ pandas を pd という短い名前で取り込む
import pandas as pd

# raw.xlsx を読む。IDは dtype=str で「文字」のまま読む(001 が 1 にならない)
raw = pd.read_excel("raw.xlsx", sheet_name="Sheet1", dtype={"ID": str})
# 加工用にコピーを作る(raw はそのまま残して、エラー行の表示に使う)
df = raw.copy()
# 数量を数字に変える。変えられない値(abc)は errors="coerce" で空(NaN)にする
df["数量"] = pd.to_numeric(df["数量"], errors="coerce")
# 単価も同じく数字に変える
df["単価"] = pd.to_numeric(df["単価"], errors="coerce")
# 日付を日付型に変える。format="mixed" で、書き方がバラバラでも1つずつ読む
df["日付"] = pd.to_datetime(df["日付"], format="mixed", errors="coerce")
# 数量・単価・日付のどれかが空の行を探す(True が不正な行)
bad = df["数量"].isna() | df["単価"].isna() | df["日付"].isna()
# 正常な行だけ取り出す(~ は「反対」)
ok = df[~bad].copy()
# 日付から「時刻」を落として、日付だけにする
ok["日付"] = ok["日付"].dt.date
# 不正な行は、元の値のまま取り出す
err = raw[bad].copy()
# 理由の列を足す
err["理由"] = "数量・単価・日付のどれかが不正"
# 保存する。元ファイルとは別の名前 clean.xlsx にする(上書きしない)
with pd.ExcelWriter("clean.xlsx", engine="openpyxl") as writer:
    # 正常な行を「明細」シートへ(index=False は行番号を書かない)
    ok.to_excel(writer, sheet_name="明細", index=False)
    # 不正な行を「エラー行」シートへ
    err.to_excel(writer, sheet_name="エラー行", index=False)
# 件数を報告する
print(f"読込{len(raw)}行 / 正常{len(ok)}行 / エラー{len(err)}行 → clean.xlsx")
