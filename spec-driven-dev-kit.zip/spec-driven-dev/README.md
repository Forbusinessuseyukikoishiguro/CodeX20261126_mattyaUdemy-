# 仕様駆動開発の一式（spec-driven-dev）

設計図解と仕様書（Mermaid・要件ID）を基に、実装・試験・納品までを進めるための一式です。
Claude Code と Codex のどちらでも使えるように、本文は標準の項目だけで書いています。

## 何が入っているか

```
spec-driven-dev/
├── SKILL.md                  入口（使い方・守ること）
├── agents/openai.yaml        Codex 用の表示設定
├── references/               参照資料（01〜09）
│   01 仕様駆動の流れ / 02 エージェントチーム / 03 製造品質と設計品質
│   04 手動試験 / 05 自動試験と品質ゲート / 06 イレギュラー対応（Excel のタブ追加など）
│   07 お客様向けの回答のレビュー（任意） / 08 任意の仕組みの選び方 / 09 公式の参照先
├── templates/                設計書・変更要求書・受け渡し票・納品前チェックシート・手動試験記録
├── scripts/
│   spec_trace.py             要件と試験の対応を確かめる（設計品質）
│   quality_gate.py           品質ゲート（G1〜G6）。--release でリリース前、--hook でフック
│   review_delivery.py        お客様向けの回答の納品前レビュー（任意）
│   install_hooks.py          任意のフック導入（既定は確認だけ。--apply で書く）
├── hooks/
│   delivery_policy.json      納品前レビューの基準（チームで編集できる）
│   claude-settings.example.json / pre-commit.example.sh   フックの例
├── examples/sample_project/  動くサンプル（税込計算・設計書・手動試験記録・回答の例）
└── tests/run_kit_tests.py    この一式の試験（20件）
```

## 使い方（最短）

```bash
# サンプルの品質ゲート（開発中）
python3 scripts/quality_gate.py examples/sample_project
# リリース前（手動試験の未実施があれば不合格になる）
python3 scripts/quality_gate.py examples/sample_project --release
# お客様向けの回答のレビュー
python3 scripts/review_delivery.py examples/sample_project/answers/回答_OK.md
# この一式の試験
python3 tests/run_kit_tests.py
```

## 任意で選ぶ仕組み（既定は何も入れない）

| 方法 | 導入 | 動き |
|---|---|---|
| スキルだけ | 配置のみ | 必要なときに依頼して使う |
| Claude Code の Stop フック | `python3 scripts/install_hooks.py <プロジェクト> --claude`（確認のあと `--apply`） | 会話の終わりに品質ゲート。不合格なら終わらせず理由を表示 |
| Git の pre-commit | `python3 scripts/install_hooks.py <プロジェクト> --git`（確認のあと `--apply`） | コミット前に品質ゲート。既存の pre-commit は上書きしない |
| お客様向けレビュー | `review_delivery.py` を手で通す | 渡す前に機械の確認（最後は人が照合） |

## 確認状況

| 項目 | 状況 |
|---|---|
| 一式の試験 20件（対応・失敗の検出・秘密情報・図の閉じ・レビュー・フック） | 確認済み（Linux） |
| サンプルの品質ゲート（開発中は合格、リリース前は手動試験の未実施で不合格） | 確認済み |
| Claude Code の Stop フックの動作（終了コード2・stop_hook_active） | 試験で確認（フックの実機での起動は未確認） |
| Codex のフック | 未確認（この一式は Codex の設定を書かない。Git か CI で代替） |
| Claude Code のサブエージェントの定義の形式 | 未確認（公式で確認してから使う） |
| CI（共有の環境）での実行 | 未確認（例は示していない。同じ scripts を走らせる形） |
| Windows での実行 | 未確認 |

## 注意

- 機械の確認は、事実の正しさを保証しない。お客様向けの数字と内容は、人が元の資料と照合する
- 法律・税務・医療・投資の最終的な判断は、専門家の確認が必要
- 秘密情報（鍵・パスワード）は、コードや試験に書かない。品質ゲートは中身を表示せず、場所だけを示す
- 仕様が変わったら、設計書を先に直す（実装だけを直さない）
