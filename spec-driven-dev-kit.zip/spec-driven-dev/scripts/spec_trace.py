#!/usr/bin/env python3
"""設計品質の自動確認：設計書の要件ID（FR-/NFR-）と、テストに書いたタグ（REQ: FR-001）を突き合わせる。

使い方: python spec_trace.py <プロジェクトフォルダ>
  - 設計書：spec/ の .md（表の中の FR-001 形式のID）
  - テスト：tests/ の .py（コメントや文字列に「REQ: FR-001, NFR-002」と書く）
判定:
  - 要件に対応するテストが1件も無い → 不合格（未カバー）
  - 設計書に無い ID をテストが指している → 不合格（宙に浮いたタグ）
"""
import re
import sys
from pathlib import Path

ID = re.compile(r"\b(?:FR|NFR)-\d{3}\b")
TAG = re.compile(r"REQ:\s*((?:FR|NFR)-\d{3}(?:\s*,\s*(?:FR|NFR)-\d{3})*)")


def spec_ids(root: Path) -> set:
    ids = set()
    spec = root / "spec"
    for f in sorted(spec.glob("*.md")) if spec.exists() else []:
        for line in f.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("|"):          # 表の行の中のIDだけを要件として数える
                ids.update(ID.findall(line))
    return ids


def test_tags(root: Path) -> dict:
    """戻り値: {要件ID: [テストファイル, ...]}"""
    tags = {}
    tests = root / "tests"
    if not tests.exists():
        return tags
    for f in sorted(tests.rglob("*.py")):
        for m in TAG.finditer(f.read_text(encoding="utf-8")):
            for rid in re.findall(r"(?:FR|NFR)-\d{3}", m.group(1)):
                tags.setdefault(rid, []).append(f.name)
    return tags


def trace(root: Path):
    """戻り値: (未カバーのID, 宙に浮いたタグ, 要件数, カバー数, タグ一覧)"""
    req = spec_ids(root)
    tags = test_tags(root)
    uncovered = sorted(r for r in req if r not in tags)
    dangling = sorted(r for r in tags if r not in req)
    return uncovered, dangling, len(req), len(req) - len(uncovered), tags


if __name__ == "__main__":
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    unc, dang, n, ok, tags = trace(root)
    print(f"要件ID: {n}件 / テストで対応: {ok}件")
    for r in sorted(tags):
        print(f"  {r}: {', '.join(sorted(set(tags[r])))}")
    for r in unc:
        print(f"[NG] 未カバー：{r} に対応するテストがありません（tests/ に「REQ: {r}」を書く）")
    for r in dang:
        print(f"[NG] 宙に浮いたタグ：{r} は設計書にありません")
    if n == 0:
        print("[NG] 設計書（spec/*.md）に要件IDがありません")
    sys.exit(0 if not unc and not dang and n > 0 else 1)
