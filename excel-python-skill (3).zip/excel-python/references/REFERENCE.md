# REFERENCE: Excel処理のよくあるエラー

| 症状 | 原因 | 対策 |
|---|---|---|
| PermissionError | Excelで開いたまま | 閉じる／手順B（xlwings）／別名で保存 |
| 数式の結果が空・None | openpyxlは計算結果を持たない | data_only=Trueで読む（Excelで一度保存した値のみ） |
| 保存すると数式が消える | data_only=Trueで開いて保存した | 読み取り用と書き込み用で開き方を分ける |
| 書式・グラフ・画像が消える | openpyxlが再現できない要素 | 元は触らずテンプレから別名出力 |
| 先頭の0が消える | 数値として読まれた | 全列を文字列で読んでから型変換（dtype=str） |
| 日付が不正になる | 書き方が混在 | pd.to_datetime(..., format="mixed", errors="coerce") |
| KeyError（列・シート名） | 空白・全角半角・名称変更 | 列名をstrip()し、存在チェックを入れる |
| 文字化け（CSV） | 文字コード不一致 | utf-8-sig または cp932 |
| .xlsが読めない | 古い形式 | .xlsxに変換 |
| 結合セル・空行でずれる | 見た目重視の表 | 読む範囲を明示 |
| シート名の保存エラー | 31文字超 | 31文字に切り詰める |

## 開いたまま更新（xlwings）の制約
- Excelがインストールされた Windows / Mac が必要
- セル編集中は Excel が受け付けないことがある（再試行で対応）
- 同じファイルを2つの Excel で開いていると接続エラー
- OneDrive / SharePoint 上のファイルはパスが URL になり、見つからないことがある
- Excelを使わない代案: CSVに出して Power Query で更新する
