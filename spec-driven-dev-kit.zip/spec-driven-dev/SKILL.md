---
name: spec-driven-dev
description: 設計図解と仕様書（Mermaid・要件ID）を基に、実装・試験・納品までを仕様駆動で進める。役割を分けたエージェントチーム開発、製造品質と設計品質の確認、手動と自動の試験、Excel のタブ追加などのイレギュラー対応を扱う。お客様に渡す回答は、納品前にレビューする（任意）。「仕様書を基に実装して」「設計どおりに作って」「テストを作って」「品質を確認して」「イレギュラーの変更」「お客様向けの回答をレビューして」「フックを入れて」などで使う。
---

# spec-driven-dev

設計図解と仕様書を先に確定し、その仕様に沿って作り、試験し、渡すための手順です。
Claude Code と Codex のどちらでも使えるように、本文は標準の項目だけで書いています。

## 最初に決めること

1. **仕様は確定しているか**：要件 ID（FR-/NFR-）と図（Mermaid）がある。無ければ、先に作る（`templates/設計書.md`）
2. **どの仕組みを使うか**（任意。既定は「手で呼ぶ」）
   - スキルだけ：必要なときに依頼する
   - フック：Claude Code の Stop フック（会話の終わりに確認）。`scripts/install_hooks.py --claude`
   - Git：コミット前の確認。`scripts/install_hooks.py --git`
   - 納品前のレビュー：お客様向けの回答に使う。`scripts/review_delivery.py`
3. **誰が何をするか**：役割（要件・設計・実装・試験・レビュー・納品）を決める（references/02）

## 流れ

1. 仕様を確認する（未確定事項が 0 か、利用者の承認があるか）
2. 作業を要件 ID 単位に分ける
3. 実装する。図の名前をそのまま使う
4. 試験する：自動（`python -m unittest discover -s tests`）と、手動（docs/手動試験記録.md）
5. 品質ゲートを走らせる：`python scripts/quality_gate.py <プロジェクト>`（リリース前は `--release`）
6. お客様に渡すものは、納品前のレビューを通す（`python scripts/review_delivery.py 回答.md`）
7. 受け渡し票を残して、次の担当に渡す

## 品質の見方

| 種類 | 確かめること | 主な道具 |
|---|---|---|
| 設計品質 | 要件と試験の対応、図の整合、未確定事項 | spec_trace.py（G1）、G4 |
| 製造品質 | 単体試験、構文、秘密情報、手動試験の記録 | G2・G3・G5・G6 |

詳しくは references/03_quality.md。

## イレギュラー対応

計画にない依頼（Excel のタブを増やす、列を足す、既存の集計を組み替えるなど）は、通常の変更より影響を厚く確認する。
変更要求書（templates/変更要求書.md）を書き、影響（参照・数式・集計・試験）を洗い出し、承認を取ってから実施する。
詳しい手順と例は references/06_irregular_change.md。

## 守ること

- 仕様を直さずに実装だけを直さない。仕様が変わったら、設計書を先に直す
- 試験を消して通さない。不合格は、原因を切り分けてから直す
- 作った人が、自分の成果物を承認しない
- 手動試験の未実施を残したままリリースしない（--release で止まる）
- お客様向けの数字は、元の資料と人が照合する。機械の確認は事実の正しさを保証しない
- 秘密情報（鍵・パスワード）は、コードや試験に書かない。環境変数で渡す

## 参照

- references/01_spec_driven.md：仕様駆動の流れ
- references/02_agent_team.md：役割と受け渡し
- references/03_quality.md：製造品質と設計品質
- references/04_manual_test.md：手動試験
- references/05_auto_test.md：自動試験と品質ゲート
- references/06_irregular_change.md：イレギュラー対応（Excel のタブ追加の例）
- references/07_customer_delivery.md：お客様向けの回答のレビュー（任意）
- references/08_optional_hooks.md：任意の仕組みの選び方
- references/09_official_refs.md：公式の参照先（確認日つき）
- templates/：設計書・変更要求書・受け渡し票・納品前チェックシート・手動試験記録
- examples/sample_project/：動くサンプル（税込計算）。品質ゲートの結果を確かめられる
