# チーム仕様（リーダー↔ワーカー）

受け渡しは**JSONファイル**。実行は `python scripts/worker_x.py <task.json>`。全タスクで任意の `"log_dir"` を付けられる。

## 出力と終了コード

標準出力に1つのJSON：`{"status": "...", "message": "...", ...}`

| status | 意味 | リーダーの動き |
|---|---|---|
| `ok` | 成功（A は検算も一致） | 次へ |
| `warn` | 完了したが注意あり（エラー行あり・別ファイルに保存） | 件数・理由を報告して次へ |
| `not_verified` | 数式は入ったが再計算を確認できていない | 「未確認」と報告して次へ |
| `ng` | 失敗。`kind` に分類 | **止まって**報告 |

`ng` の `kind` と終了コード：

| 終了コード | kind | 意味 |
|---|---|---|
| 0 | – | ok / warn / not_verified |
| 1 | `input` | 入力の問題（ファイル・列・シート・指示JSONの不足） |
| 1 | `verify` | 検算が不一致 |
| 2 | `save` | 保存の問題（開いたまま・権限・容量） |
| 3 | `unexpected` | 想定外（壊れたファイルなど） |

## B：入出力（worker_b.py）

| action | 指示JSON | 動き |
|---|---|---|
| `check` | `file`, `sheet?`, `require?[]` | 存在・形式・ロック・シート・必須列を検査 |
| `write_input` | `file`, `sheet?`, `headers`, `rows` | 新規ブックに入力して保存。列数不一致は `ng` |
| `load_clean` | `input`, `out`, `sheet?`, `required_cols?`, `text_cols?`, `num_cols?`, `date_cols?` | 読込→型変換→不正行を分離→別名で保存（既存の出力は `.bak_日時` に退避、一時ファイル経由）。シート「明細」「エラー行」。エラー行ありは `warn` |
| `read_back` | `file`, `sheet?` | 計算済みの値を `values` で返す（再計算前の数式セルは null） |
| `convert` | `input`, `out` | `.csv` `.tsv`（utf-8-sig → cp932）、`.xls`（xlrd → LibreOffice）を .xlsx に |
| `live_update` | `file`, `sheet?`, `headers`, `rows` | 開いたままExcelを更新（xlwings）。書けなければ別ファイル＝`warn` |
| `update_cells` | `file`, `inputs`（範囲）, `edits?[]` / `blocks?[]`, `recalc?`, `allow_loss?` | 既存Excelの**入力範囲だけ**を直接更新して保存（Excel不要）。保存前にバックアップ、保存後に全セル照合。詳細は下の節 |
| `merge_sheets` | `sources`（`file`, `sheets`: `"*"` か名前の配列）, `out`, `out_sheet?`（既定「統合」）, `add_source_columns?` | 複数ファイル・複数シートを列名で揃えて1表に統合。「統合サマリ」も作る。詳細は下の節 |

`load_clean` の既定：`required_cols=["ID","日付","数量","単価"]`、`text_cols=["ID"]`（先頭の0を守る）、`num_cols=["数量","単価"]`、`date_cols=["日付"]`。別の表では指示JSONで渡す（スクリプトは書き換えない）。

## A：計算（worker_a.py）

| action | 指示JSON | 動き |
|---|---|---|
| `add_formulas` | `file`, `sheet?`, `tax_rate?`, `recalc?` | 「単価」「数量」の右に「小計」、明細の下に 合計／税率（青字の入力セル）／消費税／税込合計 |
| `aggregate` | `file`, `sheet?`（既定「明細」）, `id_col?` `qty_col?` `price_col?`, `recalc?` | 「金額」列と、ID別「集計」シート（件数・数量合計・金額合計）を**数式で**作る。再実行しても列・シートは増えない |

- 共通：`recalc:true`（既定）でLibreOffice再計算 → Pythonの期待値と照合。sofficeが無ければ `not_verified`
- `aggregate` のID照合は `SUMPRODUCT` で厳密比較（COUNTIF/SUMIFSは「001」と「1」を同じと見なすため使わない）

## ログ（teamlog.py）

- ファイル名：`YYYYMMDDHHMM_log.txt`（形式は `NAME_FORMAT` で変更）／1行：`2026-11-25 12:17:14 | OK | worker_b | 3行を保存`
- ステータス：`INFO`（開始）／`OK`／`WARN`（warn・not_verified）／`NG`
- 保存先の優先順：関数の引数 ＞ タスクJSONの `log_dir` ＞ 環境変数 `TEAM_LOG_DIR` ＞ `work/logs`
- `TEAM_LOG_STAMP` を決めると、複数ワーカーの記録を1ファイルにまとめられる

## 置き場所

- Claude Code：`.claude/skills/excel-team-leader`／Codex：`.agents/skills/excel-team-leader`
- 正本は1つ、もう片方はシンボリックリンク

## B：直接更新（update_cells）

```json
{
  "action": "update_cells",
  "file": "work/book.xlsx",
  "inputs": [{"sheet": "データ", "range": "B2:C4"}],
  "edits": [{"sheet": "データ", "cell": "B2", "value": 12}],
  "blocks": [{"sheet": "データ", "top_left": "C5", "rows": [[3, 100], [4, 200]]}],
  "recalc": true,
  "allow_loss": false
}
```

- `inputs`（必須）：書いてよい範囲。ここに無いセルは拒否（`ng/input`）
- 拒否される：数式セルへの書き込み、結合セルの2つ目以降、存在しないシート、グラフ・図形・画像があるファイル（`allow_loss: true` で続行、その場合 `warn`）
- ISO形式の日付文字列（`2026-11-01`）は日付セルにする
- 保存前にバックアップ `元の名前.bak_YYYYMMDD_HHMMSS.xlsx` を作る。保存は一時ファイル経由
- 保存後、LibreOffice で再計算（`recalc: true` 既定）→ 書いた値の一致、数式の保持、**指定外セルの不変**を全セルで照合
- `status`：`ok`（照合OK）／`warn`（グラフを失って保存）／`not_verified`（soffice無し・再計算は未確認）／`ng`（`kind`: input か save）
- `ng` で照合不一致のときは、`message` にバックアップ名が入る。バックアップから戻して原因を直す

## B：統合（merge_sheets）

```json
{
  "action": "merge_sheets",
  "sources": [
    {"file": "samples/東京_売上.xlsx", "sheets": "*"},
    {"file": "samples/大阪_売上.xlsx", "sheets": ["1月", "2月"]}
  ],
  "out": "work/統合売上.xlsx",
  "out_sheet": "統合",
  "add_source_columns": true
}
```

- 列は**列名で揃える**。並びが違うシートも正しい列へ入る
- 元の列にない列は足し、ない列は空欄にする。差分は `warn` と「統合サマリ」の「列の一致」に出す
- 空行は除く。`元ファイル`・`元シート`・`元の行番号`（Excel上の行）を残す
- 「統合サマリ」は、シートごとの行数と合計行。`sheets` の名前が無いと `ng/input`
- 入力は読み取りのみ。保存先が入力と同じなら拒否。既存の出力は `.bak_日時` に退避
- `.xls` と CSV は先に `convert` で `.xlsx` にする
- 注意：数式の入ったセルは計算結果が読めない（保存時に値がないため）。統合の前に再計算するか、値のシートを使う

## 聞き返し・お知らせ・エラーの説明（v3.3）

- **聞き返し**：指示が足りないと、処理を始めず `{"status":"ng","kind":"input","message":"指示が足りません","questions":["…"]}` を返し、終了コード1。質問はワーカー `support.py` が決める
- **お知らせ**：標準エラーに「処理中だにゃー」「段階の進捗（完了 xx%・残り時間）」「終わったニャー」を出す。標準出力は結果のJSON1行だけ
- **エラーの説明**：`ng` のときは `category`（分類）・`hint`（原因のめやす）・`fix`（やってみてほしいこと）・`log_file`（ログの場所）を付ける
- 残り時間は、実測の速さから計算する。計算できないときは「まだ計算中」

## 話し方（v3.4）

- 指示JSONに `"voice": "nyanko" | "secretary" | "desu_masu"` を書くか、環境変数 `TEAM_VOICE` を設定する。どちらも無ければ `nyanko`
- 話し方は、標準エラーのお知らせだけに効く。標準出力のJSONと結果の数字は変わらない
