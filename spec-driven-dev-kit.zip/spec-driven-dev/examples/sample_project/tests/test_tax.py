"""税込計算の単体試験。各試験には、対応する要件IDをタグで書く（REQ: ...）。"""
import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from tax import tax_included  # noqa: E402


class TaxIncludedTest(unittest.TestCase):
    # REQ: FR-001
    def test_rounding_half_up(self):
        """税込は税抜に税率を足し、1円未満を四捨五入する（FR-001）。"""
        self.assertEqual(tax_included(1000, 0.10), 1100)
        self.assertEqual(tax_included(333, 0.10), 366)   # 366.3 → 366
        self.assertEqual(tax_included(5, 0.10), 6)       # 5.5 → 6（四捨五入）

    # REQ: FR-002
    def test_rate_out_of_range_raises(self):
        """税率が範囲外なら例外（FR-002）。"""
        with self.assertRaises(ValueError):
            tax_included(1000, 1.5)
        with self.assertRaises(ValueError):
            tax_included(1000, -0.1)

    # REQ: FR-003
    def test_amount_invalid_raises(self):
        """金額が負数や小数なら例外（FR-003）。"""
        with self.assertRaises(ValueError):
            tax_included(-1, 0.1)
        with self.assertRaises(ValueError):
            tax_included(10.5, 0.1)

    # REQ: NFR-001
    def test_speed_under_1ms(self):
        """1件の計算は1ミリ秒以下（100回の平均）（NFR-001）。"""
        t0 = time.perf_counter()
        for _ in range(100):
            tax_included(12345, 0.10)
        per_call_ms = (time.perf_counter() - t0) / 100 * 1000
        self.assertLessEqual(per_call_ms, 1.0)


if __name__ == "__main__":
    unittest.main()
