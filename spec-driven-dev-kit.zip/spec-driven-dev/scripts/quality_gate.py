#!/usr/bin/env python3
"""品質ゲート：自動の検査をまとめて実行し、合否をレポートにする。

使い方:
  python quality_gate.py <プロジェクト>            開発中の検査（手動試験の未実施は注意のみ）
  python quality_gate.py <プロジェクト> --release  リリース前の検査（手動試験の未実施があれば不合格）
  python quality_gate.py --hook                    Claude Code の Stop フックとして動く（stdinのJSONを読む）

検査（G1〜G6）:
  G1 設計品質：要件IDとテストの対応（spec_trace.py）
  G2 製造品質：単体試験（unittest）が通る
  G3 製造品質：Python のファイルが構文として正しい
  G4 設計品質：設計書の Mermaid 図が閉じていて、図の型が分かる
  G5 安全：秘密情報らしき文字列が無い（見つけても中身は表示しない）
  G6 手動試験：docs/手動試験記録.md の「未実施」（--release のとき不合格）

終了コード: 0=合格 / 1=不合格 / 2=フック：止める（Claude Code が理由を表示）
レポート: work/quality_report.md
"""
import ast
import json
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import spec_trace  # noqa: E402

SKIP = {".git", "work", "__pycache__", "node_modules", ".venv"}
SECRET_PATTERNS = [
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"sk-[A-Za-z0-9_\-]{20,}"),
    re.compile(r"(?i)(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*['\"][^'\"\s]{8,}['\"]"),
]
MERMAID_TYPES = ("stateDiagram-v2", "stateDiagram", "flowchart", "graph", "classDiagram",
                 "sequenceDiagram", "erDiagram", "gantt", "pie")


def files(root: Path, patterns):
    for p in root.rglob("*"):
        if any(part in SKIP for part in p.parts):
            continue
        if p.is_file() and any(p.match(pat) for pat in patterns):
            yield p


def g1_trace(root):
    unc, dang, n, ok, _ = spec_trace.trace(root)
    if n == 0:
        return "FAIL", "設計書（spec/*.md）に要件IDがありません"
    if unc or dang:
        return "FAIL", "未カバー: " + ", ".join(unc or ["-"]) + " ／ 宙に浮いたタグ: " + ", ".join(dang or ["-"])
    return "PASS", f"要件 {n} 件すべてに試験がある"


def g2_tests(root):
    if not (root / "tests").exists():
        return "FAIL", "tests/ がありません"
    cp = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-q"],
                        cwd=root, capture_output=True, text=True, timeout=600)
    out = (cp.stdout + cp.stderr).strip().splitlines()
    last = out[-1] if out else ""
    if cp.returncode == 0:
        return "PASS", last
    return "FAIL", "試験が失敗しました（" + last + "）"


def g3_syntax(root):
    bad = []
    n = 0
    for f in files(root, ["*.py"]):
        n += 1
        try:  # 構文だけを確かめる（ファイルは書かない）
            ast.parse(f.read_text(encoding="utf-8"), filename=str(f))
        except (SyntaxError, UnicodeDecodeError):
            bad.append(f.name)
    if bad:
        return "FAIL", "構文エラー: " + ", ".join(bad)
    return "PASS", f"{n} ファイルの構文を確認"


def g4_mermaid(root):
    problems, n = [], 0
    for f in files(root, ["spec/*.md"]):
        text = f.read_text(encoding="utf-8")
        lines = text.splitlines()
        inside, first, start = False, "", 0
        for i, line in enumerate(lines, 1):
            s = line.strip()
            if not inside and s == "```mermaid":
                inside, first, start = True, "", i
                n += 1
            elif inside and s == "```mermaid":  # 閉じないまま次の図が始まった
                problems.append(f"{f.name}:{start}（閉じていない）")
                first, start = "", i
                n += 1
            elif inside and s == "```":
                inside = False
                if not first.startswith(MERMAID_TYPES):
                    problems.append(f"{f.name}:{start}（図の型が不明）")
            elif inside and not first and s:
                first = s
        if inside:
            problems.append(f"{f.name}:{start}（閉じていない）")
    if problems:
        return "FAIL", "Mermaid: " + ", ".join(problems)
    return "PASS", f"Mermaid 図 {n} 個を確認"


def g5_secrets(root):
    hits = []
    for f in files(root, ["*.py", "*.md", "*.json", "*.yaml", "*.yml", "*.txt", "*.sh", "*.env"]):
        for i, line in enumerate(f.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            if any(p.search(line) for p in SECRET_PATTERNS):
                hits.append(f"{f.relative_to(root)}:{i}")  # 行番号だけを出す（中身は出さない）
    if hits:
        return "FAIL", "秘密情報らしき記述: " + ", ".join(hits[:5])
    return "PASS", "秘密情報らしき記述は見つかりません"


def g6_manual(root, release):
    rec = root / "docs" / "手動試験記録.md"
    if not rec.exists():
        return ("FAIL" if release else "INFO"), "docs/手動試験記録.md がありません"
    rows = [l for l in rec.read_text(encoding="utf-8").splitlines() if l.strip().startswith("|")]
    pending = [r for r in rows if "未実施" in r]
    if pending:
        return ("FAIL" if release else "INFO"), f"手動試験の未実施 {len(pending)} 件（リリース前に実施）"
    return "PASS", "手動試験は未実施なし"


def run_all(root: Path, release: bool):
    return [
        ("G1 設計品質：要件と試験の対応", *g1_trace(root)),
        ("G2 製造品質：単体試験", *g2_tests(root)),
        ("G3 製造品質：構文", *g3_syntax(root)),
        ("G4 設計品質：Mermaid 図", *g4_mermaid(root)),
        ("G5 安全：秘密情報", *g5_secrets(root)),
        ("G6 手動試験の記録", *g6_manual(root, release)),
    ]


def main(argv):
    if "--hook" in argv:
        data = {}
        try:
            data = json.loads(sys.stdin.read() or "{}")
        except ValueError:
            pass
        if data.get("stop_hook_active"):  # 既にこのフックで続けている → 無限に止めない
            return 0
        root = Path(data.get("cwd") or ".").resolve()
        results = run_all(root, release=False)
        bad = [r for r in results if r[1] == "FAIL"]
        if bad:
            msg = "品質ゲートで不合格です。直してから完了してください：\n" + "\n".join(f"- {b[0]}: {b[2]}" for b in bad)
            print(msg, file=sys.stderr)
            return 2
        return 0

    release = "--release" in argv
    args = [a for a in argv[1:] if not a.startswith("--")]
    root = Path(args[0] if args else ".").resolve()
    results = run_all(root, release)
    lines = ["# 品質レポート", "", f"- 対象：{root}", f"- 種類：{'リリース前' if release else '開発中'}", "",
             "| 検査 | 結果 | 内容 |", "|---|---|---|"]
    lines += [f"| {name} | {st} | {detail} |" for name, st, detail in results]
    fails = [r for r in results if r[1] == "FAIL"]
    lines += ["", f"**総合：{'不合格' if fails else '合格'}**（不合格 {len(fails)} 件）"]
    text = "\n".join(lines) + "\n"
    out = root / "work" / "quality_report.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    print(text)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
