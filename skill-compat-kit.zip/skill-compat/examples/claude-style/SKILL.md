---
name: claude-style
description: 見本（Claude 形式）。見積もりの計算を行う。「見積もりを計算して」で使う。
disable-model-invocation: true
allowed-tools: Read, Bash
---

# claude-style

配置：.claude/skills/claude-style/ に置く。呼び出しは /claude-style と書く。
