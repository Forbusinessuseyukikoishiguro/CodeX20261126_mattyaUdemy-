# 公式の参照先（確認日 2026-11-25）

仕様は変わりやすい。使う前に、各ページで最新の内容を確認する。

| 項目 | 参照先 | 確認した内容 |
|---|---|---|
| Claude Code スキル | code.claude.com/docs/en/skills | SKILL.md の作り方、配置（.claude/skills/） |
| Claude Code フック | code.claude.com/docs/en/hooks | フックのイベント（PreToolUse・Stop など）、設定ファイルの場所（~/.claude/settings.json、.claude/settings.json、.claude/settings.local.json）、Stop で終わりを止める方法（終了コード2）、stop_hook_active |
| Claude のスキルの作り方（ベストプラクティス） | platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices | 本文を短く、必要なときだけ読ませる |
| Claude Code のスキル運用（社内での例） | claude.com/blog/lessons-from-building-claude-code-how-we-use-skills（2026-06-03） | 1つのスキルは1つの型に収める |
| Codex スキル | developers.openai.com/codex/skills | SKILL.md、配置（.agents/skills/）、agents/openai.yaml |
| Agent Skills 標準 | agentskills.io/specification | name・description などの共通の項目 |
| 品質モデル・試験 | ISO/IEC 25010、ISO/IEC/IEEE 29119 | 製造品質・設計品質の考え方（規格の要点の言い換え） |

## 注意

- Codex のフック（自動で動く仕組み）の有無は、この調査では確認できなかった。使うときは公式で確認する
- Claude Code のサブエージェントの定義の形式も、使う前に公式で確認する
