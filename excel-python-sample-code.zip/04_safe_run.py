# 文字のパターン検索(エラー文から部品名を取り出す)に使う標準ライブラリ
import re
# 別のプログラムを動かす標準ライブラリ
import subprocess
# 今のPythonの場所を知るために使う標準ライブラリ
import sys
# 日時を扱う標準ライブラリ
from datetime import datetime
# ファイルの場所を扱う標準ライブラリ
from pathlib import Path

# import名と pip名が違う部品の対応表(一部)
PIP_NAMES = {"PIL": "pillow", "yaml": "pyyaml", "bs4": "beautifulsoup4"}


# 「安全に動かす」関数。script は動かしたいPythonファイル
def run_safely(script, timeout=60, log_dir="logs"):
    # 始めるときに、にゃんこが言う
    print("🐱 処理中だにゃー…ちょっと待ってね！")
    # 失敗しても止まらないように、try で囲む
    try:
        # 別プロセスで動かして、出力を全部受け取る。timeout 秒で打ち切る
        p = subprocess.run([sys.executable, script], capture_output=True, text=True,
                           encoding="utf-8", timeout=timeout)
    # 時間切れのとき
    except subprocess.TimeoutExpired:
        # 時間切れ用のメッセージを作る
        err = f"TimeoutExpired: {timeout}秒たっても終わりませんでした"
        # 終了コードは仮に 124(時間切れの慣習)
        code = 124
    # 時間切れではなく、ふつうに終わったとき
    else:
        # 終了コード(0 なら成功)を取り出す
        code = p.returncode
        # エラー出力の全文を取り出す
        err = p.stderr
    # 成功(0)なら
    if code == 0:
        # 子の出力をそのまま見せる
        print(p.stdout, end="")
        # 完了を知らせる
        print("🐱 終わったニャー！")
        # 成功を返す
        return 0
    # 「No module named 'xxx'」から、足りない部品の名前を探す
    m = re.search(r"No module named '([\w.]+)'", err)
    # 見つかったら「部品不足」、見つからなければ「想定外」と判定する
    hint = (f"部品 {m.group(1).split('.')[0]} が入っていません。"
            f"`python -m pip install {PIP_NAMES.get(m.group(1).split('.')[0], m.group(1).split('.')[0])}` で入ります"
            if m else "想定外のエラーです。ログを一緒に見て決めましょう")
    # ログを置くフォルダを作る(すでにあってもOK)
    Path(log_dir).mkdir(exist_ok=True)
    # ログのファイル名に、日時を入れる
    log = Path(log_dir) / f"{datetime.now():%Y%m%d%H%M%S}_error.txt"
    # エラー全文を、ログファイルに書く(あとで見返せるように)
    log.write_text(f"script: {script}\ncode: {code}\n\n{err}", encoding="utf-8")
    # 失敗をにゃんこが知らせる
    print("🐱 ふにゃっ！うまくいかなかったにゃ…")
    # 何が起きたか(やさしい説明)を伝える
    print("   何が起きた:", hint)
    # ログの場所を必ず伝える
    print("   ログはここにゃ →", log)
    # 失敗を返す
    return code


# このファイルを直接動かしたときだけ
if __name__ == "__main__":
    # 動かしたいファイル名をコマンドから受け取って、安全に動かす
    sys.exit(run_safely(sys.argv[1]))
